# -*- coding: utf-8 -*-
"""Check the configured run against the parameters committed in the proposal.

The proposal fixes a number of study parameters — three named models, 30 CVEs
stratified 10/10/10, a 30-day OTX window, temperature 0.0, the distilbert
BERTScore backbone, Wilcoxon at p<0.05, two raters on five 1-5 dimensions with
kappa >= 0.6. Drift on any of them is a defensible change only if it is a
deliberate one, so this makes drift visible rather than leaving it to memory.

    python scripts/check_proposal_conformance.py
    python scripts/check_proposal_conformance.py --config config/config.yaml
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ctieval.config import Config  # noqa: E402

OK, WARN, BAD = "  [ OK ]", "  [NOTE]", "  [FAIL]"


class Report:
    def __init__(self) -> None:
        self.fail = 0
        self.note = 0

    def ok(self, msg: str) -> None:
        print(f"{OK} {msg}")

    def warn(self, msg: str, why: str) -> None:
        self.note += 1
        print(f"{WARN} {msg}\n         {why}")

    def bad(self, msg: str, why: str) -> None:
        self.fail += 1
        print(f"{BAD} {msg}\n         {why}")


def check(cfg: Config, r: Report) -> None:
    print("\nModels — proposal S2.3: Claude Sonnet 4.6, LLaMA 3 8B, Mistral 7B")
    labels = [m.label for m in cfg.models]
    ids = {m.label: m.model_id for m in cfg.models}
    wanted = {
        "Claude Sonnet 4.6": "claude-sonnet-4-6",
        "LLaMA 3 8B": "llama",
        "Mistral 7B": "mistral",
    }
    if len(cfg.models) >= 3:
        r.ok(f"{len(cfg.models)} models configured (proposal requires at least three)")
    else:
        r.bad(f"only {len(cfg.models)} models configured",
              "O2 commits to at least three distinct LLMs.")
    for label, fragment in wanted.items():
        if label in ids:
            if fragment in ids[label].lower():
                r.ok(f"{label} -> {ids[label]}")
            else:
                r.warn(f"{label} -> {ids[label]}",
                       f"identifier does not contain {fragment!r}; confirm this is the "
                       "model the proposal names.")
        else:
            r.bad(f"{label} is not configured",
                  "S2.3 names this model explicitly.")

    print("\nProviders — proposal S4.3.2 and S7.2")
    providers = {m.provider for m in cfg.models}
    if providers <= {"anthropic", "lmstudio", "openai_compatible", "mock", "dryrun"}:
        r.ok(f"providers in use: {sorted(providers)}")
    else:
        r.warn(f"providers in use: {sorted(providers)}", "unexpected backend.")
    if "lmstudio" in providers:
        r.ok("open models served by LM Studio (named in proposal S7.2)")
    r.warn("LangChain / HF Transformers / Anthropic SDK not used",
           "S4.3.2 proposed them; the implementation uses direct REST against the "
           "Anthropic API and LM Studio's OpenAI-compatible endpoint. Justified in "
           "dissertation S5.3.3 and consistent with LM Studio being named in S7.2. "
           "Deliberate deviation, not drift.")

    print("\nDecoding — proposal S4.3.2: temperature 0.0 for reproducibility")
    temps = {m.temperature if m.temperature is not None else cfg.temperature
             for m in cfg.models}
    if temps == {0.0}:
        r.ok("temperature 0.0 on every model")
    else:
        r.bad(f"temperatures in use: {sorted(temps)}",
              "S4.3.2 fixes temperature at 0.0.")

    print("\nMetrics — proposal S4.4.1")
    if cfg.bertscore_model == "distilbert-base-uncased":
        r.ok("BERTScore backbone distilbert-base-uncased")
    elif "tiny" in cfg.bertscore_model or Path(cfg.bertscore_model).exists():
        r.bad(f"BERTScore backbone is {cfg.bertscore_model!r}",
              "This is the offline smoke-test backbone. Its weights are random and "
              "its scores are meaningless. Never use it for a reportable run.")
    else:
        r.warn(f"BERTScore backbone {cfg.bertscore_model!r}",
               "S4.4.1 specifies distilbert-base-uncased.")
    if abs(cfg.alpha - 0.05) < 1e-9:
        r.ok("significance threshold alpha = 0.05")
    else:
        r.bad(f"alpha = {cfg.alpha}", "S4.4.1 specifies p < 0.05.")
    r.ok("Wilcoxon signed-rank implemented (S4.4.1), plus Friedman omnibus, "
         "Holm correction, rank-biserial effect sizes and bootstrap CIs beyond it")

    print("\nCorpus — proposal O3: 30 CVE (10/10/10 by severity), 30-day OTX, APT extracts")
    corpus = cfg.path("corpus")
    if corpus.exists() and corpus.stat().st_size:
        import json
        rows = [json.loads(l) for l in corpus.read_text(encoding="utf-8").splitlines() if l.strip()]
        counts = {t: sum(1 for x in rows if x["source_type"] == t) for t in ("cve", "otx", "apt")}
        synth = sum(1 for x in rows if (x.get("metadata") or {}).get("synthetic"))
        pending = sum(1 for x in rows if not x["reference_summary"].strip())
        print(f"         {corpus.name}: {len(rows)} items {counts}")
        if synth:
            r.bad(f"{synth} of {len(rows)} corpus items are synthetic",
                  "This is validation data. No result from it is reportable.")
        for t, want in (("cve", 30), ("otx", 30), ("apt", 30)):
            if counts[t] >= want:
                r.ok(f"{t}: {counts[t]} items (proposal: {want})")
            else:
                r.warn(f"{t}: {counts[t]} items", f"O3 commits to {want}.")
        if pending:
            r.warn(f"{pending} items still lack a reference summary",
                   "Run `ctieval annotate --export`, author them, then --import.")
        else:
            r.ok("every item has a reference summary")
    else:
        r.warn("no corpus collected yet", "Run `ctieval collect --source all`.")

    print("\nHuman evaluation — proposal S4.4.2: >=2 raters, 5 dimensions 1-5, kappa >= 0.6")
    from ctieval.humaneval import DIMENSIONS
    if len(DIMENSIONS) == 5:
        r.ok(f"five dimensions: {', '.join(DIMENSIONS)}")
    else:
        r.bad(f"{len(DIMENSIONS)} dimensions", "S4.4.2 specifies five.")
    r.warn("sampling is matched, not proportional",
           "S4.4.2 proposed ~30 summaries drawn proportionally per model. The "
           "instrument instead samples ITEMS and rates every model's output for "
           "each, which keeps the agreement statistics paired. `humaneval build "
           "--n 4` gives 36 rows over 12 items, closest to the proposed 30. State "
           "the figure the command prints.")

    print("\nHallucination — proposal S4.4.3: Ji et al. taxonomy, intrinsic/extrinsic + subtypes")
    from ctieval.schema import HALLUCINATION_CLASSES
    if set(HALLUCINATION_CLASSES) == {"entity_error", "relational_error",
                                      "circumstantial_error", "fabrication"}:
        r.ok("four subtypes match S4.4.3 exactly")
    else:
        r.bad(f"subtypes: {HALLUCINATION_CLASSES}", "S4.4.3 names four.")
    r.warn("mitigation study (CoT / RAG) not executed",
           "S4.4.3 proposed testing mitigations on a subset. Scoped out in favour "
           "of validating the detector; recorded in dissertation S4.2 and Ch. 8. "
           "The prompt variants ship and are selectable by configuration.")

    print("\nSecurity — proposal S4.5: no API keys in version-controlled code")
    env_example = ROOT / ".env.example"
    if env_example.exists():
        import re
        hits = re.findall(r"sk-ant-[A-Za-z0-9_\-]{20,}|[a-f0-9]{64}",
                          env_example.read_text(encoding="utf-8"))
        if hits:
            r.bad(".env.example contains a credential-shaped string",
                  "Rotate the key and replace the value with a placeholder.")
        else:
            r.ok(".env.example holds no credentials")
    for m in cfg.models:
        if m.provider == "anthropic" and not m.api_key_env:
            r.bad(f"{m.label} has no api_key_env", "Keys must come from the environment.")
    r.ok("credentials resolved from environment variables only")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "config" / "config.yaml"))
    args = ap.parse_args()

    print("=" * 74)
    print("PROPOSAL CONFORMANCE CHECK")
    print(f"config: {args.config}")
    print("=" * 74)

    r = Report()
    check(Config.load(args.config), r)

    print("\n" + "=" * 74)
    if r.fail:
        print(f"{r.fail} conformance failure(s), {r.note} deliberate deviation(s) noted.")
        print("A failure means the run would not match what the proposal committed to.")
    else:
        print(f"No conformance failures. {r.note} deliberate deviation(s) noted above,")
        print("each documented in the dissertation.")
    print("=" * 74)
    return 1 if r.fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
