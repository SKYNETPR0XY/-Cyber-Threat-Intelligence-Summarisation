"""Full-scale offline dry run — DRY RUN ONLY, PRODUCES NO EXPERIMENTAL RESULT.

Purpose
-------
`python -m ctieval demo` proves the pipeline runs, but it does so on 30 items
with three mock providers that emit near-identical extractive text. That is
enough for CI and not enough to rehearse Chapter 6: with identical candidates
the Friedman/Wilcoxon layer is degenerate and the figures do not show what the
real ones will show.

This driver runs the *same* pipeline at the real study scale (30 CVE / 30 OTX /
30 APT = 90 items x 3 models = 270 generations) with three stand-in providers
that differ in summarisation quality, error rate, latency and cost, so that
every downstream stage - metrics, Friedman, Holm-corrected Wilcoxon, effect
sizes, hallucination taxonomy, detector validation, human-evaluation agreement,
cost/latency - is exercised on realistic, non-degenerate input.

Everything it touches is stamped synthetic. Figures carry the DRY RUN
watermark, the results pack carries the banner, and the corpus items carry
metadata["synthetic"]=True. No number produced here may appear in the
dissertation as a finding.

Usage:  python scripts/dryrun_fullscale.py [--out results/dryrun]
"""

from __future__ import annotations

import argparse
import json
import random
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ctieval.collectors import offline                      # noqa: E402
from ctieval.config import Config, ModelConfig              # noqa: E402
from ctieval.hallucination import check_grounding, validate_detector  # noqa: E402
from ctieval.humaneval import DIMENSIONS, analyse, build_sheet        # noqa: E402
from ctieval.metrics import compare_models, score_all       # noqa: E402
from ctieval.providers.mock import source_key  # noqa: E402
from ctieval.report import build_results_pack               # noqa: E402
from ctieval.runner import run_experiment                   # noqa: E402
from ctieval.schema import load_generations, write_jsonl    # noqa: E402

SEED = 20260612
_SENT = re.compile(r"(?<=[.!?])\s+")

PADDING = [
    "Organisations are advised to review their exposure and apply vendor guidance.",
    "Further analysis may be required to determine the full operational impact.",
    "This information should be correlated with internal telemetry where available.",
]


MODELS = [
    dict(label="Stand-in A (proxies the API model)",
         model_id="mock/standin-a", provider="mock",
         extra=dict(quality=0.96, error_rate=0.14, seed=11,
                    usd_per_1k_in=0.003, usd_per_1k_out=0.015,
                    latency_mu=3.1, latency_sigma=0.30)),
    dict(label="Stand-in B (proxies local open model 1)",
         model_id="mock/standin-b", provider="mock",
         extra=dict(quality=0.74, error_rate=0.33, seed=22,
                    usd_per_1k_in=0.0, usd_per_1k_out=0.0,
                    latency_mu=11.4, latency_sigma=0.35)),
    dict(label="Stand-in C (proxies local open model 2)",
         model_id="mock/standin-c", provider="mock",
         extra=dict(quality=0.62, error_rate=0.41, seed=33,
                    usd_per_1k_in=0.0, usd_per_1k_out=0.0,
                    latency_mu=8.9, latency_sigma=0.32)),
]


def simulate_raters(sheet: pd.DataFrame, key: pd.DataFrame, findings_by_pair: dict,
                    out_dir: Path, seed: int = SEED) -> dict:
    """Two blinded raters whose scores track real quality plus rater noise.

    Scores are driven by the model's true quality and by the number of grounding
    findings on that specific summary, so the kappa/ICC layer is exercised on
    data with genuine (not random) inter-rater structure.
    """
    rng = np.random.default_rng(seed)
    quality = {m["model_id"]: m["extra"]["quality"] for m in MODELS}
    key_by_eval = key.set_index("eval_id")
    files = {}
    for rater, bias, noise in (("rater1", 0.10, 0.55), ("rater2", -0.12, 0.62)):
        rows = []
        for eid in sheet["eval_id"]:
            k = key_by_eval.loc[eid]
            q = quality[k["model_id"]]
            n_find = findings_by_pair.get((k["item_id"], k["model_id"]), 0)
            base = 1.6 + 3.1 * q
            row = {"eval_id": eid}
            for dim in DIMENSIONS:
                penalty = 0.0
                if dim in ("factual_accuracy", "absence_of_hallucination"):
                    penalty = 0.85 * min(n_find, 3)
                elif dim == "conciseness":
                    penalty = 1.4 * (1 - q) * 3
                elif dim == "completeness":
                    penalty = 2.6 * (1 - q)
                elif dim == "relevance":
                    penalty = 2.2 * (1 - q) + 0.25 * min(n_find, 2)
                v = base + bias - penalty + rng.normal(0, noise)
                row[dim] = int(np.clip(round(v), 1, 5))
            row["notes"] = ""
            rows.append(row)
        df = pd.DataFrame(rows)
        p = out_dir / f"human_eval_{rater}.csv"
        df.to_csv(p, index=False)
        files[rater] = str(p)
    return files


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/dryrun")
    ap.add_argument("--n-cve", type=int, default=30)
    ap.add_argument("--n-otx", type=int, default=30)
    ap.add_argument("--n-apt", type=int, default=30)
    args = ap.parse_args()

    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    print("=" * 74)
    print("FULL-SCALE OFFLINE DRY RUN - synthetic corpus, stand-in providers.")
    print("Validates the pipeline at study scale. Produces NO experimental result.")
    print("=" * 74)

    cfg = Config.load(str(ROOT / "config" / "config.demo.yaml"))
    cfg.models = [ModelConfig(label=m["label"], provider=m["provider"],
                              model_id=m["model_id"], extra=m["extra"],
                              max_tokens=512, temperature=0.0) for m in MODELS]
    from ctieval.providers import get_provider

    instances = {m.model_id: get_provider(m) for m in cfg.models}

    corpus = offline.collect(n_cve=args.n_cve, n_otx=args.n_otx,
                             n_apt=args.n_apt, seed=SEED)
    corpus_path = out / "corpus.jsonl"
    write_jsonl(corpus_path, corpus)
    print(f"Corpus: {len(corpus)} synthetic items -> {corpus_path.name}")

    gen_path = out / "generations.jsonl"
    gen_path.write_text("", encoding="utf-8")  # truncate; some mounts disallow unlink
    # Reuse the very provider instances the driver holds, so the injected-error
    # log survives the stage and can validate the detector afterwards.
    import ctieval.runner as _runner

    _runner.get_provider = lambda m: instances[m.model_id]
    run_experiment(corpus, cfg, gen_path, models=cfg.models, resume=False, progress=False)
    gens = load_generations(gen_path)
    print(f"Generations: {len(gens)}")

    by_id = {i.item_id: i for i in corpus}
    # The dry run has no BERTScore backbone by design; the labelled proxy is
    # explicitly authorised here and nowhere else.
    metrics = score_all(gens, by_id, cfg.bertscore_model,
                        allow_semantic_fallback=True)
    metrics.to_csv(out / "metrics.csv", index=False)
    print(f"Scored {len(metrics)} generations -> metrics.csv")

    findings = []
    for g in gens:
        item = by_id.get(g.item_id)
        if item:
            findings += check_grounding(g, item)
    label_by_id = {g.model_id: g.model_label for g in gens}
    rows = [f.to_dict() for f in findings]
    for r in rows:
        r["model_label"] = label_by_id.get(r["model_id"], r["model_id"])
    write_jsonl(out / "hallucinations.jsonl", rows)
    halluc = pd.DataFrame(rows)
    print(f"Grounding findings: {len(rows)}")

    # Detector validation against the errors the stand-in providers injected.
    injected = [rec for p in instances.values() for rec in p.injected]
    key_by_src = {source_key(i.source_text): i.item_id for i in corpus}
    detector = validate_detector(findings, injected, key_by_src)

    # The shipped function now matches per finding. Keep the old span-set
    # figure alongside it so the difference stays visible in the dry run.
    detector_spanset = validate_detector(findings, injected, None)

    print(f"Detector validation (per finding):  {detector}")
    print(f"Detector validation (span sets):    {detector_spanset}")
    pd.DataFrame([detector, detector_spanset]).to_csv(
        out / "table_detector_validation.csv", index=False
    )

    # Statistics
    sem = metrics["semantic_metric"].iloc[0]
    stats_tables, omnibus = {}, {}
    for metric in ["rouge1_f", "rougeL_f", sem]:
        if metric in metrics.columns:
            tbl, o = compare_models(metrics, metric, cfg.alpha)
            if not tbl.empty:
                stats_tables[metric] = tbl
                omnibus[metric] = o

    # Human evaluation
    sheet_path = out / "human_eval_sheet.csv"
    key_path = out / "human_eval_key.csv"
    sheet = build_sheet(gens, by_id, sheet_path, key_path, items_per_source_type=10)
    key = pd.read_csv(key_path)
    per_pair = {}
    for f in findings:
        per_pair[(f.item_id, f.model_id)] = per_pair.get((f.item_id, f.model_id), 0) + 1
    files = simulate_raters(sheet, key, per_pair, out)
    long, per_model, agreement = analyse(files, key_path)
    long.to_csv(out / "human_scores.csv", index=False)
    print(f"Human eval: {len(sheet)} blinded rows, agreement {agreement}")

    pack = build_results_pack(
        metrics, halluc, stats_tables, omnibus, out / "report",
        synthetic=True, human=(long, per_model, agreement), alpha=cfg.alpha,
        detector_validation=detector, allow_synthetic=True,
    )
    print(f"Results pack -> {pack}")
    (out / "omnibus.json").write_text(json.dumps(omnibus, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
