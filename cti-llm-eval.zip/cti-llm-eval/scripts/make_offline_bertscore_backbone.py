# -*- coding: utf-8 -*-
"""Build a tiny local BERTScore backbone — OFFLINE SMOKE TEST ONLY.

BERTScore normally downloads `distilbert-base-uncased` from the Hugging Face
hub. On a machine that cannot reach the hub the metric cannot run at all, which
means the BERTScore code path goes untested until the day of the real run.

This constructs a randomly-initialised DistilBERT of the same architecture, two
layers deep, with a vocabulary built from a supplied corpus, and writes it to
`models/tiny-bertscore/`. Pointing `bertscore_model` at that directory exercises
the genuine bert-score library end to end with no network.

The scores it produces are meaningless — the weights are random. It proves the
plumbing, nothing else. Never configure it for a real run: `ctieval score` will
happily use it and the resulting column will be numerically worthless while
being named `bertscore_f1`.

    python scripts/make_offline_bertscore_backbone.py
    python -m ctieval --config config/config.offline-bertscore.yaml score
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "models" / "tiny-bertscore"

SPECIALS = ["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"]


def build_vocab(corpus_paths: list[Path], limit: int = 6000) -> list[str]:
    words: dict[str, int] = {}
    for p in corpus_paths:
        if not p.exists():
            continue
        for line in p.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            blob = " ".join(str(rec.get(k, "")) for k in
                            ("source_text", "reference_summary", "summary"))
            for w in re.findall(r"[a-z0-9]+", blob.lower()):
                words[w] = words.get(w, 0) + 1
    ranked = [w for w, _ in sorted(words.items(), key=lambda kv: -kv[1])][:limit]
    # single characters keep the WordPiece fallback able to cover anything
    chars = [chr(c) for c in range(ord("a"), ord("z") + 1)]
    chars += [str(d) for d in range(10)]
    pieces = [f"##{c}" for c in chars]
    seen, vocab = set(), []
    for tok in SPECIALS + chars + pieces + ranked:
        if tok not in seen:
            seen.add(tok)
            vocab.append(tok)
    return vocab


def main() -> int:
    from transformers import DistilBertConfig, DistilBertModel, DistilBertTokenizerFast

    OUT.mkdir(parents=True, exist_ok=True)
    vocab = build_vocab([
        ROOT / "data" / "corpus.jsonl",
        ROOT / "data" / "corpus_demo.jsonl",
        ROOT / "results" / "dryrun" / "corpus.jsonl",
    ])
    (OUT / "vocab.txt").write_text("\n".join(vocab) + "\n", encoding="utf-8")
    print(f"vocab: {len(vocab)} tokens")

    cfg = DistilBertConfig(
        vocab_size=len(vocab), dim=128, n_layers=2, n_heads=2,
        hidden_dim=256, max_position_embeddings=512,
    )
    DistilBertModel(cfg).save_pretrained(OUT)
    DistilBertTokenizerFast(vocab_file=str(OUT / "vocab.txt"),
                            do_lower_case=True).save_pretrained(OUT)
    print(f"tiny backbone -> {OUT}")
    print("Configure with:  bertscore_model: models/tiny-bertscore")
    print("                 bertscore_num_layers: 2")
    print("SMOKE TEST ONLY — the weights are random and the scores are meaningless.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
