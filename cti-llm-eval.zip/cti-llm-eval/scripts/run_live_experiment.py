# -*- coding: utf-8 -*-
"""One-command live experiment runner.

Executes the real study end to end and refuses to continue at any point where
the result would not be reportable. Every gate below exists because failing it
silently would produce numbers that look fine and are not.

    python scripts/run_live_experiment.py            # full run
    python scripts/run_live_experiment.py --smoke    # 3 items, checks wiring
    python scripts/run_live_experiment.py --resume   # continue an interrupted run

Prerequisites, all checked before anything is spent:
  * ANTHROPIC_API_KEY and OTX_API_KEY exported in this shell
  * LM Studio running with the server started, both open models loadable
  * bert-score installed and able to reach the Hugging Face hub
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable

GREEN, RED, YELLOW, DIM, RESET = "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m"


def say(msg: str, colour: str = "") -> None:
    print(f"{colour}{msg}{RESET}", flush=True)


def step(n: str, title: str) -> None:
    say(f"\n{'=' * 74}\n[{n}] {title}\n{'=' * 74}")


def run(args: list[str], *, allow_fail: bool = False) -> int:
    say(f"$ python -m ctieval {' '.join(args)}", DIM)
    rc = subprocess.run([PY, "-m", "ctieval", *args], cwd=str(ROOT)).returncode
    if rc and not allow_fail:
        say(f"\nStopped: `ctieval {args[0]}` exited {rc}.", RED)
        say("Nothing after this point would be reportable. Fix the cause and re-run "
            "with --resume; completed work is not repeated.", RED)
        sys.exit(rc)
    return rc


# --------------------------------------------------------------------------- #
# Pre-flight gates
# --------------------------------------------------------------------------- #

def gate_environment() -> None:
    step("0/8", "Pre-flight gates")
    problems = []

    for var, why in (("ANTHROPIC_API_KEY", "the proprietary comparator"),
                     ("OTX_API_KEY", "OTX collection")):
        if os.environ.get(var):
            say(f"  [ OK ] {var} is set", GREEN)
        else:
            problems.append(f"{var} is not set ({why}).")
            say(f"  [FAIL] {var} is not set  — needed for {why}", RED)

    if os.environ.get("NVD_API_KEY"):
        say("  [ OK ] NVD_API_KEY is set (50 requests / 30s)", GREEN)
    else:
        say("  [WARN] NVD_API_KEY unset — collection throttles to 5 requests / 30s", YELLOW)

    # BERTScore must be real, not the labelled proxy: scoring refuses without it,
    # so catching it here saves a full generation run.
    try:
        import bert_score  # noqa: F401
        say("  [ OK ] bert-score is installed", GREEN)
        try:
            from transformers import AutoConfig
            AutoConfig.from_pretrained("distilbert-base-uncased")
            say("  [ OK ] BERTScore backbone reachable / cached", GREEN)
        except Exception as exc:  # noqa: BLE001
            problems.append(f"BERTScore backbone unavailable: {type(exc).__name__}.")
            say(f"  [FAIL] backbone unavailable ({type(exc).__name__}) — needs hub access once", RED)
    except ImportError:
        problems.append("bert-score is not installed (pip install bert-score).")
        say("  [FAIL] bert-score not installed — `pip install bert-score`", RED)

    apt = ROOT / "data" / "apt_pdfs"
    pdfs = [p for p in apt.glob("*.pdf") if p.name != "sample.pdf"]
    if pdfs:
        say(f"  [ OK ] {len(pdfs)} vendor/APT report PDF(s) in data/apt_pdfs/", GREEN)
    else:
        problems.append("No real report PDFs in data/apt_pdfs/ (only the sample).")
        say("  [FAIL] data/apt_pdfs/ holds no real reports — the APT stratum needs them", RED)

    if problems:
        say("\nPre-flight failed. Nothing has been spent. Resolve:", RED)
        for p in problems:
            say(f"  - {p}", RED)
        sys.exit(2)

    say("\nBackend reachability:", DIM)
    if run(["preflight"], allow_fail=True):
        say("\nAt least one backend is unreachable. Start LM Studio's server and "
            "confirm each model_id in config/config.yaml matches what it reports.", RED)
        sys.exit(2)


# --------------------------------------------------------------------------- #

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true",
                    help="generate 3 summaries only, to prove the wiring")
    ap.add_argument("--resume", action="store_true",
                    help="skip collection and annotation; continue generation")
    ap.add_argument("--judge", default=None,
                    help="model label to use as the LLM judge (one extra call per summary)")
    args = ap.parse_args()

    gate_environment()

    if not args.resume:
        step("1/8", "Collect the corpus (30 CVE / 30 OTX / APT sections)")
        run(["collect", "--source", "all", "--pdf-dir", "data/apt_pdfs"])

        step("2/8", "Author the missing reference summaries")
        run(["annotate", "--export"])
        say("\nFill the 'reference_summary' column in data/reference_summaries.csv, have "
            "your second practitioner review it, then:", YELLOW)
        say("  python -m ctieval annotate --import data/reference_summaries.csv", YELLOW)
        say("  python scripts/run_live_experiment.py --resume", YELLOW)
        say("\nStopping here: generation against un-referenced items would produce "
            "summaries that cannot be scored.", YELLOW)
        return 0

    step("3/8", "Generate summaries")
    run(["run"] + (["--limit", "3"] if args.smoke else []))
    if args.smoke:
        say("\nSmoke test complete. Inspect results/generations.jsonl, then re-run "
            "without --smoke.", GREEN)
        return 0

    step("4/8", "Score (ROUGE + BERTScore + inferential statistics)")
    run(["score"])

    step("5/8", "Detect hallucination candidates")
    run(["detect"] + (["--judge", args.judge] if args.judge else []))

    step("6/8", "Adjudicate")
    run(["adjudicate", "--export", "results/adjudication.csv"])
    say("\nReview every row in results/adjudication.csv, set 'confirmed' to TRUE or "
        "FALSE, then:", YELLOW)
    say("  python -m ctieval adjudicate --import results/adjudication.csv", YELLOW)
    say("\nUntil that is done the reported rate is a detector-flagged rate, not a "
        "hallucination rate (Section 6.2).", YELLOW)

    step("7/8", "Build the blinded human-evaluation workbook")
    run(["humaneval", "build", "--n", "10"])
    say("\nSend one copy of results/human_eval_sheet.csv to each rater. Keep "
        "human_eval_key.csv to yourself. When both return:", YELLOW)
    say("  python -m ctieval humaneval analyse --scores rater1=r1.csv --scores rater2=r2.csv",
        YELLOW)

    step("8/8", "Report")
    run(["report"])
    say("\nVerifying the arithmetic independently…", DIM)
    subprocess.run([PY, "scripts/verify_statistics.py", "results"], cwd=str(ROOT))

    say("\nDone. results/report/ holds every table and figure Chapter 6 needs.", GREEN)
    say("Each Section 6.3 slot in the dissertation names the file that fills it.", GREEN)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
