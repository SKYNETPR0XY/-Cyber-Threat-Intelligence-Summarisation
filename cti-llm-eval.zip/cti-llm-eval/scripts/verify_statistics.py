"""Independent recomputation of every statistic the pipeline reports.

Nothing here imports the code under test except to compare against it: Friedman,
Kendall's W, Wilcoxon, Holm, rank-biserial, weighted kappa and ICC(2,k) are all
recomputed from the raw ``metrics.csv`` with scipy (and, for kappa, against
scikit-learn) and checked against what the pipeline wrote.

Run it after any change to metrics.py, report.py or humaneval.py:

    python scripts/verify_statistics.py [results/dryrun]
"""
import json, numpy as np, pandas as pd
from itertools import combinations
from scipy import stats

import sys as _sys
d = (_sys.argv[1] if len(_sys.argv) > 1 else "results/dryrun").rstrip("/") + "/"
m=pd.read_csv(d+"metrics.csv")
ok=[]

def chk(name, a, b, tol=1e-6):
    good = (abs(a-b) <= tol) if not (np.isnan(a) and np.isnan(b)) else True
    ok.append(good); print(f"  [{'PASS' if good else 'FAIL'}] {name}: pipeline={a!r} independent={b!r}")

# ---- 1. Friedman + Kendall's W ----
print("1. Omnibus tests")
omni=json.load(open(d+"omnibus.json"))
for metric,o in omni.items():
    wide=m.pivot_table(index="item_id",columns="model_label",values=metric,aggfunc="first").dropna()
    chi2,p=stats.friedmanchisquare(*[wide[c].to_numpy() for c in wide.columns])
    n,k=wide.shape[0],wide.shape[1]
    W=chi2/(n*(k-1))
    chk(f"{metric} chi2", o["friedman_chi2"], float(chi2), 1e-9)
    chk(f"{metric} p", o["friedman_p"], float(p), 1e-15)
    chk(f"{metric} Kendall W", o["kendalls_w"], float(W), 1e-9)
    # W must lie in [0,1]
    ok.append(0<=W<=1); print(f"  [{'PASS' if 0<=W<=1 else 'FAIL'}] {metric} W in [0,1]: {W:.4f}")

# ---- 2. Wilcoxon + Holm + rank-biserial ----
print("\n2. Pairwise Wilcoxon, Holm correction, effect sizes")
for metric in ["rouge1_f","rougeL_f","semantic_sim_tfidf"]:
    t=pd.read_csv(d+f"report/table_stats_{metric}.csv")
    wide=m.pivot_table(index="item_id",columns="model_label",values=metric,aggfunc="first").dropna()
    cols=list(wide.columns); raw=[]
    for _,r in t.iterrows():
        xa,xb=wide[r.model_a].to_numpy(),wide[r.model_b].to_numpy()
        W,p=stats.wilcoxon(xa,xb,zero_method="wilcox")
        raw.append(p)
        dd=xa-xb; dd=dd[dd!=0]; rk=stats.rankdata(np.abs(dd))
        rb=(rk[dd>0].sum()-rk[dd<0].sum())/rk.sum()
        chk(f"{metric} {r.model_a[:7]}v{r.model_b[:7]} W", r.wilcoxon_W, float(W), 1e-9)
        chk(f"{metric} {r.model_a[:7]}v{r.model_b[:7]} p_raw", r.p_raw, float(p), 1e-12)
        chk(f"{metric} {r.model_a[:7]}v{r.model_b[:7]} r_rb", r.rank_biserial_r, float(rb), 1e-9)
        ok.append(-1<=rb<=1)
    # Holm, recomputed independently
    order=np.argsort(raw); adj=np.empty(len(raw)); run=0.0
    for rank,idx in enumerate(order):
        run=max(run,(len(raw)-rank)*raw[idx]); adj[idx]=min(1.0,run)
    for i,r in t.iterrows():
        chk(f"{metric} p_holm[{i}]", r.p_holm, float(adj[i]), 1e-12)
    mono = all(adj[i]>=raw[i]-1e-15 for i in range(len(raw)))
    ok.append(mono); print(f"  [{'PASS' if mono else 'FAIL'}] {metric}: every Holm p >= raw p")

# ---- 3. Descriptives match the raw metric file ----
print("\n3. Table 6.1 descriptives vs raw data")
desc=pd.read_csv(d+"report/table_descriptives.csv")
for _,r in desc.iterrows():
    sub=m[m.model_label==r.Model]
    for col in ["rouge1_f","rouge2_f","rougeL_f"]:
        chk(f"{r.Model[:7]} {col} mean", r[f"{col}_mean"], round(float(sub[col].mean()),4), 5e-5)

# ---- 4. Hallucination rates ----
print("\n4. Table 6.4 hallucination rates")
h=pd.DataFrame([json.loads(l) for l in open(d+"hallucinations.jsonl",encoding="utf-8")])
hr=pd.read_csv(d+"report/table_hallucination_rates.csv")
for _,r in hr.iterrows():
    sub=h[h.model_label==r.Model]; n=m[m.model_label==r.Model]["item_id"].nunique()
    chk(f"{r.Model[:7]} flagged", r.Flagged, int(sub.item_id.nunique()), 0)
    chk(f"{r.Model[:7]} flagged%", r["Flagged %"], round(sub.item_id.nunique()/n*100,1), 0.05)
    chk(f"{r.Model[:7]} intrinsic+extrinsic == findings", r.Findings, int(r.Intrinsic+r.Extrinsic), 0)
    # the figure's stacked segments must sum to the table's rate (F2)
    i=set(sub[sub.category=="intrinsic"].item_id); e=set(sub[sub.category=="extrinsic"].item_id)
    chk(f"{r.Model[:7]} figure segments == table rate",
        r["Flagged %"], round((len(i-e)+len(e-i)+len(i&e))/n*100,1), 0.05)
    lo,hi=[float(v) for v in r["95% CI"].strip("[]").split(",")]
    ok.append(lo <= r["Flagged %"] <= hi)
    print(f"  [{'PASS' if lo <= r['Flagged %'] <= hi else 'FAIL'}] {r.Model[:7]} Wilson CI brackets the estimate: {r['95% CI']}")

# ---- 5. Wilson intervals recomputed from first principles ----
print("\n5. Wilson 95% CIs recomputed independently")
from ctieval.metrics import wilson_ci as _wci
for _,r in hr.iterrows():
    k_,n_=int(r.Flagged),int(r.Summaries); p=k_/n_; z=1.959963985
    den=1+z*z/n_; c=(p+z*z/(2*n_))/den
    half=z*np.sqrt(p*(1-p)/n_+z*z/(4*n_*n_))/den
    lo_i,hi_i=max(0,c-half),min(1,c+half)
    lo_p,hi_p=_wci(k_,n_)
    chk(f"{r.Model[:7]} Wilson lo", round(lo_p,6), round(lo_i,6), 1e-6)
    chk(f"{r.Model[:7]} Wilson hi", round(hi_p,6), round(hi_i,6), 1e-6)

# ---- 6. Human-eval agreement ----
print("\n6. Human evaluation: kappa and ICC")
from ctieval.humaneval import weighted_cohens_kappa, icc2k, DIMENSIONS
long=pd.read_csv(d+"human_scores.csv")
for dim in DIMENSIONS:
    w=long.pivot_table(index="eval_id",columns="rater",values=dim,aggfunc="first").dropna()
    k_pipe=weighted_cohens_kappa(w.iloc[:,0].round().to_numpy(),w.iloc[:,1].round().to_numpy())
    # independent linear-weighted kappa via sklearn
    from sklearn.metrics import cohen_kappa_score
    k_sk=cohen_kappa_score(w.iloc[:,0].astype(int),w.iloc[:,1].astype(int),weights="linear",labels=[1,2,3,4,5])
    chk(f"kappa_w {dim}", round(float(k_pipe),4), round(float(k_sk),4), 2e-3)
w=long.pivot_table(index="eval_id",columns="rater",values="composite",aggfunc="first").dropna().to_numpy()
n,k=w.shape; grand=w.mean()
msr=k*((w.mean(1)-grand)**2).sum()/(n-1); msc=n*((w.mean(0)-grand)**2).sum()/(k-1)
res=w-w.mean(1,keepdims=True)-w.mean(0,keepdims=True)+grand
mse=(res**2).sum()/((n-1)*(k-1))
icc_ind=(msr-mse)/(msr+(msc-mse)/n)
chk("ICC(2,k) composite", round(float(icc2k(w)),4), round(float(icc_ind),4), 1e-4)

# ---- 7. Figures exist and are non-trivial ----
print("\n7. Figure files")
from pathlib import Path
for f in ["fig_metrics_by_model.png","fig_rougeL_by_source.png","fig_hallucination.png","fig_cost_latency.png"]:
    p=Path(d+"report/figures/"+f); good=p.exists() and p.stat().st_size>20000
    ok.append(good); print(f"  [{'PASS' if good else 'FAIL'}] {f} ({p.stat().st_size if p.exists() else 0} bytes)")

print(f"\n==== {sum(ok)}/{len(ok)} checks passed ====")
