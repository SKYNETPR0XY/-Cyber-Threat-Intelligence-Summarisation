"""Hallucination detection and classification for CTI summaries.

Implements the three complementary detectors described in Chapter 5 of the
dissertation:

``grounding``
    A deterministic, source-anchored checker. It extracts *checkable atoms* from
    the candidate summary — identifiers, scores, versions, dates, network
    artefacts, quantities and named entities — and tests each against the source
    text and the item's structured metadata. Atoms whose type appears in the
    source but whose *value* differs are classified **intrinsic**; atoms with no
    basis in the source are classified **extrinsic**. Subtypes follow Ji et al.
    (2023) as specialised in Table 5.4.

``llm_judge``
    An LLM adjudicates the summary against the source and returns a structured
    verdict. Higher recall on paraphrastic and relational errors that the
    grounding checker cannot see, at the cost of being itself fallible.

``selfcheck``
    A SelfCheckGPT-style consistency score (Manakul et al., 2023): the same
    prompt is resampled at non-zero temperature and sentence-level agreement
    across samples is measured. Low agreement flags likely fabrication without
    requiring any external knowledge base.

The grounding checker is the primary instrument; its precision and recall
against the seeded injection set are reported as an instrument-validity check.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass

from .schema import CTIItem, Generation, HallucinationFinding

# --------------------------------------------------------------------------- #
# Atom extraction
# --------------------------------------------------------------------------- #

PATTERNS: dict[str, re.Pattern] = {
    "cve_id": re.compile(r"\bCVE-\d{4}-\d{4,7}\b"),
    "cwe_id": re.compile(r"\bCWE-\d{1,4}\b"),
    "attack_id": re.compile(r"\bT\d{4}(?:\.\d{3})?\b"),
    "capec_id": re.compile(r"\bCAPEC-\d{1,4}\b"),
    "ipv4": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
    "hash": re.compile(r"\b[a-fA-F0-9]{32,64}\b"),
    "domain": re.compile(r"\b(?:[a-z0-9-]+\.)+(?:com|net|org|io|ru|cn|info|xyz)\b", re.I),
    "port": re.compile(r"\b(?:TCP|UDP)?\s*port\s+(\d{1,5})\b", re.I),
    "percentage": re.compile(r"\b\d{1,3}(?:\.\d+)?\s?%"),
    "version": re.compile(r"\b\d+\.\d+(?:\.\d+){0,2}\b"),
    "year": re.compile(r"\b(?:19|20)\d{2}\b"),
}

# Claims that materially change an analyst's response and are therefore checked
# even when phrased loosely.
RISK_CLAIMS: dict[str, re.Pattern] = {
    "active_exploitation": re.compile(
        r"\b(actively exploited|exploited in the wild|under active attack|"
        r"observed exploitation|being exploited)\b",
        re.I,
    ),
    "public_exploit": re.compile(
        r"\b(proof[- ]of[- ]concept|public exploit|exploit code is available|"
        r"weaponised exploit|PoC (?:is )?available)\b",
        re.I,
    ),
    "zero_day": re.compile(r"\b(zero[- ]day|0[- ]day)\b", re.I),
    "ransomware": re.compile(r"\bransomware\b", re.I),
    "attribution": re.compile(
        r"\b(attributed to|linked to|operated by|associated with)\b", re.I
    ),
    "patch_status": re.compile(
        r"\b(no patch (?:is )?available|unpatched|patch (?:is )?available|"
        r"fixed in|vendor has released)\b",
        re.I,
    ),
}

# Terms whose meaning flips an operational conclusion.
POLARITY_PAIRS = [
    ("allows", "prevents"),
    ("authenticated", "unauthenticated"),
    ("remote", "local"),
    ("requires user interaction", "does not require user interaction"),
    ("patched", "unpatched"),
    ("increase", "decrease"),
    ("rose", "fell"),
]

STOP_ENTITY = {
    "The", "This", "A", "An", "It", "SOC", "CVSS", "CVE", "CWE", "IoC", "IOC",
    "TCP", "UDP", "HTTP", "HTTPS", "API", "URL", "OS", "PDF", "SQL", "XSS",
    "Successful", "Security", "Operations", "Centre", "Center", "Analysts",
    "Attackers", "Defenders", "Exploitation", "However", "Because",
}

ENTITY_PAT = re.compile(r"\b(?:[A-Z][a-zA-Z0-9]+(?:\s+[A-Z][a-zA-Z0-9]+){0,3})\b")

# "CVSS:3.1/AV:N/AC:L/..." — masked before score extraction so that the
# specification version is not mistaken for a base score.
CVSS_VECTOR = re.compile(r"CVSS:\d\.\d(?:/[A-Z]+:[A-Z]+)+", re.I)

CVSS_SCORE_CUE = re.compile(
    r"(?:CVSS(?:\s*v?\d(?:\.\d)?)?\s*(?:base\s+)?score|base\s+score|"
    r"severity\s+score|score\s+of|rated|scored)\D{0,12}(\d{1,2}\.\d)",
    re.I,
)

SEVERITY_CUE = re.compile(
    r"(?:severity(?:\s+(?:of|is|:))?\s*(critical|high|medium|low)\b"
    r"|\b(critical|high|medium|low)\s+severity\b)",
    re.I,
)

SUBTYPE_BY_ATOM = {
    "cve_id": "entity_error",
    "cwe_id": "entity_error",
    "attack_id": "entity_error",
    "capec_id": "entity_error",
    "domain": "entity_error",
    "ipv4": "entity_error",
    "hash": "entity_error",
    "entity": "entity_error",
    "version": "circumstantial_error",
    "year": "circumstantial_error",
    "port": "circumstantial_error",
    "percentage": "circumstantial_error",
    "cvss_score": "circumstantial_error",
    "severity": "circumstantial_error",
}


@dataclass
class Atom:
    kind: str
    value: str
    context: str


def _context(text: str, match: re.Match, width: int = 60) -> str:
    a = max(0, match.start() - width)
    b = min(len(text), match.end() + width)
    return re.sub(r"\s+", " ", text[a:b]).strip()


def extract_atoms(summary: str) -> list[Atom]:
    """Pull every checkable atom out of a candidate summary."""
    atoms: list[Atom] = []
    seen: set[tuple[str, str]] = set()

    for kind, pat in PATTERNS.items():
        for m in pat.finditer(summary):
            value = m.group(1) if m.groups() else m.group(0)
            key = (kind, value.lower())
            if key in seen:
                continue
            seen.add(key)
            atoms.append(Atom(kind, value, _context(summary, m)))

    # CVSS base scores. The vector string is masked out first, otherwise the
    # specification version in "CVSS:3.1/AV:N/..." is misread as a base score —
    # a false positive that would otherwise fire on almost every CVE summary.
    masked = CVSS_VECTOR.sub(lambda m: "#" * len(m.group(0)), summary)
    for m in CVSS_SCORE_CUE.finditer(masked):
        value = m.group(1)
        if not 0.0 <= float(value) <= 10.0:
            continue
        key = ("cvss_score", value)
        if key not in seen:
            seen.add(key)
            atoms.append(Atom("cvss_score", value, _context(summary, m)))

    for m in SEVERITY_CUE.finditer(masked):
        value = m.group(1) or m.group(2)
        if not value:
            continue
        key = ("severity", value.lower())
        if key not in seen:
            seen.add(key)
            atoms.append(Atom("severity", value, _context(summary, m)))

    for m in ENTITY_PAT.finditer(summary):
        value = m.group(0).strip()
        head = value.split()[0]
        if head in STOP_ENTITY or len(value) < 4:
            continue
        if m.start() == 0 or summary[max(0, m.start() - 2)] in ".!?":
            continue  # sentence-initial capitalisation is not evidence of an entity
        key = ("entity", value.lower())
        if key in seen:
            continue
        seen.add(key)
        atoms.append(Atom("entity", value, _context(summary, m)))

    return atoms


# --------------------------------------------------------------------------- #
# Grounding checker
# --------------------------------------------------------------------------- #

def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").lower()


def _metadata_expectations(item: CTIItem) -> dict[str, str]:
    md = item.metadata or {}
    exp = {}
    if md.get("cvss_score") is not None:
        exp["cvss_score"] = str(md["cvss_score"])
    if md.get("cvss_severity"):
        exp["severity"] = str(md["cvss_severity"]).lower()
    if md.get("cve_id"):
        exp["cve_id"] = str(md["cve_id"])
    if md.get("cwe"):
        exp["cwe_id"] = str(md["cwe"])
    return exp


def check_grounding(
    gen: Generation, item: CTIItem, min_entity_len: int = 5
) -> list[HallucinationFinding]:
    """Run the deterministic grounding checker over one generation."""
    findings: list[HallucinationFinding] = []
    if gen.error or not gen.summary.strip():
        return findings

    source_norm = _norm(item.source_text)
    reference_norm = _norm(item.reference_summary)
    combined = source_norm + " " + reference_norm
    expectations = _metadata_expectations(item)

    for atom in extract_atoms(gen.summary):
        value_norm = atom.value.lower()

        # 1. Metadata contradiction — the strongest possible intrinsic signal.
        if atom.kind in expectations and value_norm != expectations[atom.kind].lower():
            findings.append(
                HallucinationFinding(
                    item_id=item.item_id,
                    model_id=gen.model_id,
                    span=atom.value,
                    category="intrinsic",
                    subtype=SUBTYPE_BY_ATOM.get(atom.kind, "circumstantial_error"),
                    evidence=(
                        f"summary states {atom.kind}={atom.value!r}; "
                        f"record states {expectations[atom.kind]!r}"
                    ),
                    detector="grounding",
                    confidence=0.98,
                )
            )
            continue

        if value_norm in combined:
            continue  # grounded

        # 2. Same identifier family present but a different value → intrinsic.
        if atom.kind in PATTERNS:
            others = {
                m.group(1) if m.groups() else m.group(0)
                for m in PATTERNS[atom.kind].finditer(item.source_text)
            }
            if others:
                findings.append(
                    HallucinationFinding(
                        item_id=item.item_id,
                        model_id=gen.model_id,
                        span=atom.value,
                        category="intrinsic",
                        subtype=SUBTYPE_BY_ATOM.get(atom.kind, "entity_error"),
                        evidence=(
                            f"{atom.kind} {atom.value!r} not in source; source "
                            f"contains {sorted(others)[:3]}"
                        ),
                        detector="grounding",
                        confidence=0.9,
                    )
                )
                continue

        # 3. No basis at all → extrinsic.
        if atom.kind == "entity":
            if len(atom.value) < min_entity_len:
                continue
            # Tolerate morphological variation and partial-name shortening.
            head = atom.value.split()[0].lower()
            if head in combined:
                continue
        findings.append(
            HallucinationFinding(
                item_id=item.item_id,
                model_id=gen.model_id,
                span=atom.value,
                category="extrinsic",
                subtype="fabrication"
                if atom.kind == "entity"
                else SUBTYPE_BY_ATOM.get(atom.kind, "circumstantial_error"),
                evidence=f"{atom.kind} {atom.value!r} has no antecedent in the source",
                detector="grounding",
                confidence=0.75,
            )
        )

    # 4. High-consequence claims asserted without source support.
    for name, pat in RISK_CLAIMS.items():
        m = pat.search(gen.summary)
        if not m:
            continue
        if pat.search(item.source_text) or pat.search(item.reference_summary or ""):
            continue
        findings.append(
            HallucinationFinding(
                item_id=item.item_id,
                model_id=gen.model_id,
                span=m.group(0),
                category="extrinsic",
                subtype="fabrication",
                evidence=f"operationally significant claim ({name}) absent from source",
                detector="grounding",
                confidence=0.85,
            )
        )

    # 5. Polarity inversion — correct entities, inverted relationship.
    for positive, negative in POLARITY_PAIRS:
        in_sum_pos, in_sum_neg = positive in _norm(gen.summary), negative in _norm(gen.summary)
        in_src_pos, in_src_neg = positive in source_norm, negative in source_norm
        if in_sum_neg and in_src_pos and not in_src_neg:
            findings.append(
                HallucinationFinding(
                    item_id=item.item_id,
                    model_id=gen.model_id,
                    span=negative,
                    category="intrinsic",
                    subtype="relational_error",
                    evidence=f"source asserts {positive!r}; summary asserts {negative!r}",
                    detector="grounding",
                    confidence=0.8,
                )
            )
        elif in_sum_pos and in_src_neg and not in_src_pos:
            findings.append(
                HallucinationFinding(
                    item_id=item.item_id,
                    model_id=gen.model_id,
                    span=positive,
                    category="intrinsic",
                    subtype="relational_error",
                    evidence=f"source asserts {negative!r}; summary asserts {positive!r}",
                    detector="grounding",
                    confidence=0.8,
                )
            )
    return _dedupe(findings)


def _dedupe(findings: list[HallucinationFinding]) -> list[HallucinationFinding]:
    seen, out = set(), []
    for f in findings:
        key = (f.item_id, f.model_id, f.span.lower(), f.subtype)
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out


# --------------------------------------------------------------------------- #
# LLM-as-judge
# --------------------------------------------------------------------------- #

JUDGE_SYSTEM = (
    "You are a meticulous fact-checker for cyber threat intelligence. You "
    "compare a candidate summary against its source and report only errors that "
    "you can point to in the text. You output JSON and nothing else."
)

JUDGE_TEMPLATE = """Compare the CANDIDATE SUMMARY against the SOURCE.

Report every factual error. For each, decide:
- category: "intrinsic" if it contradicts the source, "extrinsic" if it adds a
  claim the source does not support.
- subtype: one of entity_error, relational_error, circumstantial_error, fabrication.

SOURCE:
\"\"\"
{source}
\"\"\"

CANDIDATE SUMMARY:
\"\"\"
{summary}
\"\"\"

Output JSON only, in exactly this shape:
{{"findings": [{{"span": "...", "category": "...", "subtype": "...", "evidence": "..."}}]}}
If there are no errors, output {{"findings": []}}."""


def _extract_json(text: str) -> dict | None:
    """Pull the first complete JSON object out of a model reply.

    A greedy ``\{.*\}`` match spans from the first brace to the last one, so a
    reply containing prose after the JSON, or two objects, fails to parse. This
    walks the string and returns the first brace-balanced object instead,
    ignoring braces inside string literals.
    """
    text = (text or "").strip()
    if text.startswith("```"):  # strip a markdown fence if the model added one
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    start = text.find("{")
    while start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        obj = json.loads(text[start : i + 1])
                    except json.JSONDecodeError:
                        break
                    return obj if isinstance(obj, dict) else None
        start = text.find("{", start + 1)
    return None


def judge_with_llm(gen: Generation, item: CTIItem, provider) -> list[HallucinationFinding]:  # noqa: ANN001
    """Adjudicate one summary with an LLM judge."""
    if gen.error or not gen.summary.strip():
        return []
    out = provider.complete(
        JUDGE_SYSTEM,
        JUDGE_TEMPLATE.format(source=item.source_text, summary=gen.summary),
        temperature=0.0,
        max_tokens=800,
    )
    if out.error:
        return []
    data = _extract_json(out.text)
    if data is None:
        return []

    findings = []
    for f in data.get("findings", []):
        subtype = f.get("subtype", "fabrication")
        findings.append(
            HallucinationFinding(
                item_id=item.item_id,
                model_id=gen.model_id,
                span=str(f.get("span", ""))[:200],
                category="intrinsic"
                if f.get("category") == "intrinsic"
                else "extrinsic",
                subtype=subtype
                if subtype in ("entity_error", "relational_error", "circumstantial_error", "fabrication")
                else "fabrication",
                evidence=str(f.get("evidence", ""))[:400],
                detector="llm_judge",
                confidence=0.7,
            )
        )
    return findings


# --------------------------------------------------------------------------- #
# SelfCheckGPT-style consistency
# --------------------------------------------------------------------------- #

def selfcheck_score(gen: Generation) -> float | None:
    """Mean sentence-level disagreement across stochastic resamples.

    Returns a value in [0, 1] where higher means *less* consistent, i.e. more
    likely to be fabricated. ``None`` when no samples were collected.
    """
    if not gen.samples:
        return None
    from .metrics import tokenise

    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", gen.summary) if s.strip()]
    if not sentences:
        return None
    sample_tokens = [set(tokenise(s)) for s in gen.samples]

    scores = []
    for sent in sentences:
        toks = set(tokenise(sent))
        if not toks:
            continue
        overlaps = [len(toks & st) / len(toks) for st in sample_tokens]
        scores.append(1.0 - (sum(overlaps) / len(overlaps)))
    return float(sum(scores) / len(scores)) if scores else None


# --------------------------------------------------------------------------- #
# Detector validation
# --------------------------------------------------------------------------- #

def validate_detector(
    findings: list[HallucinationFinding],
    injected: list[dict],
    item_id_by_source_key: dict[str, str] | None = None,
) -> dict[str, float]:
    """Precision / recall / F1 of the grounding checker against seeded errors.

    Findings are matched on ``(item_id, model_id, span)`` triples, so an error
    seeded into one summary is not credited to an identical span in a different
    one. Matching on span strings alone pools every occurrence across the corpus
    into a single set entry and inflates precision — on a 270-generation dry run
    the two methods differed by a factor of five (0.765 against 0.160).

    ``item_id_by_source_key`` maps :func:`ctieval.providers.mock.source_key`
    output to ``item_id``; build it from the corpus. Without it the injected
    records cannot be tied to items, so the function reports the degraded
    span-set figure and says so in ``method``.
    """
    seeded = [inj for inj in injected if inj.get("span")]
    if not seeded:
        return {
            "method": "no seeded errors",
            "precision": float("nan"),
            "recall": float("nan"),
            "f1": float("nan"),
            "n_injected": 0,
            "n_detected": len(findings),
        }

    can_pair = item_id_by_source_key is not None and all(
        inj.get("source_key") and inj.get("model_id") for inj in seeded
    )
    if can_pair:
        method = "per (item_id, model_id, span)"
        truth = {
            (
                item_id_by_source_key.get(inj["source_key"], "?"),
                inj["model_id"],
                (inj["span"] or "").lower(),
            )
            for inj in seeded
        }
        detected = {(f.item_id, f.model_id, (f.span or "").lower()) for f in findings}
    else:
        method = "span sets (degraded: injected records carry no item identity)"
        truth = {(inj["span"] or "").lower() for inj in seeded}
        detected = {(f.span or "").lower() for f in findings}

    tp = len(detected & truth)
    fp = len(detected - truth)
    fn = len(truth - detected)
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return {
        "method": method,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "true_positives": tp,
        "false_positives": fp,
        "false_negatives": fn,
        "n_injected": len(truth),
        "n_detected": len(detected),
    }
