"""Command-line interface.

    python -m ctieval preflight                 # check every backend is reachable
    python -m ctieval collect --source all      # build the corpus
    python -m ctieval annotate --export         # write reference-summary worksheet
    python -m ctieval annotate --import file    # merge authored summaries back
    python -m ctieval run                       # generate summaries
    python -m ctieval score                     # ROUGE / BERTScore / statistics
    python -m ctieval detect                    # hallucination detection
    python -m ctieval adjudicate --export f.csv # review detector findings
    python -m ctieval adjudicate --import f.csv # merge confirmations back
    python -m ctieval humaneval build           # blinded rater workbook
    python -m ctieval humaneval analyse ...     # kappa / ICC / per-model scores
    python -m ctieval report                    # figures, tables, results_pack.md
    python -m ctieval demo                      # full offline dry run
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

from .config import Config
from .schema import (
    HALLUCINATION_CLASSES,
    CTIItem,
    load_corpus,
    load_generations,
    read_jsonl,
    write_jsonl,
)


# --------------------------------------------------------------------------- #
def _provenance(corpus: list[CTIItem], path: Path) -> None:
    rows = [
        {
            "item_id": i.item_id,
            "source_type": i.source_type,
            "title": i.title,
            "source": (i.metadata or {}).get("source", ""),
            "retrieved_at": (i.metadata or {}).get("retrieved_at", ""),
            "source_sha256": i.source_sha256,
            "source_words": len(i.source_text.split()),
            "reference_words": len(i.reference_summary.split()),
            "synthetic": bool((i.metadata or {}).get("synthetic", False)),
        }
        for i in corpus
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False)


def cmd_collect(args, cfg: Config) -> int:
    from .collectors._http import CollectorError

    items: list[CTIItem] = []
    src = args.source

    try:
        if src in ("nvd", "all"):
            from .collectors import nvd

            print("Collecting CVE records from NVD…")
            items += nvd.collect(
                n_per_severity=args.n_cve // 3 or 10, days_back=args.days_back
            )
        if src in ("otx", "all"):
            from .collectors import otx

            print("Collecting OTX pulses…")
            items += otx.collect(days=args.otx_days, max_items=args.n_otx)
        if src in ("apt", "all"):
            from .collectors import apt_pdf

            print(f"Parsing APT report PDFs from {args.pdf_dir}…")
            items += apt_pdf.collect(
                args.pdf_dir,
                min_words=args.apt_min_words,
                max_per_report=args.apt_max_sections,
                require_reference=not args.allow_unreferenced,
                share_executive_summary=args.share_executive_summary,
            )
        if src == "offline":
            from .collectors import offline

            print("Generating offline synthetic corpus (DRY RUN ONLY)…")
            items += offline.collect(
                seed=cfg.seed,
                n_cve=args.n_cve,
                n_otx=args.n_otx,
                n_apt=args.n_apt,
            )
    except CollectorError as exc:
        print(f"\nCollection failed: {exc}", file=sys.stderr)
        return 2
    except FileNotFoundError as exc:
        print(f"\nCollection failed: {exc}", file=sys.stderr)
        return 2

    if not items:
        print("No items collected.", file=sys.stderr)
        return 1

    out = cfg.path("corpus")
    if args.append and out.exists():
        existing = load_corpus(out)
        seen = {i.item_id for i in existing}
        items = existing + [i for i in items if i.item_id not in seen]

    n = write_jsonl(out, items)
    _provenance(items, cfg.path("provenance"))
    pending = sum(1 for i in items if not i.reference_summary.strip())
    print(f"Wrote {n} items → {out}")
    print(f"Provenance registry → {cfg.path('provenance')}")
    if pending:
        print(
            f"{pending} items have no reference summary yet. "
            "Run `python -m ctieval annotate --export` next."
        )
    return 0


def cmd_annotate(args, cfg: Config) -> int:
    corpus = load_corpus(cfg.path("corpus"))
    work = Path(args.file or "data/reference_summaries.csv")

    if args.export:
        rows = [
            {
                "item_id": i.item_id,
                "source_type": i.source_type,
                "title": i.title,
                "SOURCE_TEXT": i.source_text,
                "reference_summary": i.reference_summary,
            }
            for i in corpus
            if not i.reference_summary.strip() or args.all
        ]
        work.parent.mkdir(parents=True, exist_ok=True)
        columns = ["item_id", "source_type", "title", "SOURCE_TEXT", "reference_summary"]
        # Always write the header row. An empty frame with no columns produces a
        # zero-byte file that crashes pandas on re-import.
        pd.DataFrame(rows, columns=columns).to_csv(work, index=False)
        if not rows:
            print(
                f"No items are awaiting reference summaries. Wrote an empty "
                f"worksheet (header only) → {work}\n"
                "Use --all to export every item, including those already referenced."
            )
            return 0
        print(f"Exported {len(rows)} items awaiting reference summaries → {work}")
        print(
            "Write a 60–120 word analyst summary in the 'reference_summary' "
            "column, have a second practitioner review it, then re-import."
        )
        return 0

    if args.import_file:
        try:
            df = pd.read_csv(args.import_file)
        except pd.errors.EmptyDataError:
            print(
                f"{args.import_file} is empty — nothing to import.", file=sys.stderr
            )
            return 1
        if "reference_summary" not in df.columns or "item_id" not in df.columns:
            print(
                f"{args.import_file} must contain 'item_id' and "
                "'reference_summary' columns.",
                file=sys.stderr,
            )
            return 1
        mapping = {
            str(r.item_id): str(r.reference_summary)
            for r in df.itertuples()
            if isinstance(r.reference_summary, str) and r.reference_summary.strip()
        }
        merged, updated = [], 0
        for item in corpus:
            if item.item_id in mapping:
                item.reference_summary = mapping[item.item_id].strip()
                item.metadata["needs_reference_summary"] = False
                item.metadata["reference_source"] = "researcher_authored"
                updated += 1
            merged.append(item)
        write_jsonl(cfg.path("corpus"), merged)
        print(f"Updated {updated} reference summaries → {cfg.path('corpus')}")
        return 0

    print("Specify --export or --import <file>.", file=sys.stderr)
    return 1


def cmd_preflight(args, cfg: Config) -> int:
    from .runner import preflight

    return 0 if preflight(cfg) else 2


def cmd_run(args, cfg: Config) -> int:
    from .runner import run_experiment

    corpus = load_corpus(cfg.path("corpus"))
    if getattr(args, "limit", None):
        # Smoke test: take the first N items, keeping source-type variety by
        # interleaving rather than taking a single block of one type.
        by_type: dict[str, list] = {}
        for item in corpus:
            by_type.setdefault(item.source_type, []).append(item)
        interleaved, idx = [], 0
        while len(interleaved) < args.limit and any(
            idx < len(v) for v in by_type.values()
        ):
            for v in by_type.values():
                if idx < len(v) and len(interleaved) < args.limit:
                    interleaved.append(v[idx])
            idx += 1
        corpus = interleaved
        print(f"--limit {args.limit}: running on {len(corpus)} items only (smoke test).")

    missing = [i.item_id for i in corpus if not i.reference_summary.strip()]
    if missing and not args.allow_unreferenced:
        print(
            f"{len(missing)} items still lack a reference summary "
            f"(e.g. {missing[:3]}). Complete annotation first, or pass "
            "--allow-unreferenced to generate anyway.",
            file=sys.stderr,
        )
        return 1
    models = [cfg.model(m) for m in args.models] if args.models else None
    run_experiment(
        corpus,
        cfg,
        cfg.path("generations"),
        models=models,
        prompt_id=args.prompt,
        resume=not args.no_resume,
    )
    return 0


def cmd_score(args, cfg: Config) -> int:
    from .metrics import BERTScoreUnavailable, compare_models, score_all

    corpus = {i.item_id: i for i in load_corpus(cfg.path("corpus"))}
    gens = load_generations(cfg.path("generations"))
    try:
        df = score_all(
            gens,
            corpus,
            cfg.bertscore_model,
            allow_semantic_fallback=getattr(args, "allow_semantic_fallback", False),
            bertscore_num_layers=cfg.bertscore_num_layers,
        )
    except BERTScoreUnavailable as exc:
        print(f"\n{exc}", file=sys.stderr)
        return 3
    if df.empty:
        print("No scorable generations found.", file=sys.stderr)
        return 1
    out = cfg.path("metrics")
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(f"Scored {len(df)} generations → {out}")

    sem = df["semantic_metric"].iloc[0]
    print("\nMean scores by model:")
    cols = [c for c in ["rouge1_f", "rouge2_f", "rougeL_f", sem] if c in df.columns]
    print(df.groupby("model_label")[cols].mean().round(4).to_string())

    for metric in ["rougeL_f", sem]:
        if metric not in df.columns:
            continue
        tbl, omni = compare_models(df, metric, cfg.alpha)
        if not tbl.empty:
            print(f"\nPairwise Wilcoxon ({metric}):")
            print(tbl[["model_a", "model_b", "median_a", "median_b",
                       "p_holm", "rank_biserial_r", "significant"]].to_string(index=False))
    return 0


def cmd_detect(args, cfg: Config) -> int:
    from .hallucination import check_grounding, judge_with_llm, selfcheck_score

    corpus = {i.item_id: i for i in load_corpus(cfg.path("corpus"))}
    gens = load_generations(cfg.path("generations"))

    findings = []
    for g in gens:
        item = corpus.get(g.item_id)
        if item is None:
            continue
        findings += check_grounding(g, item)

    if args.judge:
        from .providers import get_provider

        judge = get_provider(cfg.model(args.judge))
        print(f"Running LLM judge ({args.judge}) over {len(gens)} summaries…")
        for n, g in enumerate(gens, 1):
            item = corpus.get(g.item_id)
            if item:
                findings += judge_with_llm(g, item, judge)
            if n % 10 == 0:
                print(f"  judged {n}/{len(gens)}")

    rows = [f.to_dict() for f in findings]
    label_by_id = {g.model_id: g.model_label for g in gens}
    for r in rows:
        r["model_label"] = label_by_id.get(r["model_id"], r["model_id"])

    out = cfg.path("hallucinations")
    write_jsonl(out, rows)
    print(f"Wrote {len(rows)} findings → {out}")

    # Validate the checker against errors seeded by a test-harness provider,
    # if this corpus was generated by one. Written to disk so `report` can fill
    # the Table 6.5 slot without re-deriving it.
    inj_path = cfg.path("generations")
    inj_path = inj_path.with_name(inj_path.stem + ".injected.jsonl")
    if inj_path.exists():
        from .hallucination import validate_detector
        from .providers.mock import source_key

        injected = list(read_jsonl(inj_path))
        key_to_item = {source_key(i.source_text): i.item_id for i in corpus.values()}
        validation = validate_detector(findings, injected, key_to_item)
        pd.DataFrame([validation]).to_csv(
            out.with_name("detector_validation.csv"), index=False
        )
        print(
            f"Detector validation ({validation['method']}): "
            f"precision {validation['precision']}, recall {validation['recall']}, "
            f"F1 {validation['f1']} over {validation['n_injected']} seeded errors "
            f"→ detector_validation.csv"
        )

    sc = {g.item_id: selfcheck_score(g) for g in gens if g.samples}
    if sc:
        pd.DataFrame(
            [{"item_id": k, "selfcheck_inconsistency": v} for k, v in sc.items()]
        ).to_csv(out.with_name("selfcheck_scores.csv"), index=False)
        print(f"SelfCheck scores for {len(sc)} summaries → selfcheck_scores.csv")

    if rows:
        df = pd.DataFrame(rows)
        print("\nFindings by model and category:")
        print(pd.crosstab(df["model_label"], df["category"]).to_string())
        print("\nFindings by subtype:")
        print(df["subtype"].value_counts().to_string())
        print(
            "\nThese are detector CANDIDATES, not confirmed hallucinations. Run "
            "`ctieval adjudicate --export findings.csv`, review them, then "
            "`--import` before quoting a rate."
        )
    return 0


ADJUDICATION_GUIDE = [
    "ADJUDICATION WORKSHEET - confirm or reject each detector finding.",
    "",
    "Put TRUE in 'confirmed' if the span really is a factual error against the",
    "source; FALSE if the detector was wrong. Leave blank to defer.",
    "",
    "Correct the 'category' (intrinsic|extrinsic) and 'subtype' (entity_error|",
    "relational_error|circumstantial_error|fabrication) where the detector",
    "classified a real error under the wrong heading.",
    "",
    "Rates computed from confirmed findings are the reportable ones. The",
    "detector's raw output is reported separately, as detector performance.",
]


def cmd_adjudicate(args, cfg: Config) -> int:
    """Export detector findings for human review, and merge the verdicts back.

    Detection produces candidates. Until a person has confirmed or rejected each
    one, the only defensible figure is a detector-flagged rate. This is the
    stage that turns candidates into findings.
    """
    path = cfg.path("hallucinations")
    if not path.exists():
        print(f"{path} not found — run `ctieval detect` first.", file=sys.stderr)
        return 1
    rows = list(read_jsonl(path))
    if not rows:
        print("No findings to adjudicate.")
        return 0

    work = Path(args.file or args.export or args.import_file or "results/adjudication.csv")

    if args.export:
        cols = ["finding_id", "item_id", "model_label", "detector", "span",
                "category", "subtype", "confidence", "evidence", "confirmed", "notes"]
        out = []
        for n, r in enumerate(rows):
            rec = {c: r.get(c, "") for c in cols}
            rec["finding_id"] = r.get("finding_id") or f"F{n:05d}"
            rec["confirmed"] = "" if r.get("confirmed") is None else r["confirmed"]
            rec["notes"] = r.get("notes", "")
            out.append(rec)
        work.parent.mkdir(parents=True, exist_ok=True)
        with work.open("w", encoding="utf-8") as fh:
            for line in ADJUDICATION_GUIDE:
                fh.write(f"# {line}\n")
        pd.DataFrame(out, columns=cols).to_csv(work, mode="a", index=False)
        # Stamp ids back onto the corpus of findings so the merge can match.
        for n, r in enumerate(rows):
            r.setdefault("finding_id", f"F{n:05d}")
        write_jsonl(path, rows)
        print(f"Exported {len(out)} findings for review → {work}")
        print("Set 'confirmed' to TRUE or FALSE on each row, then re-import.")
        return 0

    if args.import_file:
        try:
            df = pd.read_csv(args.import_file, comment="#")
        except pd.errors.EmptyDataError:
            print(f"{args.import_file} is empty.", file=sys.stderr)
            return 1
        if "finding_id" not in df.columns or "confirmed" not in df.columns:
            print(
                f"{args.import_file} must contain 'finding_id' and 'confirmed'.",
                file=sys.stderr,
            )
            return 1

        def as_bool(v):
            if isinstance(v, bool):
                return v
            s = str(v).strip().lower()
            if s in ("true", "t", "yes", "y", "1"):
                return True
            if s in ("false", "f", "no", "n", "0"):
                return False
            return None

        verdicts = {str(r.finding_id): as_bool(r.confirmed) for r in df.itertuples()}
        overrides = {
            str(r.finding_id): (getattr(r, "category", None), getattr(r, "subtype", None))
            for r in df.itertuples()
        }
        merged, reviewed = [], 0
        for n, r in enumerate(rows):
            fid = r.get("finding_id") or f"F{n:05d}"
            r["finding_id"] = fid
            if fid in verdicts and verdicts[fid] is not None:
                r["confirmed"] = verdicts[fid]
                cat, sub = overrides.get(fid, (None, None))
                if isinstance(cat, str) and cat in ("intrinsic", "extrinsic"):
                    r["category"] = cat
                if isinstance(sub, str) and sub in HALLUCINATION_CLASSES:
                    r["subtype"] = sub
                reviewed += 1
            merged.append(r)
        write_jsonl(path, merged)
        confirmed = sum(1 for r in merged if r.get("confirmed") is True)
        rejected = sum(1 for r in merged if r.get("confirmed") is False)
        print(f"Merged {reviewed} verdicts → {path}")
        print(f"  confirmed {confirmed}, rejected {rejected}, "
              f"outstanding {len(merged) - confirmed - rejected}")
        if reviewed:
            print(f"  detector precision on the reviewed set: "
                  f"{confirmed / reviewed:.3f}")
        return 0

    print("Specify --export <file> or --import <file>.", file=sys.stderr)
    return 1


def cmd_humaneval(args, cfg: Config) -> int:
    from .humaneval import analyse, build_sheet

    if args.action == "build":
        corpus = {i.item_id: i for i in load_corpus(cfg.path("corpus"))}
        gens = load_generations(cfg.path("generations"))
        sheet = cfg.path("human_sheet")
        key = sheet.with_name("human_eval_key.csv")
        df = build_sheet(gens, corpus, sheet, key, items_per_source_type=args.n)
        print(
            f"Wrote blinded rater workbook → {sheet}\n"
            f"  {df.attrs['n_items_sampled']} corpus items "
            f"x {df.attrs['n_models']} models = {df.attrs['n_rows']} rows "
            f"({args.n} items per source type)\n"
            "  State these numbers in the methodology — the human-evaluation "
            "sample cannot be inferred from the flag alone."
        )
        print(f"Blinding key (do NOT send to raters) → {key}")
        return 0

    if args.action == "analyse":
        if not args.scores:
            print("Provide --scores rater1=path.csv --scores rater2=path.csv", file=sys.stderr)
            return 1
        files = dict(s.split("=", 1) for s in args.scores)
        key = cfg.path("human_sheet").with_name("human_eval_key.csv")
        long, per_model, agreement = analyse(files, key)
        long.to_csv(cfg.path("human_scores"), index=False)
        print(per_model.to_string(index=False))
        print("\nAgreement:", agreement)
        print(f"\nMerged scores → {cfg.path('human_scores')}")
        return 0
    return 1


def cmd_report(args, cfg: Config) -> int:
    from .metrics import compare_models
    from .report import build_results_pack

    corpus = load_corpus(cfg.path("corpus"))
    synthetic = any((i.metadata or {}).get("synthetic") for i in corpus)

    metrics_df = pd.read_csv(cfg.path("metrics"))
    halluc_path = cfg.path("hallucinations")
    halluc_df = (
        pd.DataFrame(list(read_jsonl(halluc_path))) if halluc_path.exists() else pd.DataFrame()
    )

    detector_validation = None
    val_path = halluc_path.with_name("detector_validation.csv")
    if val_path.exists():
        vrows = pd.read_csv(val_path).to_dict("records")
        detector_validation = vrows[0] if vrows else None

    selfcheck_df = None
    sc_path = halluc_path.with_name("selfcheck_scores.csv")
    if sc_path.exists():
        selfcheck_df = pd.read_csv(sc_path)
        if "model_label" not in selfcheck_df.columns:
            labels = metrics_df[["item_id", "model_label"]].drop_duplicates("item_id")
            selfcheck_df = selfcheck_df.merge(labels, on="item_id", how="left")

    sem = metrics_df["semantic_metric"].iloc[0]
    stats_tables, omnibus = {}, {}
    for metric in ["rouge1_f", "rougeL_f", sem]:
        if metric in metrics_df.columns:
            tbl, o = compare_models(metrics_df, metric, cfg.alpha)
            if not tbl.empty:
                stats_tables[metric] = tbl
                omnibus[metric] = o

    human = None
    if cfg.path("human_scores").exists():
        from .humaneval import DIMENSIONS

        long = pd.read_csv(cfg.path("human_scores"))
        per_model = (
            long.groupby(["model_label", "source_type"])[DIMENSIONS + ["composite"]]
            .mean()
            .round(3)
            .reset_index()
        )
        human = (long, per_model, {"note": "recomputed from merged scores"})

    path = build_results_pack(
        metrics_df,
        halluc_df,
        stats_tables,
        omnibus,
        cfg.path("report_dir"),
        synthetic=synthetic,
        human=human,
        detector_validation=detector_validation,
        selfcheck=selfcheck_df,
        alpha=cfg.alpha,
        allow_synthetic=args.allow_synthetic,
    )
    print(f"Results pack → {path}")
    print(f"Figures → {cfg.path('report_dir') / 'figures'}")
    return 0


DEMO_CONFIG = Path(__file__).resolve().parents[2] / "config" / "config.demo.yaml"


def _is_mock_only(cfg: Config) -> bool:
    return bool(cfg.models) and all(
        m.provider in ("mock", "dryrun") for m in cfg.models
    )


def cmd_demo(args, cfg: Config) -> int:
    """End-to-end offline dry run: no network, no API key, no GPU.

    The dry run writes a synthetic corpus over ``paths.corpus``. Under the real
    configuration that is the *experimental* corpus, and the models are the real
    backends — so an unqualified ``python -m ctieval demo`` used to overwrite a
    collected corpus and its provenance registry, then spend several minutes
    failing against live endpoints. The demo now switches itself to
    ``config/config.demo.yaml`` unless it was already given a mock-only config,
    and refuses to overwrite a corpus containing non-synthetic items.
    """
    if not _is_mock_only(cfg):
        if not DEMO_CONFIG.exists():
            print(
                f"The dry run needs a mock-only configuration and "
                f"{DEMO_CONFIG} is missing.",
                file=sys.stderr,
            )
            return 1
        print(f"Switching to the dry-run configuration: {DEMO_CONFIG}")
        print("(the demo never runs against real backends or the real corpus)")
        cfg = Config.load(DEMO_CONFIG)

    corpus_path = cfg.path("corpus")
    if corpus_path.exists():
        try:
            existing = load_corpus(corpus_path)
        except Exception:  # noqa: BLE001 - unreadable corpus is not a blocker here
            existing = []
        real = [i for i in existing if not (i.metadata or {}).get("synthetic")]
        if real and not args.force:
            print(
                f"Refusing to overwrite {corpus_path}: it holds {len(real)} "
                "non-synthetic items. The dry run would destroy collected data.\n"
                "Point paths.corpus somewhere else, or pass --force if you are "
                "certain the corpus is disposable.",
                file=sys.stderr,
            )
            return 1

    print("=" * 70)
    print("OFFLINE DRY RUN — synthetic corpus, mock provider.")
    print("Validates the pipeline. Produces no experimental result.")
    print("=" * 70)

    class NS:  # simple namespace for reused command handlers
        pass

    a = NS()
    a.source, a.append, a.n_cve, a.n_otx, a.n_apt = "offline", False, 12, 9, 9
    a.days_back, a.otx_days, a.pdf_dir, a.allow_unreferenced = 120, 30, "data/apt_pdfs", True
    a.apt_min_words, a.apt_max_sections = 250, 6
    a.share_executive_summary = False
    if cmd_collect(a, cfg):
        return 1

    from .runner import run_experiment

    corpus = load_corpus(cfg.path("corpus"))
    gen_path = cfg.path("generations")
    gen_path.parent.mkdir(parents=True, exist_ok=True)
    gen_path.write_text("", encoding="utf-8")  # truncate: unlink fails on some mounts
    run_experiment(corpus, cfg, gen_path, resume=False, progress=args.progress)

    a = NS()
    # The dry run has no BERTScore backbone by design, so the labelled proxy is
    # authorised here and nowhere else.
    a.allow_semantic_fallback = True
    if cmd_score(a, cfg):
        return 1
    a = NS()
    a.judge = None
    if cmd_detect(a, cfg):
        return 1
    a = NS()
    a.allow_synthetic = True
    print(
        "\nDry run complete. Every table and figure is watermarked and none of "
        "it is an experimental result."
    )
    return cmd_report(a, cfg)


# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="ctieval", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", default=None, help="path to config.yaml")
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("collect", help="build the evaluation corpus")
    c.add_argument("--source", choices=["nvd", "otx", "apt", "offline", "all"], default="all")
    c.add_argument("--n-cve", type=int, default=30)
    c.add_argument("--n-otx", type=int, default=30)
    c.add_argument("--n-apt", type=int, default=30,
                   help="offline corpus only; APT PDF count is set by the folder")
    c.add_argument("--days-back", type=int, default=120)
    c.add_argument("--otx-days", type=int, default=30)
    c.add_argument("--pdf-dir", default="data/apt_pdfs")
    c.add_argument("--apt-min-words", type=int, default=250)
    c.add_argument("--apt-max-sections", type=int, default=6)
    c.add_argument("--append", action="store_true")
    c.add_argument("--allow-unreferenced", action="store_true")
    c.add_argument(
        "--share-executive-summary",
        action="store_true",
        help="reuse a report's executive summary as the reference for its body "
             "sections (off by default: one summary shared across sections about "
             "different material makes ROUGE against it near-meaningless)",
    )
    c.set_defaults(func=cmd_collect)

    a = sub.add_parser("annotate", help="author reference summaries")
    a.add_argument("--export", action="store_true")
    a.add_argument("--import", dest="import_file")
    a.add_argument("--file")
    a.add_argument("--all", action="store_true")
    a.set_defaults(func=cmd_annotate)

    f = sub.add_parser("preflight", help="check model backends")
    f.set_defaults(func=cmd_preflight)

    r = sub.add_parser("run", help="generate summaries")
    r.add_argument("--models", nargs="*")
    r.add_argument("--prompt", default=None)
    r.add_argument("--limit", type=int, default=None,
                   help="run on only the first N items (smoke test)")
    r.add_argument("--no-resume", action="store_true")
    r.add_argument("--allow-unreferenced", action="store_true")
    r.set_defaults(func=cmd_run)

    s = sub.add_parser("score", help="automated metrics and statistics")
    s.add_argument(
        "--allow-semantic-fallback",
        action="store_true",
        help="record the labelled TF-IDF proxy when BERTScore cannot be "
             "computed, instead of failing. The proxy is NOT BERTScore.",
    )
    s.set_defaults(func=cmd_score)

    adj = sub.add_parser("adjudicate", help="review detector findings")
    adj.add_argument("--export", nargs="?", const="results/adjudication.csv")
    adj.add_argument("--import", dest="import_file")
    adj.add_argument("--file")
    adj.set_defaults(func=cmd_adjudicate)

    d = sub.add_parser("detect", help="hallucination detection")
    d.add_argument("--judge", default=None, help="model label to use as LLM judge")
    d.set_defaults(func=cmd_detect)

    h = sub.add_parser("humaneval", help="expert evaluation")
    h.add_argument("action", choices=["build", "analyse"])
    h.add_argument("--n", type=int, default=4,
                   help="corpus ITEMS sampled per source type; every model's "
                        "output for each is rated, so rows = n x types x models")
    h.add_argument("--scores", action="append")
    h.set_defaults(func=cmd_humaneval)

    rp = sub.add_parser("report", help="figures, tables, results pack")
    rp.add_argument("--allow-synthetic", action="store_true")
    rp.set_defaults(func=cmd_report)

    dm = sub.add_parser("demo", help="offline end-to-end dry run")
    dm.add_argument("--force", action="store_true",
                    help="overwrite a corpus that holds non-synthetic items")
    dm.add_argument("--progress", action="store_true", default=False,
                    help="print a per-generation progress line")
    dm.set_defaults(func=cmd_demo)

    args = p.parse_args(argv)
    cfg = Config.load(args.config)
    return args.func(args, cfg)


if __name__ == "__main__":
    raise SystemExit(main())
