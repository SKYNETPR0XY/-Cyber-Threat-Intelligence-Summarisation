"""Core data structures for the CTI summarisation evaluation framework.

Every stage of the pipeline reads and writes these objects, serialised as
JSON Lines, so that any stage can be re-run independently of the others.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable, Iterator

SOURCE_TYPES = ("cve", "otx", "apt")


@dataclass
class CTIItem:
    """A single ground-truth evaluation item.

    Attributes
    ----------
    item_id:
        Stable identifier, unique across the whole corpus.
    source_type:
        One of ``cve`` (structured NVD record), ``otx`` (AlienVault OTX pulse
        narrative) or ``apt`` (narrative APT / vendor threat report section).
    title:
        Short human-readable label used in tables and figures.
    source_text:
        The text presented to the model as input.
    reference_summary:
        The expert-authored ground-truth summary used as the evaluation target.
    metadata:
        Provenance and any structured facts used by the grounding checks
        (e.g. ``cvss_score``, ``cwe_id``, ``published``, ``retrieved_at``).
    """

    item_id: str
    source_type: str
    title: str
    source_text: str
    reference_summary: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.source_type not in SOURCE_TYPES:
            raise ValueError(
                f"source_type must be one of {SOURCE_TYPES}, got {self.source_type!r}"
            )

    @property
    def source_sha256(self) -> str:
        """Content hash, recorded in the provenance registry."""
        return hashlib.sha256(self.source_text.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["source_sha256"] = self.source_sha256
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "CTIItem":
        d = dict(d)
        d.pop("source_sha256", None)
        return cls(**d)


@dataclass
class Generation:
    """One summary produced by one model for one item."""

    item_id: str
    source_type: str
    model_id: str
    model_label: str
    summary: str
    prompt_id: str
    temperature: float
    input_chars: int
    output_chars: int
    input_tokens: int | None = None
    output_tokens: int | None = None
    latency_s: float | None = None
    cost_usd: float | None = None
    run_id: str = ""
    error: str | None = None
    samples: list[str] = field(default_factory=list)  # SelfCheckGPT stochastic samples

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Generation":
        return cls(**d)


# Ji et al. (2023) taxonomy, specialised to CTI in Section 5.3 of the dissertation.
HALLUCINATION_CLASSES = (
    "entity_error",  # wrong identifier / product / actor name
    "relational_error",  # correct entities, wrong relationship between them
    "circumstantial_error",  # wrong severity, version, date, count, condition
    "fabrication",  # claim with no basis whatsoever in the source
)


@dataclass
class HallucinationFinding:
    """A single classified error inside one generated summary."""

    item_id: str
    model_id: str
    span: str
    category: str  # "intrinsic" | "extrinsic"
    subtype: str  # one of HALLUCINATION_CLASSES
    evidence: str
    detector: str  # "grounding" | "llm_judge" | "selfcheck" | "manual"
    confidence: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------- #
# JSONL helpers
# --------------------------------------------------------------------------- #

def write_jsonl(path: str | Path, records: Iterable[Any]) -> int:
    """Write dataclass instances or dicts to JSON Lines. Returns the row count."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with path.open("w", encoding="utf-8") as fh:
        for rec in records:
            if hasattr(rec, "to_dict"):
                rec = rec.to_dict()
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1
    return n


def read_jsonl(path: str | Path) -> Iterator[dict[str, Any]]:
    """Stream a JSON Lines file as dicts."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found — run the earlier pipeline stage first."
        )
    with path.open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                yield json.loads(line)


def load_corpus(path: str | Path) -> list[CTIItem]:
    return [CTIItem.from_dict(d) for d in read_jsonl(path)]


def load_generations(path: str | Path) -> list[Generation]:
    return [Generation.from_dict(d) for d in read_jsonl(path)]
