"""Experiment runner.

Executes the summarisation experiment: every configured model over every corpus
item, under one controlled prompt, at a fixed temperature. Results are appended
to a JSONL file and the run is resumable — an interrupted run re-executes only
the (item, model) pairs that are missing, which matters when a 7B model on a
laptop CPU takes several seconds per item.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

from .config import Config, ModelConfig
from .prompts import SYSTEM_PROMPT, build_prompt
from .providers import get_provider
from .schema import CTIItem, Generation, read_jsonl


def _existing_keys(path: Path) -> set[tuple[str, str, str]]:
    if not path.exists():
        return set()
    keys = set()
    for row in read_jsonl(path):
        if row.get("error"):
            continue  # retry previously failed pairs
        keys.add((row["item_id"], row["model_id"], row.get("prompt_id", "")))
    return keys


def run_experiment(
    corpus: list[CTIItem],
    cfg: Config,
    out_path: Path,
    models: list[ModelConfig] | None = None,
    prompt_id: str | None = None,
    resume: bool = True,
    progress: bool = True,
) -> list[Generation]:
    """Generate one summary per (item, model). Returns the new generations."""
    models = models or cfg.models
    prompt_id = prompt_id or cfg.prompt_id
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    done = _existing_keys(out_path) if resume else set()
    todo = [
        (item, m)
        for m in models
        for item in corpus
        if (item.item_id, m.model_id, prompt_id) not in done
    ]
    total = len(todo)
    if total == 0:
        print("Nothing to do — all (item, model) pairs already present.")
        return []

    print(
        f"Running {total} generations: {len(corpus)} items × {len(models)} models "
        f"(prompt={prompt_id}, temp={cfg.temperature})"
    )

    providers = {m.model_id: get_provider(m) for m in models}
    new: list[Generation] = []
    t_start = time.perf_counter()

    with out_path.open("a", encoding="utf-8") as fh:
        import json

        for n, (item, mcfg) in enumerate(todo, start=1):
            provider = providers[mcfg.model_id]
            user = build_prompt(prompt_id, item.source_type, item.source_text)
            temperature = (
                mcfg.temperature if mcfg.temperature is not None else cfg.temperature
            )
            out = provider.complete(
                SYSTEM_PROMPT,
                user,
                temperature=temperature,
                max_tokens=mcfg.max_tokens or cfg.max_tokens,
            )

            samples: list[str] = []
            if cfg.selfcheck_samples > 0 and not out.error:
                for _ in range(cfg.selfcheck_samples):
                    s = provider.complete(
                        SYSTEM_PROMPT,
                        user,
                        temperature=cfg.selfcheck_temperature,
                        max_tokens=mcfg.max_tokens or cfg.max_tokens,
                    )
                    if not s.error:
                        samples.append(s.text)

            gen = Generation(
                item_id=item.item_id,
                source_type=item.source_type,
                model_id=mcfg.model_id,
                model_label=mcfg.label,
                summary=out.text,
                prompt_id=prompt_id,
                temperature=temperature,
                input_chars=len(user),
                output_chars=len(out.text),
                input_tokens=out.input_tokens,
                output_tokens=out.output_tokens,
                latency_s=round(out.latency_s, 3),
                cost_usd=out.cost_usd,
                run_id=cfg.run_id,
                error=out.error,
                samples=samples,
            )
            fh.write(json.dumps(gen.to_dict(), ensure_ascii=False) + "\n")
            fh.flush()  # crash-safe: never lose completed inference
            new.append(gen)

            if progress:
                elapsed = time.perf_counter() - t_start
                eta = elapsed / n * (total - n)
                flag = "ERR" if out.error else "ok "
                sys.stdout.write(
                    f"\r  [{n}/{total}] {flag} {mcfg.label:<18} "
                    f"{item.item_id[:34]:<34} "
                    f"{out.latency_s:5.1f}s  ETA {eta / 60:5.1f}m   "
                )
                sys.stdout.flush()
    if progress:
        print()

    # Test-harness providers inject labelled errors. Persist them beside the
    # generations so `detect` can validate the checker against ground truth that
    # is known by construction - the provider objects do not survive the stage.
    injected = [
        rec
        for p in providers.values()
        for rec in getattr(p, "injected", [])
    ]
    if injected:
        import json as _json

        inj_path = out_path.with_name(out_path.stem + ".injected.jsonl")
        with inj_path.open("w", encoding="utf-8") as fh:
            for rec in injected:
                fh.write(_json.dumps(rec, ensure_ascii=False) + "\n")
        print(f"Recorded {len(injected)} seeded errors -> {inj_path.name}")

    errors = [g for g in new if g.error]
    if errors:
        print(f"WARNING: {len(errors)}/{len(new)} generations failed.")
        seen = set()
        for g in errors:
            if g.model_label not in seen:
                seen.add(g.model_label)
                print(f"  {g.model_label}: {g.error}")
    return new


def preflight(cfg: Config) -> bool:
    """Check every configured backend before committing to a long run."""
    ok = True
    print("Pre-flight checks")
    for m in cfg.models:
        provider = get_provider(m)
        if hasattr(provider, "health_check"):
            healthy, msg = provider.health_check()
        else:
            out = provider.complete(
                "You are a test harness.",
                "Reply with the single word: ready",
                temperature=0.0,
                max_tokens=16,
            )
            healthy, msg = (out.error is None), (out.error or "reachable")
        print(f"  [{'PASS' if healthy else 'FAIL'}] {m.label:<20} {msg}")
        ok = ok and healthy
    return ok
