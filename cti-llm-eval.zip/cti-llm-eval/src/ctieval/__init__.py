"""ctieval — a reproducible evaluation framework for LLM summarisation of
cyber threat intelligence.

MSc Cyber Security and Forensics, University of Westminster.
"""

__version__ = "1.0.0"
