"""Human expert evaluation instrument.

Generates a **blinded** scoring workbook and analyses the returned scores.

Blinding matters: if a rater can see that a summary came from a commercial API
rather than a local 7B model, the model identity becomes a confound in the
rating. The workbook therefore exposes only an opaque ``eval_id``; the mapping
back to model identity is written to a separate key file that raters do not
receive.

Five dimensions are scored 1–5, matching the proposal:

1. **Factual accuracy** — are all stated facts correct with respect to the source?
2. **Completeness** — are the operationally important points present?
3. **Conciseness** — is it free of padding and repetition?
4. **Relevance** — is it pitched at what a SOC analyst needs?
5. **Absence of hallucination** — is it free of unsupported additions?

Agreement is reported as linearly-weighted Cohen's kappa (ordinal scale, so
disagreement of 1 point should not count the same as 4) plus a two-way
random-effects ICC(2,k) for the composite score.
"""

from __future__ import annotations

import hashlib
import random
from pathlib import Path

import numpy as np
import pandas as pd

DIMENSIONS = [
    "factual_accuracy",
    "completeness",
    "conciseness",
    "relevance",
    "absence_of_hallucination",
]

RATER_INSTRUCTIONS = [
    "SCORING INSTRUCTIONS — read before you begin.",
    "",
    "You are rating machine-generated summaries of cyber threat intelligence.",
    "The model that produced each summary is deliberately hidden from you.",
    "",
    "For each row, read SOURCE_TEXT, then REFERENCE_SUMMARY, then CANDIDATE_SUMMARY.",
    "Score the CANDIDATE on each dimension from 1 (very poor) to 5 (excellent).",
    "",
    "factual_accuracy         1 = multiple false statements; 5 = every statement supported by the source.",
    "completeness             1 = omits the central point; 5 = captures everything operationally important.",
    "conciseness              1 = padded or repetitive; 5 = no wasted words.",
    "relevance                1 = wrong audience or focus; 5 = exactly what a SOC analyst needs first.",
    "absence_of_hallucination 1 = invents entities or claims; 5 = adds nothing not in the source.",
    "",
    "Use the notes column for anything you flagged. Do not leave scores blank.",
    "Score every row independently; do not go back and adjust for consistency.",
]


def _eval_id(item_id: str, model_id: str, salt: str) -> str:
    h = hashlib.sha256(f"{salt}|{item_id}|{model_id}".encode()).hexdigest()
    return "E" + h[:10].upper()


def build_sheet(
    generations: list,
    corpus_by_id: dict,
    out_csv: str | Path,
    key_csv: str | Path,
    items_per_source_type: int = 4,
    salt: str = "cti-eval-2026",
    seed: int = 20260612,
) -> pd.DataFrame:
    """Sample a balanced, blinded subset and write the rater workbook + key.

    ``items_per_source_type`` counts **corpus items**, not rows. Every model's
    output for a sampled item is included, so the sheet holds
    ``items_per_source_type x n_source_types x n_models`` rows and the paired
    structure needed by the agreement statistics survives.

    The count of items sampled and rows written is returned on the frame as
    ``df.attrs`` and printed by the CLI, because the human-evaluation sample
    size has to be stated in the methodology and cannot be inferred from the
    flag alone.
    """
    rng = random.Random(seed)
    by_type: dict[str, list] = {}
    for g in generations:
        if g.error or g.item_id not in corpus_by_id:
            continue
        by_type.setdefault(g.source_type, []).append(g)

    selected = []
    for source_type, gens in by_type.items():
        # Sample items first, then take every model's output for those items, so
        # that raters see a matched set and paired tests remain valid.
        item_ids = sorted({g.item_id for g in gens})
        rng.shuffle(item_ids)
        take = min(len(item_ids), max(1, items_per_source_type))
        chosen = set(item_ids[:take])
        selected += [g for g in gens if g.item_id in chosen]

    rng.shuffle(selected)

    rows, key_rows = [], []
    for g in selected:
        item = corpus_by_id[g.item_id]
        eid = _eval_id(g.item_id, g.model_id, salt)
        rows.append(
            {
                "eval_id": eid,
                "source_type": g.source_type,
                "SOURCE_TEXT": item.source_text,
                "REFERENCE_SUMMARY": item.reference_summary,
                "CANDIDATE_SUMMARY": g.summary,
                **{d: "" for d in DIMENSIONS},
                "notes": "",
            }
        )
        key_rows.append(
            {
                "eval_id": eid,
                "item_id": g.item_id,
                "model_id": g.model_id,
                "model_label": g.model_label,
                "source_type": g.source_type,
            }
        )

    df = pd.DataFrame(rows)
    df.attrs["n_items_sampled"] = len({r["item_id"] for r in key_rows})
    df.attrs["n_rows"] = len(rows)
    df.attrs["n_models"] = len({r["model_id"] for r in key_rows})
    out_csv, key_csv = Path(out_csv), Path(key_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)

    with out_csv.open("w", encoding="utf-8") as fh:
        for line in RATER_INSTRUCTIONS:
            fh.write(f"# {line}\n")
    df.to_csv(out_csv, mode="a", index=False)
    pd.DataFrame(key_rows).to_csv(key_csv, index=False)
    return df


def read_scores(path: str | Path) -> pd.DataFrame:
    """Read a completed sheet, tolerating the leading comment block."""
    return pd.read_csv(path, comment="#")


def weighted_cohens_kappa(a: np.ndarray, b: np.ndarray, k: int = 5) -> float:
    """Linearly-weighted Cohen's kappa for ordinal ratings on 1..k."""
    a = np.asarray(a, int) - 1
    b = np.asarray(b, int) - 1
    mask = (a >= 0) & (a < k) & (b >= 0) & (b < k)
    a, b = a[mask], b[mask]
    if a.size == 0:
        return float("nan")

    obs = np.zeros((k, k))
    for i, j in zip(a, b):
        obs[i, j] += 1
    obs /= obs.sum()

    pa = obs.sum(axis=1)
    pb = obs.sum(axis=0)
    exp = np.outer(pa, pb)

    w = np.abs(np.subtract.outer(np.arange(k), np.arange(k))) / (k - 1)
    po = 1 - (w * obs).sum()
    pe = 1 - (w * exp).sum()
    return float((po - pe) / (1 - pe)) if pe != 1 else float("nan")


def icc2k(ratings: np.ndarray) -> float:
    """ICC(2,k): two-way random effects, absolute agreement, mean of k raters."""
    ratings = np.asarray(ratings, float)
    ratings = ratings[~np.isnan(ratings).any(axis=1)]
    n, k = ratings.shape
    if n < 2 or k < 2:
        return float("nan")

    grand = ratings.mean()
    ms_rows = k * ((ratings.mean(axis=1) - grand) ** 2).sum() / (n - 1)
    ms_cols = n * ((ratings.mean(axis=0) - grand) ** 2).sum() / (k - 1)
    resid = (
        ratings
        - ratings.mean(axis=1, keepdims=True)
        - ratings.mean(axis=0, keepdims=True)
        + grand
    )
    ms_err = (resid**2).sum() / ((n - 1) * (k - 1))
    denom = ms_rows + (ms_cols - ms_err) / n
    return float((ms_rows - ms_err) / denom) if denom else float("nan")


def analyse(
    score_files: dict[str, str | Path], key_csv: str | Path
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Merge rater sheets with the blinding key and compute agreement.

    Returns ``(long_scores, per_model_summary, agreement)``.
    """
    key = pd.read_csv(key_csv)
    frames = []
    for rater, path in score_files.items():
        df = read_scores(path)
        df["rater"] = rater
        frames.append(df[["eval_id", "rater", *DIMENSIONS, "notes"]])
    long = pd.concat(frames, ignore_index=True)
    long = long.merge(key, on="eval_id", how="left")
    long[DIMENSIONS] = long[DIMENSIONS].apply(pd.to_numeric, errors="coerce")
    long["composite"] = long[DIMENSIONS].mean(axis=1)

    per_model = (
        long.groupby(["model_label", "source_type"])[DIMENSIONS + ["composite"]]
        .agg(["mean", "std"])
        .round(3)
    )
    per_model.columns = [f"{a}_{b}" for a, b in per_model.columns]
    per_model = per_model.reset_index()

    agreement: dict = {}
    raters = sorted(long["rater"].unique())
    if len(raters) >= 2:
        for dim in DIMENSIONS + ["composite"]:
            wide = long.pivot_table(
                index="eval_id", columns="rater", values=dim, aggfunc="first"
            ).dropna()
            if wide.shape[0] < 2:
                continue
            if dim != "composite":
                pairs = [
                    weighted_cohens_kappa(
                        wide[r1].round().to_numpy(), wide[r2].round().to_numpy()
                    )
                    for i, r1 in enumerate(raters)
                    for r2 in raters[i + 1 :]
                    if r1 in wide and r2 in wide
                ]
                agreement[f"kappa_w_{dim}"] = (
                    round(float(np.nanmean(pairs)), 4) if pairs else float("nan")
                )
            else:
                agreement["icc2k_composite"] = round(icc2k(wide.to_numpy()), 4)
        agreement["n_double_rated"] = int(
            long.pivot_table(
                index="eval_id", columns="rater", values="composite", aggfunc="first"
            )
            .dropna()
            .shape[0]
        )
    return long, per_model, agreement
