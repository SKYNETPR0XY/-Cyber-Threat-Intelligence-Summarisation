"""Prompt templates.

A single unified template is applied to every model so that cross-model
differences cannot be attributed to prompt variation (the control described in
Section 5.4 of the dissertation). The mitigation variants (``*_cot``,
``*_grounded``) are used only in the RQ2 mitigation sub-experiment, where the
prompt is the deliberately manipulated variable.
"""

from __future__ import annotations

SYSTEM_PROMPT = (
    "You are a cyber threat intelligence analyst working in a Security "
    "Operations Centre. You write concise, factually precise summaries of "
    "threat intelligence for other analysts. You never introduce information "
    "that is not present in the source material."
)

_BASE = """Summarise the following {label} for a SOC analyst.

Requirements:
- Between 60 and 120 words, in continuous prose (no bullet points, no headings).
- State what the threat is, what it affects, and why it matters operationally.
- Preserve every identifier exactly as written in the source (CVE IDs, CWE IDs,
  CVSS scores, product names, version numbers, threat actor names).
- Include no information that is not stated in the source.

SOURCE:
\"\"\"
{source}
\"\"\"

SUMMARY:"""

_COT_SUFFIX = """

Before writing, work through these steps silently:
1. List the identifiers that appear verbatim in the source.
2. List the claims the source actually makes about them.
3. Discard anything you know from elsewhere that the source does not state.
Then write only the final summary, with no preamble and no working."""

_GROUNDED_SUFFIX = """

Every factual claim in your summary must be traceable to a specific phrase in
the SOURCE above. If the source does not state something, omit it rather than
inferring it. Where the source is silent on impact or exploitation status, say
nothing about it."""

SOURCE_LABELS = {
    "cve": "vulnerability record",
    "otx": "threat intelligence pulse",
    "apt": "threat report extract",
}

PROMPTS: dict[str, str] = {
    "cti_summary_v1": _BASE,
    "cti_summary_v1_cot": _BASE + _COT_SUFFIX,
    "cti_summary_v1_grounded": _BASE + _GROUNDED_SUFFIX,
}


def build_prompt(prompt_id: str, source_type: str, source_text: str) -> str:
    """Render the user-turn prompt for one item."""
    if prompt_id not in PROMPTS:
        raise KeyError(
            f"Unknown prompt_id {prompt_id!r}; available: {sorted(PROMPTS)}"
        )
    label = SOURCE_LABELS.get(source_type, "threat intelligence record")
    return PROMPTS[prompt_id].format(label=label, source=source_text.strip())
