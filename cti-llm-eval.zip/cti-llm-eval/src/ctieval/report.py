"""Reporting layer.

Turns the analysis dataframes into (a) publication-quality figures, (b) tables
in Markdown, and (c) ``results_pack.md`` — a drop-in fragment for Chapter 6 of
the dissertation with every number populated from the actual run.

Integrity guard
---------------
If any corpus item carries ``metadata["synthetic"] = True``, every figure is
watermarked ``DRY RUN — SYNTHETIC DATA`` and every table is preceded by a
warning banner. Generating a results pack from a synthetic corpus requires
``allow_synthetic=True`` to be passed explicitly. This makes it structurally
difficult to submit dry-run output as an experimental finding.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

PALETTE = ["#2b5797", "#c0504d", "#4f8a3d", "#7b5aa6", "#c9820b"]
WATERMARK = "DRY RUN — SYNTHETIC DATA — NOT AN EXPERIMENTAL RESULT"

# Axis labels. Derived labels were previously produced with
# ``name.replace("_f", "").upper()``, which strips the "_f" from the *middle* of
# "bertscore_f1" and renders it "BERTSCORE1".
METRIC_LABELS = {
    "rouge1_f": "ROUGE-1",
    "rouge2_f": "ROUGE-2",
    "rougeL_f": "ROUGE-L",
    "bertscore_f1": "BERTScore F1",
    "semantic_sim_tfidf": "TF-IDF proxy\n(not BERTScore)",
}
SUBTYPES = ("entity_error", "relational_error", "circumstantial_error", "fabrication")


def metric_label(name: str) -> str:
    return METRIC_LABELS.get(name, name.replace("_", " "))


def short_label(model_label: str, width: int = 22) -> str:
    """Compact model name for a tick label, without losing what it names."""
    s = str(model_label)
    if len(s) <= width:
        return s
    # Prefer dropping a trailing parenthetical ("Stand-in A (proxies …)" ->
    # "Stand-in A") over cutting mid-word; the full label stays in the tables.
    head = s.split("(", 1)[0].strip()
    if head and len(head) <= width:
        return head
    return s[: width - 1] + "\u2026"

plt.rcParams.update(
    {
        "figure.dpi": 150,
        "savefig.dpi": 300,  # thesis figures are reproduced at 300 dpi
        "font.size": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linestyle": ":",
        "figure.autolayout": True,
    }
)


def _watermark(fig, on: bool) -> None:
    """Label a figure built from a synthetic corpus so it cannot be read as a result.

    The label sits in the lower-right margin, outside the data area, so the
    chart stays legible; it is deliberately not removable by configuration."""
    if on:
        fig.text(
            0.995,
            -0.02,
            WATERMARK,
            ha="right",
            va="top",
            fontsize=7,
            color="#B03030",
            alpha=0.9,
            style="italic",
            transform=fig.transFigure,
        )


def _save(fig, path: Path, synthetic: bool) -> Path:
    _watermark(fig, synthetic)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #

def fig_metric_bars(df: pd.DataFrame, out: Path, synthetic: bool) -> Path:
    sem = df["semantic_metric"].iloc[0] if "semantic_metric" in df else None
    metrics = ["rouge1_f", "rouge2_f", "rougeL_f"] + (
        [sem] if sem and sem in df.columns else []
    )
    models = sorted(df["model_label"].unique())
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    width = 0.8 / len(models)
    x = np.arange(len(metrics))
    for i, m in enumerate(models):
        sub = df[df["model_label"] == m]
        means = [sub[k].mean() for k in metrics]
        errs = [sub[k].std() / max(1, np.sqrt(sub[k].notna().sum())) for k in metrics]
        ax.bar(
            x + i * width - 0.4 + width / 2,
            means,
            width,
            yerr=errs,
            capsize=3,
            label=short_label(m, 28),
            color=PALETTE[i % len(PALETTE)],
        )
    ax.set_xticks(x)
    ax.set_xticklabels([metric_label(m) for m in metrics])
    ax.set_ylabel("Score (mean ± SE)")
    ax.set_title("Automated summarisation metrics by model")
    ax.set_ylim(0, min(1.0, ax.get_ylim()[1] * 1.18))
    # Legend sits below the axes so long model labels never overlap the bars.
    ax.legend(frameon=False, ncol=min(3, len(models)), fontsize=8,
              loc="upper center", bbox_to_anchor=(0.5, -0.16))
    return _save(fig, out, synthetic)


def fig_source_type_box(df: pd.DataFrame, out: Path, synthetic: bool) -> Path:
    types = sorted(df["source_type"].unique())
    models = sorted(df["model_label"].unique())
    fig, axes = plt.subplots(1, len(types), figsize=(3.0 * len(types), 3.4), sharey=True)
    axes = np.atleast_1d(axes)
    for ax, t in zip(axes, types):
        data = [
            df[(df.source_type == t) & (df.model_label == m)]["rougeL_f"].dropna()
            for m in models
        ]
        bp = ax.boxplot(data, patch_artist=True, widths=0.6, showfliers=False)
        for patch, colour in zip(bp["boxes"], PALETTE):
            patch.set_facecolor(colour)
            patch.set_alpha(0.65)
        for med in bp["medians"]:
            med.set_color("black")
        ax.set_xticklabels([short_label(m) for m in models], rotation=20,
                           ha="right", fontsize=8)
        ax.set_title({"cve": "CVE records", "otx": "OTX pulses", "apt": "APT reports"}.get(t, t))
    axes[0].set_ylabel("ROUGE-L F")
    fig.suptitle("ROUGE-L by CTI source type", y=1.02)
    return _save(fig, out, synthetic)


def fig_hallucination(halluc: pd.DataFrame, gens: pd.DataFrame, out: Path, synthetic: bool) -> Path:
    models = sorted(gens["model_label"].unique())
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.2, 3.6))

    # Categories are made mutually exclusive before stacking. Counting a summary
    # in both the intrinsic and the extrinsic bar makes the stacked total exceed
    # the affected rate reported in Table 6.4 — a figure contradicting its own
    # table. The three segments here sum exactly to that rate.
    totals = gens.groupby("model_label")["item_id"].nunique()
    only_i, only_e, both = [], [], []
    for m in models:
        sub = halluc[halluc.model_label == m]
        n = max(1, totals.get(m, 1))
        i_ids = set(sub[sub.category == "intrinsic"]["item_id"])
        e_ids = set(sub[sub.category == "extrinsic"]["item_id"])
        only_i.append(len(i_ids - e_ids) / n * 100)
        only_e.append(len(e_ids - i_ids) / n * 100)
        both.append(len(i_ids & e_ids) / n * 100)
    x = np.arange(len(models))
    ax1.bar(x, only_i, 0.55, label="Intrinsic only", color=PALETTE[0])
    ax1.bar(x, only_e, 0.55, bottom=only_i, label="Extrinsic only", color=PALETTE[1])
    ax1.bar(x, both, 0.55, bottom=np.add(only_i, only_e), label="Both",
            color=PALETTE[3])
    ax1.set_xticks(x)
    ax1.set_xticklabels([short_label(m) for m in models], rotation=15,
                        ha="right", fontsize=8)
    ax1.set_ylabel("% of summaries affected")
    ax1.set_title("Summaries affected, by error category")
    ax1.legend(frameon=False, fontsize=8)

    subtypes = list(SUBTYPES)
    mat = np.zeros((len(models), len(subtypes)))
    for i, m in enumerate(models):
        for j, s in enumerate(subtypes):
            mat[i, j] = len(halluc[(halluc.model_label == m) & (halluc.subtype == s)])
    im = ax2.imshow(mat, cmap="OrRd", aspect="auto")
    ax2.set_xticks(range(len(subtypes)))
    ax2.set_xticklabels([s.replace("_error", "").replace("_", " ") for s in subtypes],
                        rotation=25, ha="right", fontsize=8)
    ax2.set_yticks(range(len(models)))
    ax2.set_yticklabels([short_label(m) for m in models], fontsize=8)
    ax2.set_title("Findings by taxonomy subtype\n(atom-level, not one per hallucination)")
    ax2.grid(False)
    for i in range(len(models)):
        for j in range(len(subtypes)):
            ax2.text(j, i, int(mat[i, j]), ha="center", va="center", fontsize=8,
                     color="white" if mat[i, j] > mat.max() * 0.6 else "black")
    fig.colorbar(im, ax=ax2, shrink=0.8, label="errors")
    return _save(fig, out, synthetic)


def fig_cost_latency(df: pd.DataFrame, out: Path, synthetic: bool) -> Path:
    models = sorted(df["model_label"].unique())
    # sharey so the model names are written once instead of on both panels.
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8.4, 3.2), sharey=True)
    y = np.arange(len(models))
    lat = [float(df[df.model_label == m]["latency_s"].median()) for m in models]
    ax1.barh(y, lat, color=PALETTE[: len(models)], height=0.55)
    ax1.set_yticks(y)
    ax1.set_yticklabels([short_label(m, 28) for m in models], fontsize=8)
    ax1.set_xlabel("Median latency per summary (s)")
    ax1.set_title("Inference latency")
    cost = [
        float(df[df.model_label == m]["cost_usd"].fillna(0).mean()) * 1000
        for m in models
    ]
    ax2.barh(y, cost, color=PALETTE[: len(models)], height=0.55)
    ax2.set_xlabel("USD per 1 000 summaries")
    ax2.set_title("Marginal inference cost")
    for ax, vals, fmt in ((ax1, lat, "{:.1f}s"), (ax2, cost, "${:,.2f}")):
        span = max(vals) if max(vals) else 1.0
        for yi, v in zip(y, vals):
            ax.text(v + span * 0.02, yi, fmt.format(v), va="center", fontsize=8)
        ax.set_xlim(0, span * 1.22)
    return _save(fig, out, synthetic)


# --------------------------------------------------------------------------- #
# Tables and results pack
# --------------------------------------------------------------------------- #

def _md_table(df: pd.DataFrame, floatfmt: str = ".3f") -> str:
    return df.to_markdown(index=False, floatfmt=floatfmt)


def hallucination_rates(halluc: pd.DataFrame, gens: pd.DataFrame) -> pd.DataFrame:
    """Per-model flagged rate with Wilson intervals and taxonomy counts.

    Two distinctions the earlier version elided:

    * *Findings* are atom-level. One fabricated sentence naming an actor, a
      repository and an exploitation status yields several findings, so
      "findings per summary" is not "hallucinations per summary".
    * If the findings carry a ``confirmed`` column (written by
      ``ctieval adjudicate``) the human-confirmed rate is reported alongside the
      raw detector rate. Without adjudication only the flagged rate exists, and
      it is named accordingly.
    """
    from .metrics import wilson_ci

    adjudicated = "confirmed" in halluc.columns and halluc["confirmed"].notna().any()
    rows = []
    for model in sorted(gens["model_label"].unique()):
        g = gens[gens.model_label == model]
        h = halluc[halluc.model_label == model] if not halluc.empty else halluc
        n = int(g["item_id"].nunique())
        affected = int(h["item_id"].nunique()) if len(h) else 0
        lo, hi = wilson_ci(affected, n)
        row = {
            "Model": model,
            "Summaries": n,
            "Flagged": affected,
            "Flagged %": round(affected / n * 100, 1) if n else float("nan"),
            "95% CI": f"[{lo * 100:.1f}, {hi * 100:.1f}]",
            "Findings": len(h),
            "Findings/summary": round(len(h) / n, 2) if n else float("nan"),
            "Intrinsic": int((h["category"] == "intrinsic").sum()) if len(h) else 0,
            "Extrinsic": int((h["category"] == "extrinsic").sum()) if len(h) else 0,
        }
        if adjudicated:
            conf = h[h["confirmed"] == True]  # noqa: E712 - NaN-safe on object dtype
            c_aff = int(conf["item_id"].nunique()) if len(conf) else 0
            clo, chi = wilson_ci(c_aff, n)
            row["Confirmed"] = c_aff
            row["Confirmed %"] = round(c_aff / n * 100, 1) if n else float("nan")
            row["Confirmed 95% CI"] = f"[{clo * 100:.1f}, {chi * 100:.1f}]"
            reviewed = int(h["confirmed"].notna().sum())
            row["Detector precision"] = (
                round(len(conf) / reviewed, 3) if reviewed else float("nan")
            )
        for s in SUBTYPES:
            row[s.replace("_error", "").capitalize()] = (
                int((h["subtype"] == s).sum()) if len(h) else 0
            )
        rows.append(row)
    return pd.DataFrame(rows)


def metric_confidence_table(
    metrics_df: pd.DataFrame, metric_cols: list[str], alpha: float = 0.05
) -> pd.DataFrame:
    """Bootstrap 95% CIs for every model x metric mean.

    A mean over 30 items per source type without an interval is hard to defend;
    these are cheap and belong beside Table 6.1.
    """
    from .metrics import bootstrap_ci

    rows = []
    for model in sorted(metrics_df["model_label"].unique()):
        sub = metrics_df[metrics_df.model_label == model]
        row = {"Model": model, "n": int(len(sub))}
        for col in metric_cols:
            if col not in sub.columns:
                continue
            lo, hi = bootstrap_ci(sub[col].to_numpy(), alpha=alpha)
            row[f"{col}_mean"] = round(float(sub[col].mean()), 4)
            row[f"{col}_ci95"] = f"[{lo:.4f}, {hi:.4f}]"
        rows.append(row)
    return pd.DataFrame(rows)


def build_results_pack(
    metrics_df: pd.DataFrame,
    halluc_df: pd.DataFrame,
    stats_tables: dict[str, pd.DataFrame],
    omnibus: dict,
    out_dir: str | Path,
    synthetic: bool,
    human: tuple | None = None,
    detector_validation: dict | None = None,
    selfcheck: pd.DataFrame | None = None,
    alpha: float = 0.05,
    allow_synthetic: bool = False,
) -> Path:
    """Write figures, CSV tables and ``results_pack.md``."""
    out_dir = Path(out_dir)
    fig_dir = out_dir / "figures"
    out_dir.mkdir(parents=True, exist_ok=True)

    if synthetic and not allow_synthetic:
        raise RuntimeError(
            "Corpus contains synthetic items. Refusing to build a results pack. "
            "Pass allow_synthetic=True (CLI: --allow-synthetic) if you are "
            "deliberately producing a dry run."
        )

    figs = {
        "f_metrics": fig_metric_bars(metrics_df, fig_dir / "fig_metrics_by_model.png", synthetic),
        "f_source": fig_source_type_box(metrics_df, fig_dir / "fig_rougeL_by_source.png", synthetic),
        "f_cost": fig_cost_latency(metrics_df, fig_dir / "fig_cost_latency.png", synthetic),
    }
    if not halluc_df.empty:
        figs["f_halluc"] = fig_hallucination(
            halluc_df, metrics_df, fig_dir / "fig_hallucination.png", synthetic
        )

    sem = metrics_df["semantic_metric"].iloc[0] if "semantic_metric" in metrics_df else None
    metric_cols = ["rouge1_f", "rouge2_f", "rougeL_f"] + (
        [sem] if sem and sem in metrics_df.columns else []
    )

    desc = (
        metrics_df.groupby("model_label")[metric_cols + ["len_ratio", "novel_unigram_rate", "latency_s"]]
        .agg(["mean", "std"])
        .round(4)
    )
    desc.columns = [f"{a}_{b}" for a, b in desc.columns]
    desc = desc.reset_index().rename(columns={"model_label": "Model"})

    by_source = (
        metrics_df.groupby(["source_type", "model_label"])[metric_cols]
        .mean()
        .round(4)
        .reset_index()
    )

    cis = metric_confidence_table(metrics_df, metric_cols, alpha=alpha)
    cis.to_csv(out_dir / "table_metric_confidence_intervals.csv", index=False)

    hall_rates = hallucination_rates(halluc_df, metrics_df) if not halluc_df.empty else pd.DataFrame()

    desc.to_csv(out_dir / "table_descriptives.csv", index=False)
    by_source.to_csv(out_dir / "table_by_source_type.csv", index=False)
    if not hall_rates.empty:
        hall_rates.to_csv(out_dir / "table_hallucination_rates.csv", index=False)
    for name, tbl in stats_tables.items():
        tbl.to_csv(out_dir / f"table_stats_{name}.csv", index=False)

    lines: list[str] = []
    if synthetic:
        lines += [
            "> **DRY RUN — SYNTHETIC DATA.** Every number below was produced from "
            "the offline synthetic corpus with the mock provider. It validates "
            "that the pipeline runs end to end. It is **not** an experimental "
            "result and must not be reported as one.",
            "",
        ]

    n_items = metrics_df["item_id"].nunique()
    n_models = metrics_df["model_label"].nunique()
    lines += [
        "## 6.1 Overview of the experimental run",
        "",
        f"The experiment produced {len(metrics_df)} summaries: {n_items} corpus "
        f"items across {n_models} models. Coverage by source type was "
        + ", ".join(
            f"{n} {t.upper()}"
            for t, n in metrics_df.groupby("source_type")["item_id"].nunique().items()
        )
        + ".",
        "",
        "### Table 6.1 — Automated metrics by model (mean ± SD)",
        "",
        _md_table(desc),
        "",
        f"![Automated metrics by model]({figs['f_metrics'].as_posix()})",
        "",
        "*Figure 6.1: Automated summarisation metrics by model, mean ± standard error.*",
        "",
        "### Table 6.1b — Bootstrap 95% confidence intervals for the means",
        "",
        _md_table(cis),
        "",
        "### Table 6.2 — Automated metrics by CTI source type",
        "",
        _md_table(by_source),
        "",
        f"![ROUGE-L by source type]({figs['f_source'].as_posix()})",
        "",
        "*Figure 6.2: Distribution of ROUGE-L F by model within each CTI source type.*",
        "",
        "## 6.2 Inferential comparison between models",
        "",
    ]

    if omnibus:
        for metric, o in omnibus.items():
            if "friedman_p" in o:
                lines.append(
                    f"- **{metric}**: Friedman χ²({o.get('n_items')} items) = "
                    f"{o['friedman_chi2']:.2f}, p = {o['friedman_p']:.4f}, "
                    f"Kendall's W = {o['kendalls_w']:.3f}."
                )
        lines.append("")

    for name, tbl in stats_tables.items():
        lines += [
            f"### Table 6.3.{name} — Pairwise Wilcoxon signed-rank tests ({name})",
            "",
            _md_table(tbl, floatfmt=".4f"),
            "",
        ]

    if not hall_rates.empty:
        adjudicated = "Confirmed" in hall_rates.columns
        heading = (
            "### Table 6.4 — Hallucination rate (human-confirmed) and detector output"
            if adjudicated
            else "### Table 6.4 — Detector-flagged rate and taxonomy breakdown"
        )
        caveat = (
            "Rates are human-confirmed; the detector's own flagged rate and its "
            "precision against adjudication are shown beside them."
            if adjudicated
            else "**These are detector-flagged rates, not adjudicated hallucination "
            "rates.** No findings have been reviewed by a human "
            "(`ctieval adjudicate`), so each figure is an upper bound that "
            "includes the detector's false positives. `Findings` counts "
            "checkable atoms, so one fabricated sentence can contribute several."
        )
        lines += [
            "## 6.3 Hallucination",
            "",
            heading,
            "",
            _md_table(hall_rates, floatfmt=".2f"),
            "",
            caveat,
            "",
            f"![Hallucination]({figs['f_halluc'].as_posix()})",
            "",
            "*Figure 6.3: Hallucination rate by category (left) and error counts by "
            "taxonomy subtype (right).*",
            "",
        ]

    if detector_validation:
        lines += [
            "### Table 6.5 — Grounding detector validation against seeded errors",
            "",
            _md_table(pd.DataFrame([detector_validation]), floatfmt=".3f"),
            "",
            "Matching is on (item_id, model_id, span) triples. Pooling span "
            "strings across the corpus collapses repeated spans into one entry "
            "and inflates precision.",
            "",
        ]
        pd.DataFrame([detector_validation]).to_csv(
            out_dir / "table_detector_validation.csv", index=False
        )

    if selfcheck is not None and not selfcheck.empty:
        sc = (
            selfcheck.groupby("model_label")["selfcheck_inconsistency"]
            .agg(["count", "mean", "std"])
            .round(4)
            .reset_index()
        )
        sc.to_csv(out_dir / "table_selfcheck.csv", index=False)
        lines += [
            "### Table 6.5b — SelfCheckGPT consistency (higher = less consistent)",
            "",
            _md_table(sc),
            "",
        ]

    if human:
        long, per_model, agreement = human
        lines += [
            "## 6.4 Human expert evaluation",
            "",
            "### Table 6.6 — Expert scores by model and source type (1–5)",
            "",
            _md_table(per_model),
            "",
            "**Inter-rater agreement.** "
            + "; ".join(f"{k} = {v}" for k, v in agreement.items())
            + ".",
            "",
        ]

    lines += [
        "## 6.5 Operational cost and latency",
        "",
        f"![Cost and latency]({figs['f_cost'].as_posix()})",
        "",
        "*Figure 6.4: Median inference latency per summary and marginal cost per "
        "1 000 summaries.*",
        "",
    ]

    path = out_dir / "results_pack.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path
