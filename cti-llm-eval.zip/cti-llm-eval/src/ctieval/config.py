"""Configuration handling.

All experiment parameters live in ``config/config.yaml`` so that a run is
reproducible from a single file. API keys are *never* read from the config —
they are taken from environment variables only, satisfying the requirement in
the project proposal that no credentials enter version control.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "config.yaml"


@dataclass
class ModelConfig:
    """One model under evaluation."""

    label: str  # e.g. "LLaMA 3 8B"
    provider: str  # "lmstudio" | "anthropic" | "mock"
    model_id: str  # provider-specific identifier
    base_url: str | None = None  # LM Studio endpoint
    api_key_env: str | None = None  # env var holding the key
    max_tokens: int = 512
    temperature: float = 0.0
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def api_key(self) -> str | None:
        if not self.api_key_env:
            return None
        return os.environ.get(self.api_key_env)


@dataclass
class Config:
    run_id: str = "run-001"
    seed: int = 20260612
    prompt_id: str = "cti_summary_v1"
    temperature: float = 0.0
    max_tokens: int = 512
    selfcheck_samples: int = 0  # >0 enables SelfCheckGPT-style sampling
    selfcheck_temperature: float = 0.7
    models: list[ModelConfig] = field(default_factory=list)
    paths: dict[str, str] = field(default_factory=dict)
    bertscore_model: str = "distilbert-base-uncased"
    bertscore_num_layers: int | None = None
    alpha: float = 0.05
    raw: dict[str, Any] = field(default_factory=dict)

    # ---------------------------------------------------------------- #
    def path(self, key: str) -> Path:
        """Resolve a named path from the config, relative to the project root."""
        defaults = {
            "corpus": "data/corpus.jsonl",
            "generations": "results/generations.jsonl",
            "metrics": "results/metrics.csv",
            "hallucinations": "results/hallucinations.jsonl",
            "human_sheet": "results/human_eval_sheet.csv",
            "human_scores": "results/human_scores.csv",
            "report_dir": "results/report",
            "figures_dir": "results/figures",
            "provenance": "data/provenance_registry.csv",
        }
        raw = self.paths.get(key, defaults[key])
        p = Path(raw)
        return p if p.is_absolute() else PROJECT_ROOT / p

    @classmethod
    def load(cls, path: str | Path | None = None) -> "Config":
        path = Path(path) if path else DEFAULT_CONFIG
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        models = [ModelConfig(**m) for m in data.get("models", [])]
        exp = data.get("experiment", {})
        return cls(
            run_id=exp.get("run_id", "run-001"),
            seed=exp.get("seed", 20260612),
            prompt_id=exp.get("prompt_id", "cti_summary_v1"),
            temperature=exp.get("temperature", 0.0),
            max_tokens=exp.get("max_tokens", 512),
            selfcheck_samples=exp.get("selfcheck_samples", 0),
            selfcheck_temperature=exp.get("selfcheck_temperature", 0.7),
            bertscore_model=exp.get("bertscore_model", "distilbert-base-uncased"),
            bertscore_num_layers=exp.get("bertscore_num_layers"),
            alpha=exp.get("alpha", 0.05),
            models=models,
            paths=data.get("paths", {}),
            raw=data,
        )

    def model(self, label_or_id: str) -> ModelConfig:
        for m in self.models:
            if label_or_id in (m.label, m.model_id):
                return m
        raise KeyError(f"No model configured with label or id {label_or_id!r}")
