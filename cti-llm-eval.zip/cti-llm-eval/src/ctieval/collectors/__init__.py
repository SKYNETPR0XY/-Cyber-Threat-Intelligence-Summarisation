"""Corpus collectors, one per CTI source type."""
