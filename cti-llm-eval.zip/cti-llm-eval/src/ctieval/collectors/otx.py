"""AlienVault OTX pulse collector.

Pulls pulses from the OTX subscribed/activity feed within a rolling window and
retains only those with substantive English narrative content. Because OTX
pulses do not carry an authoritative expert summary, the reference summaries
for this source type are authored by the researcher and validated by a second
practitioner (see Section 5.2.3 of the dissertation) — this module therefore
emits items with an *empty* ``reference_summary`` for the annotation stage to
fill, and refuses to invent one.

Requires a free API key from https://otx.alienvault.com (Settings → API key),
exported as ``OTX_API_KEY``.
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta, timezone

import requests

from ..schema import CTIItem
from ._http import CollectorError, get_json

API = "https://otx.alienvault.com/api/v1"
NON_ASCII = re.compile(r"[^\x00-\x7F]")


def _is_english(text: str) -> bool:
    """Cheap language screen: reject text with a high non-ASCII ratio."""
    if not text:
        return False
    return len(NON_ASCII.findall(text)) / max(1, len(text)) < 0.05


def _indicator_digest(indicators: list[dict], limit: int = 25) -> str:
    by_type: dict[str, list[str]] = {}
    for ind in indicators[:400]:
        by_type.setdefault(ind.get("type", "unknown"), []).append(
            str(ind.get("indicator", ""))
        )
    lines = []
    for t, vals in sorted(by_type.items(), key=lambda kv: -len(kv[1])):
        shown = vals[:5]
        more = len(vals) - len(shown)
        lines.append(
            f"  - {t} ({len(vals)}): "
            + ", ".join(shown)
            + (f" … and {more} more" if more > 0 else "")
        )
    return "\n".join(lines[:limit]) or "  - none"


def collect(
    days: int = 30,
    min_words: int = 200,
    max_items: int = 30,
    api_key: str | None = None,
) -> list[CTIItem]:
    api_key = api_key or os.environ.get("OTX_API_KEY")
    if not api_key:
        raise CollectorError(
            "OTX_API_KEY is not set. Register free at otx.alienvault.com and "
            "export the key before running the OTX collector."
        )
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    headers = {"X-OTX-API-KEY": api_key}

    items: list[CTIItem] = []
    page = 1
    while len(items) < max_items and page <= 20:
        payload = get_json(
            f"{API}/pulses/subscribed",
            params={"modified_since": since, "limit": 50, "page": page},
            headers=headers,
            source="the AlienVault OTX API",
        )
        results = payload.get("results", [])
        if not results:
            break
        for pulse in results:
            if len(items) >= max_items:
                break
            desc = (pulse.get("description") or "").strip()
            if len(desc.split()) < min_words or not _is_english(desc):
                continue
            indicators = pulse.get("indicators", [])
            body = "\n".join(
                [
                    f"Pulse title: {pulse.get('name', '')}",
                    f"Author: {pulse.get('author_name', 'unknown')}",
                    f"Created: {(pulse.get('created') or '')[:10]}",
                    f"Modified: {(pulse.get('modified') or '')[:10]}",
                    f"Tags: {', '.join(pulse.get('tags', [])) or 'none'}",
                    f"Targeted industries: {', '.join(pulse.get('industries', [])) or 'not stated'}",
                    f"Targeted countries: {', '.join(pulse.get('targeted_countries', [])) or 'not stated'}",
                    f"Malware families: {', '.join(pulse.get('malware_families', [])) or 'not stated'}",
                    f"ATT&CK IDs: {', '.join(pulse.get('attack_ids', [])) or 'not stated'}",
                    f"Related CVEs: {', '.join(pulse.get('cves', [])) or 'none'}",
                    "",
                    "Narrative:",
                    desc,
                    "",
                    f"Indicators of compromise ({len(indicators)} total):",
                    _indicator_digest(indicators),
                ]
            )
            items.append(
                CTIItem(
                    item_id=f"otx::{pulse.get('id')}",
                    source_type="otx",
                    title=(pulse.get("name") or "untitled")[:80],
                    source_text=body,
                    reference_summary="",  # authored at the annotation stage
                    metadata={
                        "pulse_id": pulse.get("id"),
                        "author": pulse.get("author_name"),
                        "created": (pulse.get("created") or "")[:10],
                        "indicator_count": len(indicators),
                        "cves": pulse.get("cves", []),
                        "attack_ids": pulse.get("attack_ids", []),
                        "malware_families": pulse.get("malware_families", []),
                        "source": "AlienVault OTX API v1",
                        "retrieved_at": datetime.now(timezone.utc).isoformat(),
                        "needs_reference_summary": True,
                    },
                )
            )
        page += 1
    return items
