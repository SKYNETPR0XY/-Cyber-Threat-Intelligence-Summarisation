"""NVD CVE collector.

Pulls CVE records from the NIST NVD 2.0 REST API and builds stratified
``CTIItem`` objects. Stratification is by CVSS v3.1 base severity
(10 Critical / 10 High / 10 Medium by default) with a cap on the number of
records drawn from any single CWE class, so that the sample is not dominated
by one vulnerability family.

The NVD description field is authored by the CVE Numbering Authority and
reviewed by NIST analysts; it is used as the expert reference summary, and the
model input is the record with the description removed so that the task is
genuine summarisation rather than copying.

Public API, no key required. Rate limit without a key is 5 requests per 30 s;
with a key it is 50 per 30 s. Request an optional key at
https://nvd.nist.gov/developers/request-an-api-key and export it as
``NVD_API_KEY``.
"""

from __future__ import annotations

import os
import time
from collections import Counter
from datetime import datetime, timedelta, timezone

from ..schema import CTIItem
from ._http import CollectorError, get_json  # noqa: F401 - CollectorError re-exported

API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM")


def _sleep_for_rate_limit(has_key: bool) -> None:
    time.sleep(0.7 if has_key else 6.5)


def _fetch_page(params: dict, api_key: str | None) -> dict:
    headers = {"apiKey": api_key} if api_key else {}
    return get_json(API, params=params, headers=headers, source="the NVD 2.0 API")


def _cvss(metrics: dict) -> tuple[float | None, str | None, str | None]:
    """Return (base score, severity, vector) preferring CVSS v3.1."""
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        entries = metrics.get(key) or []
        if entries:
            d = entries[0].get("cvssData", {})
            sev = d.get("baseSeverity") or entries[0].get("baseSeverity")
            return d.get("baseScore"), sev, d.get("vectorString")
    return None, None, None


def _model_input(cve: dict, description: str) -> str:
    """Build the structured record shown to the model (description withheld)."""
    metrics = cve.get("metrics", {})
    score, severity, vector = _cvss(metrics)
    cwes = sorted(
        {
            d.get("value")
            for w in cve.get("weaknesses", [])
            for d in w.get("description", [])
            if d.get("value", "").startswith("CWE")
        }
    )
    configs = []
    for node in cve.get("configurations", []):
        for n in node.get("nodes", []):
            for cpe in n.get("cpeMatch", [])[:6]:
                crit = cpe.get("criteria", "")
                parts = crit.split(":")
                if len(parts) > 5:
                    vendor, product, version = parts[3], parts[4], parts[5]
                    label = f"{vendor} {product}".replace("_", " ")
                    if version not in ("*", "-"):
                        label += f" {version}"
                    bounds = []
                    for k, sym in (
                        ("versionStartIncluding", ">="),
                        ("versionStartExcluding", ">"),
                        ("versionEndIncluding", "<="),
                        ("versionEndExcluding", "<"),
                    ):
                        if cpe.get(k):
                            bounds.append(f"{sym} {cpe[k]}")
                    if bounds:
                        label += " (" + ", ".join(bounds) + ")"
                    configs.append(label)
    refs = [r.get("url") for r in cve.get("references", [])[:5] if r.get("url")]

    lines = [
        f"CVE ID: {cve.get('id')}",
        f"Published: {cve.get('published', '')[:10]}",
        f"Last modified: {cve.get('lastModified', '')[:10]}",
        f"Vulnerability status: {cve.get('vulnStatus', 'Unknown')}",
        f"CVSS base score: {score}  Severity: {severity}",
        f"CVSS vector: {vector}",
        f"Weakness (CWE): {', '.join(cwes) if cwes else 'not assigned'}",
        "Affected configurations:",
    ]
    lines += [f"  - {c}" for c in (dict.fromkeys(configs) or ["not enumerated"])]
    lines.append("Technical detail:")
    lines.append("  " + description)
    lines.append("References:")
    lines += [f"  - {u}" for u in refs] or ["  - none listed"]
    return "\n".join(lines)


def collect(
    n_per_severity: int = 10,
    days_back: int = 120,
    max_per_cwe: int = 3,
    api_key: str | None = None,
) -> list[CTIItem]:
    """Collect a stratified CVE sample.

    Parameters
    ----------
    n_per_severity:
        Number of records per CVSS severity band (default 10 → 30 total).
    days_back:
        Size of the publication window to sample from, ending today.
    max_per_cwe:
        Maximum records drawn from any single CWE class within a band.
    """
    api_key = api_key or os.environ.get("NVD_API_KEY")
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days_back)
    items: list[CTIItem] = []

    for severity in SEVERITIES:
        cwe_counts: Counter[str] = Counter()
        taken = 0
        start_index = 0
        while taken < n_per_severity and start_index < 2000:
            params = {
                "cvssV3Severity": severity,
                "pubStartDate": start.strftime("%Y-%m-%dT%H:%M:%S.000"),
                "pubEndDate": end.strftime("%Y-%m-%dT%H:%M:%S.000"),
                "resultsPerPage": 100,
                "startIndex": start_index,
            }
            data = _fetch_page(params, api_key)
            vulns = data.get("vulnerabilities", [])
            if not vulns:
                break
            for entry in vulns:
                if taken >= n_per_severity:
                    break
                cve = entry.get("cve", {})
                desc = next(
                    (
                        d.get("value", "")
                        for d in cve.get("descriptions", [])
                        if d.get("lang") == "en"
                    ),
                    "",
                )
                # Quality filters: reserved/rejected records and stubs are useless
                # as summarisation targets.
                if len(desc.split()) < 30 or desc.startswith("Rejected"):
                    continue
                if cve.get("vulnStatus") in ("Rejected", "Awaiting Analysis"):
                    continue
                score, sev, vector = _cvss(cve.get("metrics", {}))
                if score is None:
                    continue
                cwes = [
                    d.get("value")
                    for w in cve.get("weaknesses", [])
                    for d in w.get("description", [])
                    if d.get("value", "").startswith("CWE")
                ]
                primary_cwe = cwes[0] if cwes else "CWE-noinfo"
                if cwe_counts[primary_cwe] >= max_per_cwe:
                    continue
                cwe_counts[primary_cwe] += 1
                taken += 1

                items.append(
                    CTIItem(
                        item_id=f"cve::{cve['id']}",
                        source_type="cve",
                        title=cve["id"],
                        source_text=_model_input(cve, desc),
                        reference_summary=desc.strip(),
                        metadata={
                            "cve_id": cve["id"],
                            "cvss_score": score,
                            "cvss_severity": sev,
                            "cvss_vector": vector,
                            "cwe": primary_cwe,
                            "published": cve.get("published", "")[:10],
                            "source": "NVD 2.0 REST API",
                            "retrieved_at": datetime.now(timezone.utc).isoformat(),
                            "licence": "NVD data is public domain (NIST)",
                        },
                    )
                )
            start_index += 100
            _sleep_for_rate_limit(bool(api_key))
    return items
