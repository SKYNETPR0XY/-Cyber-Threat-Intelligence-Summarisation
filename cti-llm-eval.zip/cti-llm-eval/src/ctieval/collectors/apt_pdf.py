"""APT / vendor threat report collector (PDF).

This is the collector used for the third CTI source type: long-form narrative
reports published as PDFs (Mandiant M-Trends, CrowdStrike Global Threat Report,
and equivalent public vendor reporting), plus MITRE ATT&CK group profiles.

Design notes
------------
*Segmentation.* A 60-page report is far longer than the context window budget
of a 4-bit 7B model served through LM Studio, so reports are segmented into
sections and each section becomes one evaluation item. Segmentation uses layout
signals available from ``pdfplumber`` (font size relative to the page's modal
body size, plus short line length and title casing) rather than regex alone,
because vendor reports use heavily designed headings that a pure regex misses.

*Ground truth.* Two modes are supported:

``exec_summary``
    If the report contains an "Executive Summary" / "Key Findings" section, that
    section is used as the reference summary for the body sections of the same
    chapter. This is the design stated in the project proposal.

``sidecar``
    A JSON file next to the PDF (``<report>.refs.json``) mapping section id →
    researcher-authored reference summary. Used where no executive summary
    exists, and for the second-rater validation workflow.

*Copyright.* Only locally held copies are read. The corpus stores extracted
text for analysis under fair-dealing for non-commercial research, records page
ranges for citation, and is not redistributed with the published pipeline; the
``--no-text`` export mode emits hashes and page references only.
"""

from __future__ import annotations

import json
import re
import statistics
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pdfplumber

from ..schema import CTIItem

EXEC_PAT = re.compile(
    r"^(executive summary|key findings|key takeaways|at a glance|"
    r"summary of findings)\b",
    re.I,
)
NOISE_PAT = re.compile(
    r"^(page \d+|\d+\s*$|copyright|all rights reserved|www\.|https?://)", re.I
)


def _page_lines(page) -> list[dict[str, Any]]:  # noqa: ANN001
    """Group a page's characters into lines with a representative font size."""
    words = page.extract_words(extra_attrs=["size", "fontname"]) or []
    lines: dict[int, list[dict]] = {}
    for w in words:
        key = int(round(w["top"] / 3.0))  # 3pt vertical tolerance
        lines.setdefault(key, []).append(w)
    out = []
    for key in sorted(lines):
        ws = sorted(lines[key], key=lambda w: w["x0"])
        text = " ".join(w["text"] for w in ws).strip()
        if not text:
            continue
        sizes = [w.get("size", 0) or 0 for w in ws]
        out.append(
            {
                "text": text,
                "size": statistics.median(sizes) if sizes else 0.0,
                "bold": any("bold" in (w.get("fontname") or "").lower() for w in ws),
            }
        )
    return out


def _is_heading(line: dict, body_size: float) -> bool:
    text = line["text"].strip()
    if len(text) < 3 or len(text) > 120:
        return False
    if NOISE_PAT.match(text):
        return False
    if text.endswith((".", ";", ",")):
        return False
    bigger = line["size"] >= body_size * 1.15
    short_and_titled = len(text.split()) <= 12 and (
        text.istitle() or text.isupper() or line["bold"]
    )
    return bigger or (short_and_titled and line["size"] >= body_size)


def parse_pdf(path: str | Path) -> list[dict[str, Any]]:
    """Segment one PDF into ``{heading, text, page_start, page_end}`` sections."""
    path = Path(path)
    sections: list[dict[str, Any]] = []
    current = {"heading": "Front matter", "lines": [], "page_start": 1, "page_end": 1}

    with pdfplumber.open(path) as pdf:
        all_sizes: list[float] = []
        pages_lines: list[tuple[int, list[dict]]] = []
        for i, page in enumerate(pdf.pages, start=1):
            lines = _page_lines(page)
            pages_lines.append((i, lines))
            all_sizes.extend(l["size"] for l in lines if l["size"])
        body_size = statistics.median(all_sizes) if all_sizes else 10.0

        for page_no, lines in pages_lines:
            for line in lines:
                text = line["text"].strip()
                if NOISE_PAT.match(text):
                    continue
                if _is_heading(line, body_size):
                    if current["lines"]:
                        current["page_end"] = page_no
                        sections.append(current)
                    current = {
                        "heading": text,
                        "lines": [],
                        "page_start": page_no,
                        "page_end": page_no,
                    }
                else:
                    current["lines"].append(text)
        if current["lines"]:
            current["page_end"] = pages_lines[-1][0] if pages_lines else 1
            sections.append(current)

    return [
        {
            "heading": s["heading"],
            "text": re.sub(r"\s+", " ", " ".join(s["lines"])).strip(),
            "page_start": s["page_start"],
            "page_end": s["page_end"],
        }
        for s in sections
    ]


def collect(
    pdf_dir: str | Path,
    min_words: int = 250,
    max_words: int = 1400,
    max_per_report: int = 6,
    require_reference: bool = True,
    share_executive_summary: bool = False,
) -> list[CTIItem]:
    """Build APT items from every PDF in ``pdf_dir``.

    Sections shorter than ``min_words`` are discarded as fragments; sections
    longer than ``max_words`` are truncated at a sentence boundary so that every
    input fits comfortably inside a 4 096-token context window.

    A per-section reference summary comes from the ``<report>.refs.json``
    sidecar. A report-level executive summary is **not** used as the reference
    for individual body sections by default: one summary shared across several
    sections about different subject matter makes ROUGE against it close to
    meaningless, and marking those sections as already referenced means the
    annotation stage never prompts for the real ones. Sections without a
    sidecar reference are emitted with ``needs_reference_summary=True`` so
    ``ctieval annotate --export`` picks them up.

    ``share_executive_summary=True`` restores the old behaviour for a report
    whose sections genuinely are summarised by it; such items are marked
    ``reference_shared=True`` so the choice is visible in the corpus.
    """
    pdf_dir = Path(pdf_dir)
    pdfs = sorted(pdf_dir.glob("*.pdf"))
    if not pdfs:
        raise FileNotFoundError(f"no PDFs found in {pdf_dir}")

    items: list[CTIItem] = []
    for pdf_path in pdfs:
        stem = pdf_path.stem
        sidecar = pdf_dir / f"{stem}.refs.json"
        refs: dict[str, str] = {}
        if sidecar.exists():
            refs = json.loads(sidecar.read_text(encoding="utf-8"))

        sections = parse_pdf(pdf_path)
        exec_summary = next(
            (s["text"] for s in sections if EXEC_PAT.match(s["heading"].strip())),
            "",
        )

        kept = 0
        for idx, sec in enumerate(sections):
            if kept >= max_per_report:
                break
            wc = len(sec["text"].split())
            if wc < min_words:
                continue
            if EXEC_PAT.match(sec["heading"].strip()):
                continue  # the ground truth must not also be an input

            text = sec["text"]
            if wc > max_words:
                cut = text[: max_words * 7]
                text = cut[: cut.rfind(".") + 1] or cut

            section_id = f"{stem}::s{idx:03d}"
            reference = refs.get(section_id) or refs.get(sec["heading"], "")
            shared = False
            if not reference and exec_summary and share_executive_summary:
                reference = exec_summary[:2000]
                shared = True
            if require_reference and not reference:
                continue

            kept += 1
            items.append(
                CTIItem(
                    item_id=f"apt::{section_id}",
                    source_type="apt",
                    title=f"{stem} — {sec['heading'][:60]}",
                    source_text=text,
                    reference_summary=reference.strip(),
                    metadata={
                        "report": stem,
                        "heading": sec["heading"],
                        "pages": f"{sec['page_start']}-{sec['page_end']}",
                        "word_count": wc,
                        "reference_source": (
                            "sidecar"
                            if reference and not shared
                            else ("executive_summary" if shared else "pending")
                        ),
                        "reference_shared": shared,
                        "source": f"local PDF {pdf_path.name}",
                        "retrieved_at": datetime.now(timezone.utc).isoformat(),
                        "needs_reference_summary": (not reference) or shared,
                    },
                )
            )
    return items
