"""Offline synthetic corpus — CI AND DRY-RUN ONLY.

Generates a structurally faithful but entirely fictitious corpus so that the
pipeline can be exercised without network access, API keys or a GPU.

Every item is stamped ``metadata["synthetic"] = True`` and every identifier is
drawn from reserved / non-routable ranges (RFC 5737 documentation IP addresses,
``example.com`` domains, CVE identifiers in a year far outside the real
allocation range). ``report.py`` refuses to emit a dissertation results pack
from a corpus containing synthetic items unless ``--allow-synthetic`` is passed,
and stamps every such table and figure with a DRY RUN watermark.

Nothing produced from this corpus may be reported as an experimental result.
"""

from __future__ import annotations

import random
from datetime import datetime, timezone

from ..schema import CTIItem

VENDORS = [
    ("Acme Systems", "GatewayOS", "4.2.1"),
    ("Northwind Software", "DocRender", "11.0.6"),
    ("Contoso Networks", "EdgeProxy", "2.9.3"),
    ("Fabrikam", "MailRelay", "7.14.0"),
    ("Globex", "SCADALink", "3.0.2"),
    ("Initech", "PrintSpool Server", "5.5.5"),
]
WEAKNESSES = [
    ("CWE-89", "SQL injection", "allows an unauthenticated remote attacker to execute arbitrary SQL statements"),
    ("CWE-79", "cross-site scripting", "allows a remote attacker to inject arbitrary script into the administrative console"),
    ("CWE-787", "out-of-bounds write", "allows a remote attacker to write outside the bounds of a heap buffer"),
    ("CWE-22", "path traversal", "allows an authenticated attacker to read arbitrary files outside the web root"),
    ("CWE-502", "deserialisation of untrusted data", "allows a remote attacker to execute arbitrary code through a crafted serialised object"),
    ("CWE-306", "missing authentication for critical function", "allows an unauthenticated attacker to invoke privileged management endpoints"),
]
ACTORS = ["THISTLE PANDA", "AMBER TEMPEST", "Operation Quiet Harbour", "TA-9901"]
MALWARE = ["GRAYHOOK", "SILENTQUILL", "MOTHDUST", "PALEBRIDGE"]


def _cve_item(rng: random.Random, i: int) -> CTIItem:
    vendor, product, version = rng.choice(VENDORS)
    cwe, cwe_name, effect = rng.choice(WEAKNESSES)
    severity, score = rng.choice(
        [("CRITICAL", round(rng.uniform(9.0, 10.0), 1)),
         ("HIGH", round(rng.uniform(7.0, 8.9), 1)),
         ("MEDIUM", round(rng.uniform(4.0, 6.9), 1))]
    )
    cve_id = f"CVE-2099-{10000 + i}"
    vector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
    description = (
        f"A {cwe_name} vulnerability in the request-handling component of "
        f"{vendor} {product} through {version} {effect}. Successful exploitation "
        f"requires network access to the management interface on TCP port "
        f"{rng.choice([443, 8443, 9090, 8080])} and does not require user "
        f"interaction. The vendor has released a fixed build."
    )
    source = "\n".join(
        [
            f"CVE ID: {cve_id}",
            f"Published: 2099-0{rng.randint(1, 9)}-1{rng.randint(0, 9)}",
            "Vulnerability status: Analyzed",
            f"CVSS base score: {score}  Severity: {severity}",
            f"CVSS vector: {vector}",
            f"Weakness (CWE): {cwe}",
            "Affected configurations:",
            f"  - {vendor} {product} (<= {version})",
            "Technical detail:",
            "  " + description,
            "References:",
            "  - https://example.com/advisories/" + cve_id.lower(),
            "  - https://example.com/kb/patch-notes",
        ]
    )
    return CTIItem(
        item_id=f"cve::{cve_id}",
        source_type="cve",
        title=cve_id,
        source_text=source,
        reference_summary=description,
        metadata={
            "synthetic": True,
            "cve_id": cve_id,
            "cvss_score": score,
            "cvss_severity": severity,
            "cwe": cwe,
            "source": "offline synthetic generator",
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
        },
    )


def _otx_item(rng: random.Random, i: int) -> CTIItem:
    actor = rng.choice(ACTORS)
    mal = rng.choice(MALWARE)
    sector = rng.choice(["energy", "higher education", "logistics", "regional banking"])
    narrative = (
        f"A campaign tracked as {actor} has been observed delivering the {mal} "
        f"loader to organisations in the {sector} sector across Western Europe. "
        f"Initial access is achieved through spearphishing attachments containing "
        f"a macro-enabled document that retrieves a second-stage payload over "
        f"HTTPS. The loader establishes persistence through a scheduled task named "
        f"in imitation of a legitimate update service, and beacons to "
        f"infrastructure hosted on bulletproof providers at 30-minute intervals "
        f"with jitter. Collected telemetry indicates credential harvesting from "
        f"browser stores followed by lateral movement using valid accounts. "
        f"Defenders should hunt for the scheduled task name, the named pipe used "
        f"for inter-process communication, and outbound connections to the listed "
        f"command-and-control infrastructure. No destructive activity has been "
        f"observed to date, and the operators appear focused on long-dwell "
        f"collection rather than immediate monetisation."
    )
    reference = (
        f"{actor} is delivering the {mal} loader to {sector} targets in Western "
        f"Europe via macro-enabled spearphishing attachments. The loader persists "
        f"through a disguised scheduled task and beacons over HTTPS at jittered "
        f"30-minute intervals. Observed follow-on activity is credential theft "
        f"from browser stores and lateral movement with valid accounts, with no "
        f"destructive component reported. Hunt for the scheduled task, the named "
        f"pipe, and the listed command-and-control infrastructure."
    )
    source = "\n".join(
        [
            f"Pulse title: {actor} delivers {mal} to {sector} targets",
            "Author: synthetic_generator",
            "Created: 2099-03-14",
            f"Tags: {mal.lower()}, spearphishing, loader",
            f"Targeted industries: {sector}",
            "Targeted countries: DE, FR, NL, GB",
            f"Malware families: {mal}",
            "ATT&CK IDs: T1566.001, T1053.005, T1555.003, T1078",
            "Related CVEs: none",
            "",
            "Narrative:",
            narrative,
            "",
            "Indicators of compromise (18 total):",
            "  - domain (6): update-svc.example.com, cdn-cache.example.net",
            "  - IPv4 (7): 192.0.2.41, 198.51.100.7, 203.0.113.19",
            "  - FileHash-SHA256 (5): 3f2a…c91d, 88be…04aa",
        ]
    )
    return CTIItem(
        item_id=f"otx::synthetic-{i:03d}",
        source_type="otx",
        title=f"{actor} delivers {mal}",
        source_text=source,
        reference_summary=reference,
        metadata={
            "synthetic": True,
            "actor": actor,
            "malware": mal,
            "source": "offline synthetic generator",
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
        },
    )


def _apt_item(rng: random.Random, i: int) -> CTIItem:
    actor = rng.choice(ACTORS)
    body = (
        f"Throughout the reporting period, intrusion activity attributed to "
        f"{actor} shifted away from commodity tooling toward living-off-the-land "
        f"techniques. In the intrusions we responded to, the group obtained "
        f"initial access predominantly through exposed remote access services "
        f"protected only by single-factor authentication, with valid credentials "
        f"sourced from prior infostealer logs traded on criminal marketplaces. "
        f"Median dwell time fell from 21 days to 13 days year on year, which we "
        f"assess reflects improved endpoint detection coverage among victims "
        f"rather than reduced operator patience. Once resident, the group "
        f"favoured native administrative tooling for discovery and lateral "
        f"movement, staged collected data in archive files on file servers "
        f"already used for backup, and exfiltrated over cloud storage services "
        f"that were permitted by the victim's egress policy. Ransomware "
        f"deployment occurred in fewer than a third of the intrusions we "
        f"observed; in the remainder the objective appeared to be extortion "
        f"based on data theft alone. Defensive recommendations centre on "
        f"enforcing phishing-resistant multi-factor authentication on all "
        f"externally reachable services, monitoring for archive creation on file "
        f"servers, and constraining egress to sanctioned cloud storage tenants."
    )
    reference = (
        f"{actor} moved toward living-off-the-land tradecraft during the "
        f"reporting period, gaining access mainly through single-factor remote "
        f"access services using credentials from infostealer logs. Median dwell "
        f"time fell from 21 to 13 days. The group used native admin tooling for "
        f"lateral movement, staged data in archives on backup file servers, and "
        f"exfiltrated via permitted cloud storage. Fewer than a third of "
        f"intrusions ended in ransomware; the rest were theft-based extortion. "
        f"Priority mitigations are phishing-resistant MFA, archive-creation "
        f"monitoring, and egress restriction to sanctioned tenants."
    )
    return CTIItem(
        item_id=f"apt::synthetic-{i:03d}",
        source_type="apt",
        title=f"Synthetic threat report — {actor} intrusion trends",
        source_text=body,
        reference_summary=reference,
        metadata={
            "synthetic": True,
            "actor": actor,
            "pages": "0-0",
            "source": "offline synthetic generator",
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
        },
    )


def collect(n_cve: int = 12, n_otx: int = 9, n_apt: int = 9, seed: int = 20260612):
    rng = random.Random(seed)
    items = [_cve_item(rng, i) for i in range(n_cve)]
    items += [_otx_item(rng, i) for i in range(n_otx)]
    items += [_apt_item(rng, i) for i in range(n_apt)]
    return items
