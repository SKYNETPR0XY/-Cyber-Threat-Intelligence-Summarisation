"""Shared HTTP behaviour for the collectors.

Collection is a long, network-bound loop against public APIs that rate-limit and
occasionally 503. Before this module a single blip raised a bare
``requests`` exception out of the CLI as a traceback, losing every record
already gathered in that run. Requests are now retried with exponential backoff
on the transient statuses, and anything unrecoverable is raised as a
:class:`CollectorError` carrying a message a user can act on.
"""

from __future__ import annotations

import time

import requests

RETRY_STATUS = {403, 408, 429, 500, 502, 503, 504}


class CollectorError(RuntimeError):
    """A collection step failed in a way the caller should report, not trace."""


def get_json(
    url: str,
    *,
    params: dict | None = None,
    headers: dict | None = None,
    timeout: int = 60,
    max_attempts: int = 5,
    backoff_s: float = 4.0,
    source: str = "the API",
) -> dict:
    """GET returning parsed JSON, retrying transient failures with backoff."""
    last = ""
    for attempt in range(1, max_attempts + 1):
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=timeout)
            if resp.status_code in RETRY_STATUS:
                last = f"HTTP {resp.status_code} from {source}"
                if resp.status_code in (403, 429):
                    last += " (rate limited, or a key is required)"
            else:
                resp.raise_for_status()
                return resp.json()
        except requests.exceptions.RequestException as exc:
            last = f"{type(exc).__name__}: {exc}"
        except ValueError as exc:  # body was not JSON
            raise CollectorError(f"{source} returned a non-JSON body: {exc}") from exc

        if attempt < max_attempts:
            wait = backoff_s * (2 ** (attempt - 1))
            print(f"  {last} - retrying in {wait:.0f}s ({attempt}/{max_attempts - 1})")
            time.sleep(wait)

    raise CollectorError(
        f"Could not reach {source} after {max_attempts} attempts. Last error: "
        f"{last}\n\nCheck network access and any proxy, and consider requesting "
        "an API key to raise the rate limit. Records already collected in this "
        "run are unaffected - re-run with --append to continue."
    )
