"""Anthropic Messages API provider (proprietary comparator model).

Uses the REST endpoint directly via ``requests`` so the pipeline has no hard
dependency on the Anthropic SDK; if the SDK is installed it is used instead,
which gives better error typing. The API key is read from the environment
variable named in ``config.yaml`` (``ANTHROPIC_API_KEY`` by default) and is
never written to disk or to any log.
"""

from __future__ import annotations

import requests

from .base import BaseProvider, Completion

API_URL = "https://api.anthropic.com/v1/messages"
API_VERSION = "2023-06-01"

# USD per million tokens, used for the cost-per-summary figures in Chapter 6.
# Update these if Anthropic's published pricing changes.
PRICING = {
    "input_per_mtok": 3.00,
    "output_per_mtok": 15.00,
}


class AnthropicProvider(BaseProvider):
    timeout_s = 120

    def _call(
        self, system: str, user: str, temperature: float, max_tokens: int
    ) -> Completion:
        key = self.cfg.api_key
        if not key:
            return Completion(
                text="",
                error=(
                    f"environment variable {self.cfg.api_key_env!r} is not set; "
                    "export your Anthropic API key before running"
                ),
            )

        payload = {
            "model": self.model_id,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        payload.update(self.cfg.extra or {})

        resp = requests.post(
            API_URL,
            json=payload,
            headers={
                "x-api-key": key,
                "anthropic-version": API_VERSION,
                "content-type": "application/json",
            },
            timeout=self.timeout_s,
        )
        if resp.status_code != 200:
            return Completion(
                text="", error=f"HTTP {resp.status_code}: {resp.text[:300]}"
            )

        data = resp.json()
        blocks = [b for b in data.get("content", []) if b.get("type") == "text"]
        text = "\n".join(b.get("text", "") for b in blocks).strip()
        usage = data.get("usage") or {}
        tin = usage.get("input_tokens")
        tout = usage.get("output_tokens")
        cost = None
        if tin is not None and tout is not None:
            cost = (
                tin / 1e6 * PRICING["input_per_mtok"]
                + tout / 1e6 * PRICING["output_per_mtok"]
            )
        return Completion(
            text=text, input_tokens=tin, output_tokens=tout, cost_usd=cost
        )
