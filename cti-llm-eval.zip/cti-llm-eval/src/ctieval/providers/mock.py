"""Deterministic stand-in provider — TEST HARNESS ONLY.

A stand-in **represents the structure** of a model in the study — its relative
summarisation quality, its error rate, its latency and cost profile — so that
every downstream stage can be exercised on realistically-shaped input. It does
not represent any actual model's behaviour, and it performs no inference
whatsoever.

Stand-ins are named for what they proxy, never for the model they proxy, and
their ``model_id`` is prefixed ``mock/``. Output carrying those identifiers is
watermarked by the reporting layer and refused by the results-pack builder
without an explicit override. If a table or figure shows a stand-in label, it
is validation output and not an experimental result.

This provider does not perform inference. It produces extractive summaries with
a controlled, seeded number of *deliberately injected* factual errors of each
taxonomy subtype.

It exists for two legitimate purposes:

1. **Continuous integration.** The full pipeline can be exercised end to end
   with no GPU, no network and no API key, so that a regression in the metric,
   detection or reporting code is caught immediately.

2. **Detector validation.** Because the injected errors are known by
   construction, running the grounding detector over mock output yields
   precision, recall and F1 for the detector itself. Those figures are reported
   in Section 5.5 of the dissertation as a measure of instrument validity.

Output from this provider is written with ``model_id`` prefixed ``mock/`` and is
excluded from any results table reporting model performance. It must never be
presented as the output of a real model.
"""

from __future__ import annotations

import hashlib
import math
import random
import re

from .base import BaseProvider, Completion

_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")

PADDING = [
    "Organisations are advised to review their exposure and apply vendor guidance.",
    "Further analysis may be required to determine the full operational impact.",
    "This information should be correlated with internal telemetry where available.",
    "Defenders should monitor for related activity across the estate.",
    "The reporting source did not state the affected version range precisely.",
]


def _stable_seed(seed: int, source: str) -> int:
    """A process-independent seed derived from (seed, source).

    ``hash()`` on a str is salted by PYTHONHASHSEED, so seeding from it makes
    this provider reproducible *within* a process and different between runs —
    which silently breaks the reproducibility the module claims and makes the
    detector-validation figures drift from one execution to the next. A digest
    is used instead so that a given (seed, source) always yields the same
    stream.
    """
    digest = hashlib.blake2b(f"{seed}|{source}".encode("utf-8"), digest_size=8)
    return int.from_bytes(digest.digest(), "big")


def source_key(source_text: str) -> str:
    """Stable key linking an injected error back to its corpus item.

    A provider only ever sees the rendered prompt, not the ``CTIItem``, so the
    leading slice of the source text is used as the join key. It is stable,
    unique across the corpus in practice, and needs no plumbing through the
    runner.
    """
    return " ".join((source_text or "").split())[:200]


class MockProvider(BaseProvider):
    """Extractive summariser with seeded, labelled error injection."""

    def __init__(self, cfg) -> None:  # noqa: ANN001
        super().__init__(cfg)
        extra = cfg.extra or {}
        self.error_rate: float = float(extra.get("error_rate", 0.3))
        self.seed: int = int(extra.get("seed", 12345))
        # Structural profile of the model this stands in for. `quality` at 1.0
        # is near-extractive and faithful; lower values drop tokens and pad,
        # which is what moves ROUGE and the semantic metric the way a weaker
        # model does. Without a spread here every stand-in scores identically
        # and the inferential layer has nothing to work on.
        self.quality: float = float(extra.get("quality", 1.0))
        self.usd_per_1k_in: float = float(extra.get("usd_per_1k_in", 0.0))
        self.usd_per_1k_out: float = float(extra.get("usd_per_1k_out", 0.0))
        self.latency_mu: float = float(extra.get("latency_mu", 0.0))
        self.latency_sigma: float = float(extra.get("latency_sigma", 0.25))
        # Injected errors are recorded here so tests can score the detector.
        self.injected: list[dict] = []

    def _call(
        self, system: str, user: str, temperature: float, max_tokens: int
    ) -> Completion:
        m = re.search(r'"""(.*?)"""', user, flags=re.S)
        source = (m.group(1) if m else user).strip()

        rng = random.Random(_stable_seed(self.seed, source))
        sentences = [s.strip() for s in _SENT_SPLIT.split(source) if s.strip()]
        summary = " ".join(sentences[: max(2, round(2 + 2 * self.quality))])

        # Quality degradation. Dropout is deliberately light: heavy dropout
        # manufactures broken tokens that the entity heuristic reads as
        # fabricated entities, which would be an artefact of the harness rather
        # than of the pipeline under test.
        drop = 1.0 - self.quality
        if drop > 0:
            words = [w for w in summary.split() if rng.random() > drop * 0.22]
            summary = " ".join(words)
            for pad in PADDING[: round(drop * 5)]:
                summary += " " + pad

        cap = round(80 + 40 * self.quality)
        words = summary.split()
        if len(words) > cap:
            summary = " ".join(words[:cap]).rstrip(",;") + "."

        if rng.random() < self.error_rate:
            summary, record = self._inject(summary, source, rng)
            if record:
                # Record which (item, model) the error was injected into, so the
                # detector can be validated per finding rather than over a set of
                # span strings pooled across the whole corpus.
                record = dict(record)
                record["source_key"] = source_key(source)
                record["model_id"] = self.model_id
                self.injected.append(record)

        n_in = max(1, len(user) // 4)
        n_out = max(1, len(summary) // 4)
        out = Completion(
            text=summary,
            input_tokens=n_in,
            output_tokens=n_out,
            cost_usd=round(
                n_in / 1000 * self.usd_per_1k_in + n_out / 1000 * self.usd_per_1k_out,
                6,
            ),
        )
        if self.latency_mu > 0:
            # A simulated figure, so it must not be overwritten by the wall-clock
            # time of a call that does no inference.
            out.latency_s = round(
                max(0.05, rng.lognormvariate(math.log(self.latency_mu),
                                             self.latency_sigma)), 3
            )
            self._simulated_latency = out.latency_s
        return out

    # ------------------------------------------------------------------ #
    def complete(self, system, user, *, temperature, max_tokens):  # noqa: ANN001
        """Restore the simulated latency that BaseProvider stamps over.

        The base class records wall-clock time around ``_call``, which for a
        provider that performs no inference is a few microseconds and tells the
        reader nothing. The profile figure is the useful one.
        """
        self._simulated_latency = None
        out = super().complete(system, user, temperature=temperature,
                               max_tokens=max_tokens)
        if self._simulated_latency is not None and not out.error:
            out.latency_s = self._simulated_latency
        return out

    def _inject(self, summary: str, source: str, rng: random.Random):
        """Apply one labelled error of a randomly chosen subtype."""
        strategies = [
            self._wrong_cvss,
            self._wrong_cve_id,
            self._fabricate_exploitation,
            self._swap_relation,
        ]
        rng.shuffle(strategies)
        for fn in strategies:
            out = fn(summary, source, rng)
            if out is not None:
                return out
        return summary, None

    def _wrong_cvss(self, summary, source, rng):
        m = re.search(r"\b(\d{1,2}\.\d)\b", summary)
        if not m:
            return None
        original = m.group(1)
        wrong = f"{min(10.0, float(original) + rng.choice([1.1, 2.3, -1.4])):.1f}"
        return (
            summary.replace(original, wrong, 1),
            {
                "subtype": "circumstantial_error",
                "category": "intrinsic",
                "span": wrong,
                "truth": original,
            },
        )

    def _wrong_cve_id(self, summary, source, rng):
        m = re.search(r"CVE-\d{4}-\d{4,7}", summary)
        if not m:
            return None
        original = m.group(0)
        year, num = original.split("-")[1:]
        wrong = f"CVE-{year}-{int(num) + rng.randint(1, 40):0{len(num)}d}"
        return (
            summary.replace(original, wrong, 1),
            {
                "subtype": "entity_error",
                "category": "intrinsic",
                "span": wrong,
                "truth": original,
            },
        )

    def _fabricate_exploitation(self, summary, source, rng):
        claim = (
            " The flaw is being actively exploited in the wild by the Lazarus "
            "Group, and a public proof-of-concept exploit is available on GitHub."
        )
        if "Lazarus" in source or "actively exploited" in source:
            return None
        return (
            summary.rstrip() + claim,
            {
                "subtype": "fabrication",
                "category": "extrinsic",
                "span": "Lazarus Group",
                "truth": None,
            },
        )

    def _swap_relation(self, summary, source, rng):
        if "allows" not in summary:
            return None
        return (
            summary.replace("allows", "prevents", 1),
            {
                "subtype": "relational_error",
                "category": "intrinsic",
                "span": "prevents",
                "truth": "allows",
            },
        )
