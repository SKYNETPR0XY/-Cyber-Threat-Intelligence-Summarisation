"""Provider abstraction.

Each provider wraps one inference backend behind a single ``complete()`` call so
that the experiment runner is backend-agnostic. Adding a fourth model to the
study requires only a new entry in ``config.yaml``, not a code change.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Protocol

from ..config import ModelConfig


@dataclass
class Completion:
    text: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    latency_s: float = 0.0
    cost_usd: float | None = None
    error: str | None = None


class Provider(Protocol):
    label: str
    model_id: str

    def complete(
        self, system: str, user: str, *, temperature: float, max_tokens: int
    ) -> Completion: ...


class BaseProvider:
    """Shared retry / timing behaviour."""

    max_retries = 3
    backoff_s = 2.0

    def __init__(self, cfg: ModelConfig) -> None:
        self.cfg = cfg
        self.label = cfg.label
        self.model_id = cfg.model_id

    # Subclasses implement this.
    def _call(
        self, system: str, user: str, temperature: float, max_tokens: int
    ) -> Completion:  # pragma: no cover - abstract
        raise NotImplementedError

    def complete(
        self, system: str, user: str, *, temperature: float, max_tokens: int
    ) -> Completion:
        last_err: str | None = None
        for attempt in range(1, self.max_retries + 1):
            t0 = time.perf_counter()
            try:
                out = self._call(system, user, temperature, max_tokens)
                out.latency_s = time.perf_counter() - t0
                if out.error is None:
                    return out
                last_err = out.error
            except Exception as exc:  # noqa: BLE001 - surfaced to the caller
                last_err = f"{type(exc).__name__}: {exc}"
            if attempt < self.max_retries:
                time.sleep(self.backoff_s * attempt)
        return Completion(text="", error=last_err or "unknown error")


def get_provider(cfg: ModelConfig) -> BaseProvider:
    """Instantiate the provider named in a :class:`ModelConfig`."""
    from .lmstudio import LMStudioProvider
    from .anthropic_api import AnthropicProvider
    from .mock import MockProvider

    registry = {
        "lmstudio": LMStudioProvider,
        "openai_compatible": LMStudioProvider,
        "anthropic": AnthropicProvider,
        "mock": MockProvider,
    }
    if cfg.provider not in registry:
        raise KeyError(
            f"Unknown provider {cfg.provider!r}; available: {sorted(registry)}"
        )
    return registry[cfg.provider](cfg)
