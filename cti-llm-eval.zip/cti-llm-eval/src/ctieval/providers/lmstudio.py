"""LM Studio provider (OpenAI-compatible local server).

LM Studio serves GGUF-quantised models over an OpenAI-compatible REST API,
by default at ``http://localhost:1234/v1``. This is the backend used for both
open-source models in the study (LLaMA 3 8B Instruct and Mistral 7B Instruct),
which keeps the two open-source models on an identical serving stack and
removes serving-framework differences as a confound.

No API key is required for a local LM Studio instance; the ``Authorization``
header is sent only if an API key environment variable is configured (useful
if the endpoint is proxied).
"""

from __future__ import annotations

import requests

from .base import BaseProvider, Completion

DEFAULT_BASE_URL = "http://localhost:1234/v1"


class LMStudioProvider(BaseProvider):
    timeout_s = 600  # local 8B inference on CPU can be slow

    @property
    def base_url(self) -> str:
        return (self.cfg.base_url or DEFAULT_BASE_URL).rstrip("/")

    def _call(
        self, system: str, user: str, temperature: float, max_tokens: int
    ) -> Completion:
        headers = {"Content-Type": "application/json"}
        if self.cfg.api_key:
            headers["Authorization"] = f"Bearer {self.cfg.api_key}"

        payload = {
            "model": self.model_id,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        payload.update(self.cfg.extra or {})

        resp = requests.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            headers=headers,
            timeout=self.timeout_s,
        )
        if resp.status_code != 200:
            return Completion(
                text="", error=f"HTTP {resp.status_code}: {resp.text[:300]}"
            )

        data = resp.json()
        choices = data.get("choices") or []
        if not choices:
            return Completion(text="", error="no choices returned")
        text = (choices[0].get("message") or {}).get("content", "") or ""
        usage = data.get("usage") or {}
        return Completion(
            text=text.strip(),
            input_tokens=usage.get("prompt_tokens"),
            output_tokens=usage.get("completion_tokens"),
            cost_usd=0.0,  # local inference has no marginal API cost
        )

    def health_check(self) -> tuple[bool, str]:
        """Confirm the LM Studio server is up and report the loaded models."""
        try:
            r = requests.get(f"{self.base_url}/models", timeout=10)
            if r.status_code != 200:
                return False, f"HTTP {r.status_code} from {self.base_url}/models"
            ids = [m.get("id") for m in r.json().get("data", [])]
            if self.model_id not in ids:
                return False, (
                    f"model {self.model_id!r} not loaded in LM Studio. "
                    f"Loaded: {ids}"
                )
            return True, f"{self.model_id} ready at {self.base_url}"
        except Exception as exc:  # noqa: BLE001
            return False, f"cannot reach LM Studio at {self.base_url}: {exc}"
