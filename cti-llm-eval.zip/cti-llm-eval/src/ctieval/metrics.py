"""Automated summarisation metrics and inferential statistics.

Metrics computed per (item, model) pair:

============================  ==========================================
``rouge1_f`` ``rouge2_f``     n-gram overlap F-measure (Lin, 2004)
``rougeL_f``                  longest-common-subsequence F-measure
``bertscore_f1``              contextual embedding F1 (Zhang et al., 2020)
``semantic_sim_tfidf``        fallback lexical-semantic proxy, used only
                              when ``bert-score`` is not installed and
                              *never* reported as BERTScore
``len_ratio``                 |candidate| / |reference| in words
``novel_unigram_rate``        share of candidate unigrams absent from the
                              source — an abstractiveness indicator, and a
                              cheap leading signal for extrinsic error
============================  ==========================================

Inferential tests follow the analysis plan in the proposal: Friedman omnibus
across the three models, then pairwise Wilcoxon signed-rank tests on the paired
per-item scores with Holm–Bonferroni correction, reported alongside the matched-
pairs rank-biserial correlation as an effect size.
"""

from __future__ import annotations

import re
import warnings
from dataclasses import dataclass
from itertools import combinations

import numpy as np
import pandas as pd
from rouge_score import rouge_scorer
from scipy import stats

_WORD = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/-]*")

_SCORER = rouge_scorer.RougeScorer(
    ["rouge1", "rouge2", "rougeL"], use_stemmer=True
)


def tokenise(text: str) -> list[str]:
    return [w.lower() for w in _WORD.findall(text or "")]


# --------------------------------------------------------------------------- #
# BERTScore (real) with an explicitly-labelled fallback
# --------------------------------------------------------------------------- #

def bertscore_available() -> bool:
    try:
        import bert_score  # noqa: F401

        return True
    except Exception:  # noqa: BLE001
        return False


def bertscore_backbone_cached(model_type: str) -> bool:
    """True when the backbone is already on disk, so scoring will not download.

    Checked before scoring because the alternative is a multi-minute stall: if
    the weights are absent and the hub is unreachable, ``transformers`` works
    through its full retry-and-backoff cycle for every call before raising.
    Knowing in advance lets the caller say what is about to happen.
    """
    try:
        from transformers import AutoConfig

        AutoConfig.from_pretrained(model_type, local_files_only=True)
        return True
    except Exception:  # noqa: BLE001
        return False


def _backbone_max_words(model_type: str, default: int = 350) -> int:
    """Word budget that will not overrun the backbone's position embeddings.

    Two subword pieces per word is a deliberately conservative ratio; the point
    is to never exceed the limit, not to use every position available.
    """
    try:
        from transformers import AutoConfig

        cfg = AutoConfig.from_pretrained(model_type, local_files_only=True)
        positions = getattr(cfg, "max_position_embeddings", None)
        if positions:
            return max(32, int(positions) // 2 - 8)  # 8 spare for special tokens
    except Exception:  # noqa: BLE001
        pass
    return default


def _clip_to_context(
    candidates: list[str], references: list[str], model_type: str
) -> tuple[list[str], list[str], int]:
    limit = _backbone_max_words(model_type)

    def clip(text: str) -> tuple[str, bool]:
        words = (text or "").split()
        if len(words) <= limit:
            return text, False
        return " ".join(words[:limit]), True

    out_c, out_r, n = [], [], 0
    for c, r in zip(candidates, references):
        cc, c_clipped = clip(c)
        rr, r_clipped = clip(r)
        out_c.append(cc)
        out_r.append(rr)
        n += int(c_clipped or r_clipped)
    return out_c, out_r, n


def compute_bertscore(
    candidates: list[str],
    references: list[str],
    model_type: str,
    num_layers: int | None = None,
) -> list[float]:
    """Real BERTScore F1. Raises if ``bert-score`` is not installed.

    ``num_layers`` is required for any backbone outside bert-score's built-in
    table — a local path, or a model it does not ship a default for. Leaving it
    ``None`` for a known backbone keeps the library's own default.
    """
    import bert_score

    kwargs = {}
    if num_layers is not None:
        kwargs["num_layers"] = int(num_layers)

    cands, refs, clipped = _clip_to_context(candidates, references, model_type)
    if clipped:
        warnings.warn(
            f"{clipped} text(s) exceeded the BERTScore backbone's position limit "
            "and were truncated at a word boundary before scoring. Summaries are "
            "specified at 60-120 words, so this indicates unusually long output "
            "or references; the affected scores are computed on the truncated "
            "text. Without this, one over-long item aborts the whole scoring "
            "stage.",
            RuntimeWarning,
            stacklevel=2,
        )

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        _, _, f1 = bert_score.score(
            cands,
            refs,
            model_type=model_type,
            lang="en",
            rescale_with_baseline=False,
            verbose=False,
            **kwargs,
        )
    return [float(x) for x in f1]


def compute_tfidf_similarity(
    candidates: list[str], references: list[str]
) -> list[float]:
    """Fallback lexical-semantic proxy (cosine over character n-gram TF-IDF).

    This is NOT BERTScore and is never reported as such. It exists so that the
    pipeline degrades gracefully on a machine without PyTorch, and so that CI
    can validate the surrounding code path.
    """
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    if not candidates:
        return []
    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1)
    corpus = [c or " " for c in candidates] + [r or " " for r in references]
    matrix = vec.fit_transform(corpus)
    n = len(candidates)
    return [
        float(cosine_similarity(matrix[i], matrix[n + i])[0][0]) for i in range(n)
    ]


# --------------------------------------------------------------------------- #
# Per-pair metrics
# --------------------------------------------------------------------------- #

@dataclass
class PairMetrics:
    rouge1_f: float
    rouge2_f: float
    rougeL_f: float
    rouge1_p: float
    rouge1_r: float
    len_ratio: float
    novel_unigram_rate: float
    candidate_words: int


def score_pair(candidate: str, reference: str, source: str) -> PairMetrics:
    scores = _SCORER.score(reference or "", candidate or "")
    cand_toks = tokenise(candidate)
    ref_toks = tokenise(reference)
    src_toks = set(tokenise(source))
    novel = (
        sum(1 for t in cand_toks if t not in src_toks) / len(cand_toks)
        if cand_toks
        else 0.0
    )
    return PairMetrics(
        rouge1_f=scores["rouge1"].fmeasure,
        rouge2_f=scores["rouge2"].fmeasure,
        rougeL_f=scores["rougeL"].fmeasure,
        rouge1_p=scores["rouge1"].precision,
        rouge1_r=scores["rouge1"].recall,
        len_ratio=len(cand_toks) / len(ref_toks) if ref_toks else float("nan"),
        novel_unigram_rate=novel,
        candidate_words=len(cand_toks),
    )


class BERTScoreUnavailable(RuntimeError):
    """Raised when BERTScore cannot be computed and no fallback was authorised."""


def score_all(
    generations: list,
    corpus_by_id: dict,
    bertscore_model: str = "distilbert-base-uncased",
    allow_semantic_fallback: bool = False,
    bertscore_num_layers: int | None = None,
) -> pd.DataFrame:
    """Score every generation. Returns a tidy dataframe, one row per pair.

    If BERTScore cannot be computed this raises :class:`BERTScoreUnavailable`
    unless ``allow_semantic_fallback=True``. Silently substituting the TF-IDF
    proxy is how a results table ends up with a column that is not the metric
    its caption claims, so the fallback now has to be asked for.
    """
    rows = []
    for gen in generations:
        item = corpus_by_id.get(gen.item_id)
        if item is None:
            continue
        pm = score_pair(gen.summary, item.reference_summary, item.source_text)
        rows.append(
            {
                "item_id": gen.item_id,
                "source_type": gen.source_type,
                "model_label": gen.model_label,
                "model_id": gen.model_id,
                "run_id": gen.run_id,
                "prompt_id": gen.prompt_id,
                **pm.__dict__,
                "latency_s": gen.latency_s,
                "cost_usd": gen.cost_usd,
                "input_tokens": gen.input_tokens,
                "output_tokens": gen.output_tokens,
                "error": gen.error,
            }
        )
    df = pd.DataFrame(rows)
    if df.empty:
        return df

    ok = df["error"].isna()
    cands = [
        g.summary for g in generations if g.error is None and g.item_id in corpus_by_id
    ]
    refs = [
        corpus_by_id[g.item_id].reference_summary
        for g in generations
        if g.error is None and g.item_id in corpus_by_id
    ]

    reason = None
    if bertscore_available():
        if not bertscore_backbone_cached(bertscore_model):
            warnings.warn(
                f"BERTScore backbone {bertscore_model!r} is not cached locally; "
                "it will be downloaded now (a few hundred megabytes, first run "
                "only). If this machine cannot reach the Hugging Face hub the "
                "attempt will fail after retrying — pre-cache the weights on a "
                "networked machine and copy ~/.cache/huggingface across.",
                RuntimeWarning,
                stacklevel=2,
            )
        try:
            df.loc[ok, "bertscore_f1"] = compute_bertscore(
                cands, refs, bertscore_model, bertscore_num_layers
            )
            df["semantic_metric"] = "bertscore_f1"
        except Exception as exc:  # noqa: BLE001
            # Most commonly: no network on first use, so the backbone weights
            # cannot be downloaded from the Hugging Face hub. Degrade rather
            # than lose an expensive inference run.
            reason = (
                f"bert-score raised {type(exc).__name__}: {exc}. The backbone "
                f"{bertscore_model!r} may not be cached locally — run once with "
                "network access, or pre-download the weights."
            )
    else:
        reason = (
            "bert-score is not installed (`pip install bert-score`)."
        )

    if reason:
        if not allow_semantic_fallback:
            raise BERTScoreUnavailable(
                "BERTScore was not computed and no fallback was authorised. "
                + reason
                + "\n\nEither fix the cause (this is the metric Chapter 6 "
                "reports), or re-run with --allow-semantic-fallback to record "
                "the clearly-labelled TF-IDF proxy instead. The proxy is NOT "
                "BERTScore and must never be reported as such."
            )
        df.loc[ok, "semantic_sim_tfidf"] = compute_tfidf_similarity(cands, refs)
        df["semantic_metric"] = "semantic_sim_tfidf"
        warnings.warn(
            "BERTScore was NOT computed. " + reason + " A clearly-labelled "
            "TF-IDF proxy has been recorded in 'semantic_sim_tfidf' instead; it "
            "is not BERTScore and must not be reported as such. Resolve this "
            "before generating results for submission.",
            RuntimeWarning,
            stacklevel=2,
        )
    return df


# --------------------------------------------------------------------------- #
# Inferential statistics
# --------------------------------------------------------------------------- #

def rank_biserial(x: np.ndarray, y: np.ndarray) -> float:
    """Matched-pairs rank-biserial correlation (effect size for Wilcoxon)."""
    d = np.asarray(x, float) - np.asarray(y, float)
    d = d[d != 0]
    if d.size == 0:
        return 0.0
    ranks = stats.rankdata(np.abs(d))
    r_plus = ranks[d > 0].sum()
    r_minus = ranks[d < 0].sum()
    return float((r_plus - r_minus) / ranks.sum())


def holm_bonferroni(pvals: list[float]) -> list[float]:
    """Holm–Bonferroni step-down adjusted p-values."""
    n = len(pvals)
    order = np.argsort(pvals)
    adjusted = np.empty(n, float)
    running = 0.0
    for rank, idx in enumerate(order):
        val = (n - rank) * pvals[idx]
        running = max(running, val)
        adjusted[idx] = min(1.0, running)
    return adjusted.tolist()


def paired_matrix(df: pd.DataFrame, metric: str) -> pd.DataFrame:
    """Wide table: rows = items present for every model, columns = models."""
    wide = df.pivot_table(
        index="item_id", columns="model_label", values=metric, aggfunc="first"
    )
    return wide.dropna(how="any")


def compare_models(
    df: pd.DataFrame, metric: str, alpha: float = 0.05
) -> tuple[pd.DataFrame, dict]:
    """Friedman omnibus + Holm-corrected pairwise Wilcoxon signed-rank tests."""
    wide = paired_matrix(df, metric)
    models = list(wide.columns)
    omnibus: dict = {"metric": metric, "n_items": int(len(wide))}

    if len(models) >= 3 and len(wide) >= 3:
        chi2, p = stats.friedmanchisquare(*[wide[m].to_numpy() for m in models])
        k, n = len(models), len(wide)
        omnibus.update(
            friedman_chi2=float(chi2),
            friedman_p=float(p),
            kendalls_w=float(chi2 / (n * (k - 1))) if n and k > 1 else float("nan"),
        )

    rows = []
    raw_p = []
    for a, b in combinations(models, 2):
        xa, xb = wide[a].to_numpy(), wide[b].to_numpy()
        if np.allclose(xa, xb):
            stat, p = float("nan"), 1.0
        else:
            stat, p = stats.wilcoxon(xa, xb, zero_method="wilcox")
        raw_p.append(float(p))
        rows.append(
            {
                "metric": metric,
                "model_a": a,
                "model_b": b,
                "median_a": float(np.median(xa)),
                "median_b": float(np.median(xb)),
                "mean_diff": float(np.mean(xa - xb)),
                "wilcoxon_W": float(stat),
                "p_raw": float(p),
                "rank_biserial_r": rank_biserial(xa, xb),
                "n": int(len(wide)),
            }
        )
    out = pd.DataFrame(rows)
    if not out.empty:
        out["p_holm"] = holm_bonferroni(raw_p)
        out["significant"] = out["p_holm"] < alpha
    return out, omnibus


def wilson_ci(successes: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    """Wilson score interval for a proportion.

    Preferred over the normal approximation at the sample sizes used here: it
    stays inside [0, 1] and behaves sensibly when the count is near 0 or n.
    """
    if n <= 0:
        return (float("nan"), float("nan"))
    z = float(stats.norm.ppf(1 - alpha / 2))
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def bootstrap_ci(
    values, n_boot: int = 10000, alpha: float = 0.05, seed: int = 20260612
) -> tuple[float, float]:
    """Percentile bootstrap confidence interval for the mean."""
    x = np.asarray([v for v in values if v is not None and not np.isnan(v)], float)
    if x.size < 2:
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    means = rng.choice(x, size=(n_boot, x.size), replace=True).mean(axis=1)
    lo, hi = np.percentile(means, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return (float(lo), float(hi))


def descriptive_table(df: pd.DataFrame, metrics: list[str]) -> pd.DataFrame:
    """Mean ± SD and median per model per metric, plus per-source-type means."""
    present = [m for m in metrics if m in df.columns]
    agg = (
        df.groupby("model_label")[present]
        .agg(["mean", "std", "median"])
        .round(4)
    )
    agg.columns = [f"{m}_{s}" for m, s in agg.columns]
    return agg.reset_index()
