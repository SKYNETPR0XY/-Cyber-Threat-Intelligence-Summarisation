"""Test suite for the ctieval pipeline.

Run with:  PYTHONPATH=src python -m pytest tests -v

The detector-validity tests are the methodologically important ones: they
measure the precision and recall of the grounding checker against errors whose
ground truth is known by construction, and the figures they print are the
instrument-validity numbers reported in Section 5.5 of the dissertation.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ctieval.collectors import offline  # noqa: E402
from ctieval.config import Config, ModelConfig  # noqa: E402
from ctieval.hallucination import (  # noqa: E402
    check_grounding,
    extract_atoms,
    selfcheck_score,
)
from ctieval.humaneval import icc2k, weighted_cohens_kappa  # noqa: E402
from ctieval.metrics import (  # noqa: E402
    compare_models,
    holm_bonferroni,
    rank_biserial,
    score_all,
    score_pair,
)
from ctieval.prompts import build_prompt  # noqa: E402
from ctieval.providers import get_provider  # noqa: E402
from ctieval.schema import CTIItem, Generation, read_jsonl, write_jsonl  # noqa: E402

REPO = Path(__file__).resolve().parents[1]


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture(scope="module")
def corpus():
    return offline.collect(n_cve=8, n_otx=6, n_apt=6, seed=42)


@pytest.fixture(scope="module")
def mock_run(corpus):
    """Generate summaries with the mock provider, keeping the injection log."""
    cfg = ModelConfig(
        label="Mock", provider="mock", model_id="mock/test",
        extra={"error_rate": 0.8, "seed": 7},
    )
    provider = get_provider(cfg)
    gens = []
    for item in corpus:
        user = build_prompt("cti_summary_v1", item.source_type, item.source_text)
        out = provider.complete("sys", user, temperature=0.0, max_tokens=512)
        gens.append(
            Generation(
                item_id=item.item_id, source_type=item.source_type,
                model_id=cfg.model_id, model_label=cfg.label, summary=out.text,
                prompt_id="cti_summary_v1", temperature=0.0,
                input_chars=len(user), output_chars=len(out.text),
            )
        )
    return gens, provider.injected


# --------------------------------------------------------------------------- #
# Schema
# --------------------------------------------------------------------------- #

def test_schema_roundtrip(tmp_path, corpus):
    path = tmp_path / "c.jsonl"
    assert write_jsonl(path, corpus) == len(corpus)
    back = [CTIItem.from_dict(d) for d in read_jsonl(path)]
    assert len(back) == len(corpus)
    assert back[0].item_id == corpus[0].item_id
    assert back[0].source_sha256 == corpus[0].source_sha256


def test_schema_rejects_bad_source_type():
    with pytest.raises(ValueError):
        CTIItem("x", "not_a_type", "t", "s", "r")


def test_missing_file_raises_clear_error(tmp_path):
    with pytest.raises(FileNotFoundError, match="earlier pipeline stage"):
        list(read_jsonl(tmp_path / "nope.jsonl"))


# --------------------------------------------------------------------------- #
# Prompts and providers
# --------------------------------------------------------------------------- #

def test_prompt_contains_source_and_is_type_aware(corpus):
    item = corpus[0]
    p = build_prompt("cti_summary_v1", item.source_type, item.source_text)
    assert item.source_text.strip()[:40] in p
    assert "vulnerability record" in p  # first item is a CVE


def test_unknown_prompt_id_raises():
    with pytest.raises(KeyError):
        build_prompt("does_not_exist", "cve", "x")


def test_provider_registry_rejects_unknown():
    with pytest.raises(KeyError):
        get_provider(ModelConfig(label="x", provider="nope", model_id="y"))


def test_provider_retries_and_reports_error():
    """A backend that always fails must surface the error, not raise."""
    cfg = ModelConfig(
        label="Down", provider="lmstudio", model_id="none",
        base_url="http://127.0.0.1:9/v1",  # discard port: always refused
    )
    provider = get_provider(cfg)
    provider.max_retries, provider.backoff_s = 1, 0.0
    out = provider.complete("s", "u", temperature=0.0, max_tokens=8)
    assert out.error is not None
    assert out.text == ""


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #

def test_identical_text_scores_one():
    m = score_pair("the quick brown fox", "the quick brown fox", "the quick brown fox")
    assert m.rouge1_f == pytest.approx(1.0)
    assert m.rougeL_f == pytest.approx(1.0)
    assert m.novel_unigram_rate == pytest.approx(0.0)


def test_disjoint_text_scores_zero():
    m = score_pair("alpha beta gamma", "delta epsilon zeta", "delta epsilon zeta")
    assert m.rouge1_f == pytest.approx(0.0)
    assert m.novel_unigram_rate == pytest.approx(1.0)


def test_novel_unigram_rate_detects_unsupported_content():
    m = score_pair(
        "The flaw affects GatewayOS and is exploited by Lazarus Group.",
        "The flaw affects GatewayOS.",
        "The flaw affects GatewayOS.",
    )
    assert m.novel_unigram_rate > 0.3


def test_score_all_produces_one_row_per_generation(corpus, mock_run):
    gens, _ = mock_run
    df = score_all(gens, {i.item_id: i for i in corpus}, allow_semantic_fallback=True)
    assert len(df) == len(gens)
    assert df["rougeL_f"].between(0, 1).all()
    assert df["semantic_metric"].nunique() == 1


# --------------------------------------------------------------------------- #
# Statistics
# --------------------------------------------------------------------------- #

def test_holm_is_monotone_and_conservative():
    raw = [0.001, 0.01, 0.04]
    adj = holm_bonferroni(raw)
    assert all(a >= r for a, r in zip(adj, raw))
    assert adj == sorted(adj)


def test_rank_biserial_signs():
    a, b = np.arange(10.0) + 1, np.arange(10.0)
    assert rank_biserial(a, b) == pytest.approx(1.0)
    assert rank_biserial(b, a) == pytest.approx(-1.0)
    assert rank_biserial(a, a) == 0.0


def test_compare_models_pairs_only_common_items():
    import pandas as pd

    df = pd.DataFrame(
        {
            "item_id": ["a", "a", "b", "b", "c"],
            "model_label": ["M1", "M2", "M1", "M2", "M1"],
            "rougeL_f": [0.5, 0.4, 0.6, 0.3, 0.9],
        }
    )
    tbl, _ = compare_models(df, "rougeL_f")
    assert tbl.iloc[0]["n"] == 2  # item "c" has no M2 pair and is dropped


# --------------------------------------------------------------------------- #
# Hallucination detection
# --------------------------------------------------------------------------- #

def test_atom_extraction_finds_identifiers():
    kinds = {
        a.kind for a in extract_atoms(
            "CVE-2024-1234 (CWE-79) scored 9.8, technique T1566.001, host 192.0.2.5."
        )
    }
    assert {"cve_id", "cwe_id", "cvss_score", "attack_id", "ipv4"} <= kinds


def test_cvss_vector_version_is_not_read_as_a_score():
    """Regression: 'CVSS:3.1/AV:N/...' must not yield a 3.1 base score."""
    atoms = extract_atoms("Rated under CVSS:3.1/AV:N/AC:L/PR:N with a base score of 9.8.")
    scores = {a.value for a in atoms if a.kind == "cvss_score"}
    assert scores == {"9.8"}


def test_faithful_summary_produces_no_findings():
    item = CTIItem(
        item_id="cve::CVE-2099-1", source_type="cve", title="t",
        source_text=(
            "CVE ID: CVE-2099-1\nCVSS base score: 8.8  Severity: HIGH\n"
            "Technical detail: A path traversal flaw in Acme GatewayOS 1.2 allows "
            "a remote attacker to read arbitrary files."
        ),
        reference_summary="A path traversal flaw in Acme GatewayOS 1.2 allows file read.",
        metadata={"cve_id": "CVE-2099-1", "cvss_score": 8.8, "cvss_severity": "HIGH"},
    )
    gen = Generation(
        item_id=item.item_id, source_type="cve", model_id="m", model_label="M",
        summary=(
            "CVE-2099-1 is a path traversal flaw in Acme GatewayOS 1.2 that allows a "
            "remote attacker to read arbitrary files. It has a base score of 8.8."
        ),
        prompt_id="p", temperature=0.0, input_chars=1, output_chars=1,
    )
    assert check_grounding(gen, item) == []


def test_contradicted_score_is_intrinsic_circumstantial():
    item = CTIItem(
        "cve::X", "cve", "t",
        "CVE ID: CVE-2099-2\nCVSS base score: 5.0  Severity: MEDIUM\nDetail: minor issue.",
        "A minor issue.",
        {"cve_id": "CVE-2099-2", "cvss_score": 5.0},
    )
    gen = Generation("cve::X", "cve", "m", "M", "CVE-2099-2 has a base score of 9.8.",
                     "p", 0.0, 1, 1)
    f = check_grounding(gen, item)
    assert any(x.category == "intrinsic" and x.subtype == "circumstantial_error" for x in f)


def test_unsupported_exploitation_claim_is_extrinsic():
    item = CTIItem("cve::Y", "cve", "t", "A flaw exists in Acme GatewayOS.",
                   "A flaw exists in Acme GatewayOS.", {})
    gen = Generation("cve::Y", "cve", "m", "M",
                     "A flaw exists in Acme GatewayOS and is actively exploited in the wild.",
                     "p", 0.0, 1, 1)
    f = check_grounding(gen, item)
    assert any(x.category == "extrinsic" for x in f)


def test_polarity_inversion_is_relational():
    item = CTIItem("cve::Z", "cve", "t",
                   "The flaw allows an unauthenticated attacker to run code.",
                   "The flaw allows code execution.", {})
    gen = Generation("cve::Z", "cve", "m", "M",
                     "The flaw prevents an unauthenticated attacker from running code.",
                     "p", 0.0, 1, 1)
    assert any(x.subtype == "relational_error" for x in check_grounding(gen, item))


def test_detector_validity_against_seeded_errors(corpus, mock_run):
    """Instrument validity: precision/recall against known injected errors."""
    gens, injected = mock_run
    by_id = {i.item_id: i for i in corpus}

    injected_items = {inj["span"].lower() for inj in injected if inj.get("span")}
    detected = set()
    for g in gens:
        for f in check_grounding(g, by_id[g.item_id]):
            detected.add(f.span.lower())

    assert injected, "the mock provider should have injected at least one error"
    recall = len(detected & injected_items) / len(injected_items)
    print(
        f"\n  detector validity: recall={recall:.2f} "
        f"(injected={len(injected_items)}, detected={len(detected)})"
    )
    assert recall >= 0.5, "grounding checker missed most seeded errors"


def test_selfcheck_flags_inconsistent_samples():
    gen = Generation("i", "cve", "m", "M", "The Lazarus Group exploited the flaw.",
                     "p", 0.7, 1, 1,
                     samples=["A patch is available.", "The vendor issued an advisory."])
    high = selfcheck_score(gen)
    gen.samples = ["The Lazarus Group exploited the flaw.",
                   "The Lazarus Group exploited the flaw."]
    low = selfcheck_score(gen)
    assert high > low


def test_selfcheck_returns_none_without_samples():
    assert selfcheck_score(Generation("i", "cve", "m", "M", "x", "p", 0.0, 1, 1)) is None


# --------------------------------------------------------------------------- #
# Human evaluation statistics
# --------------------------------------------------------------------------- #

def test_weighted_kappa_bounds():
    a = np.array([1, 2, 3, 4, 5, 1, 2, 3])
    assert weighted_cohens_kappa(a, a) == pytest.approx(1.0)
    assert weighted_cohens_kappa(a, np.array([5, 4, 3, 2, 1, 5, 4, 3])) < 0.2


def test_icc_high_for_agreeing_raters():
    ratings = np.array([[5, 5], [4, 4], [3, 3], [2, 2], [1, 1]], float)
    assert icc2k(ratings) > 0.95


def test_blinded_sheet_hides_model_identity(tmp_path, corpus, mock_run):
    from ctieval.humaneval import DIMENSIONS, build_sheet

    gens, _ = mock_run
    sheet, key = tmp_path / "s.csv", tmp_path / "k.csv"
    df = build_sheet(gens, {i.item_id: i for i in corpus}, sheet, key, items_per_source_type=3)
    assert not df.empty
    text = sheet.read_text()
    assert "mock/test" not in text  # model identity must not leak to the rater
    assert all(d in df.columns for d in DIMENSIONS)
    assert "model_id" in key.read_text()


# --------------------------------------------------------------------------- #
# Collectors and configuration
# --------------------------------------------------------------------------- #

def test_offline_corpus_is_marked_synthetic(corpus):
    assert all(i.metadata.get("synthetic") is True for i in corpus)
    assert {i.source_type for i in corpus} == {"cve", "otx", "apt"}


def test_offline_corpus_is_deterministic():
    a = offline.collect(seed=99)
    b = offline.collect(seed=99)
    assert [x.source_text for x in a] == [x.source_text for x in b]


@pytest.mark.skipif(
    not (REPO / "data/apt_pdfs/sample.pdf").exists(), reason="no sample PDF present"
)
def test_pdf_sections_are_extracted():
    from ctieval.collectors.apt_pdf import parse_pdf

    secs = parse_pdf(REPO / "data/apt_pdfs/sample.pdf")
    headings = {s["heading"] for s in secs}
    assert "Executive Summary" in headings
    assert any(len(s["text"].split()) > 100 for s in secs)


def test_config_never_reads_keys_from_file():
    cfg = Config.load(REPO / "config/config.yaml")
    assert "api_key" not in cfg.raw.get("models", [{}])[0]
    for m in cfg.models:
        assert not any(
            k in (m.extra or {}) for k in ("api_key", "key", "token")
        )


def test_run_limit_restricts_item_count(tmp_path):
    """`run --limit N` must generate at most N items, interleaving source types."""
    from types import SimpleNamespace

    from ctieval.cli import cmd_run
    from ctieval.config import Config

    cfg = Config.load(REPO / "config/config.demo.yaml")
    corpus_path = tmp_path / "c.jsonl"
    write_jsonl(corpus_path, offline.collect(n_cve=5, n_otx=5, n_apt=5, seed=1))
    gen_path = tmp_path / "g.jsonl"
    cfg.paths["corpus"] = str(corpus_path)
    cfg.paths["generations"] = str(gen_path)

    args = SimpleNamespace(
        limit=6, models=None, prompt=None, no_resume=True, allow_unreferenced=True
    )
    assert cmd_run(args, cfg) == 0
    produced = list(read_jsonl(gen_path))
    n_models = len(cfg.models)
    # 6 items x n_models generations, and more than one source type represented.
    assert len(produced) == 6 * n_models
    assert len({g["source_type"] for g in produced}) > 1


def test_report_refuses_synthetic_without_flag(tmp_path, corpus, mock_run):
    import pandas as pd
    from ctieval.report import build_results_pack

    gens, _ = mock_run
    df = score_all(gens, {i.item_id: i for i in corpus}, allow_semantic_fallback=True)
    with pytest.raises(RuntimeError, match="synthetic"):
        build_results_pack(df, pd.DataFrame(), {}, {}, tmp_path, synthetic=True)


# =========================================================================== #
# Regression tests for the fixes applied on 2026-09-01.
# Each one pins a defect found by running the pipeline end to end; see
# docs/DISSERTATION_AND_PIPELINE_REVIEW.md for the corresponding issue id.
# =========================================================================== #

import json as _json
import subprocess as _subprocess
import sys as _sys

import pandas as _pd
import pytest as _pytest

from pathlib import Path as _Path

from ctieval.collectors import apt_pdf as _apt_pdf
from ctieval.collectors import offline as _offline
from ctieval.hallucination import (
    _extract_json,
    check_grounding as _check_grounding,
    validate_detector as _validate_detector,
)
from ctieval.metrics import (
    BERTScoreUnavailable as _BERTScoreUnavailable,
    bootstrap_ci as _bootstrap_ci,
    score_all as _score_all,
    wilson_ci as _wilson_ci,
)
from ctieval.providers.mock import source_key as _source_key
from ctieval.report import METRIC_LABELS as _LABELS, metric_label as _metric_label
from ctieval.schema import HallucinationFinding as _Finding


PROJECT = _Path(__file__).resolve().parents[1] if "_Path" in dir() else None


def _cli(*args, cwd):
    """Run the CLI in a subprocess and return (returncode, stdout+stderr)."""
    proc = _subprocess.run(
        [_sys.executable, "-m", "ctieval", *args],
        cwd=str(cwd), capture_output=True, text=True, timeout=300,
    )
    return proc.returncode, proc.stdout + proc.stderr


# --- B1: BERTScore may no longer degrade silently ------------------------- #

def test_score_all_refuses_to_substitute_the_proxy_by_default(corpus, mock_run):
    """A results table must never carry a column that is not the metric named."""
    gens, _injected = mock_run
    with _pytest.raises(_BERTScoreUnavailable) as exc:
        _score_all(gens, {i.item_id: i for i in corpus})
    assert "NOT BERTScore" in str(exc.value)


def test_score_all_fallback_is_explicit_and_labelled(corpus, mock_run):
    gens_, _injected = mock_run
    df = _score_all(gens_, {i.item_id: i for i in corpus},
                    allow_semantic_fallback=True)
    assert df["semantic_metric"].iloc[0] == "semantic_sim_tfidf"
    assert "bertscore_f1" not in df.columns
    assert len(gens_) == len(df)


# --- B3: detector validation matches per finding, not per span string ----- #

def test_detector_validation_matches_per_item_not_per_span():
    """The same span in two items is two findings, not one set entry."""
    injected = [
        {"span": "Lazarus Group", "source_key": "k1", "model_id": "m1"},
        {"span": "Lazarus Group", "source_key": "k2", "model_id": "m1"},
    ]
    mapping = {"k1": "item-1", "k2": "item-2"}
    caught_one = [
        _Finding(item_id="item-1", model_id="m1", span="Lazarus Group",
                 category="extrinsic", subtype="fabrication", evidence="",
                 detector="grounding"),
    ]
    per_finding = _validate_detector(caught_one, injected, mapping)
    assert per_finding["method"].startswith("per (")
    assert per_finding["n_injected"] == 2          # not collapsed to 1
    assert per_finding["recall"] == 0.5            # one of two caught
    assert per_finding["false_negatives"] == 1

    # Without the mapping the function must SAY it is degraded, not pretend.
    degraded = _validate_detector(caught_one, injected, None)
    assert "span sets" in degraded["method"]
    assert degraded["n_injected"] == 1             # the collapse it used to hide


def test_detector_validation_counts_false_positives():
    injected = [{"span": "7.7", "source_key": "k1", "model_id": "m1"}]
    findings = [
        _Finding(item_id="i1", model_id="m1", span="7.7", category="intrinsic",
                 subtype="circumstantial_error", evidence="", detector="grounding"),
        _Finding(item_id="i1", model_id="m1", span="GitHub", category="extrinsic",
                 subtype="fabrication", evidence="", detector="grounding"),
    ]
    out = _validate_detector(findings, injected, {"k1": "i1"})
    assert out["true_positives"] == 1 and out["false_positives"] == 1
    assert out["precision"] == 0.5 and out["recall"] == 1.0


def test_mock_provider_records_the_pair_it_injected_into(corpus):
    from ctieval.config import ModelConfig
    from ctieval.prompts import SYSTEM_PROMPT, build_prompt
    from ctieval.providers.mock import MockProvider

    p = MockProvider(ModelConfig(label="m", provider="mock", model_id="mock/x",
                                 extra={"error_rate": 1.0, "seed": 5}))
    item = corpus[0]
    p.complete(SYSTEM_PROMPT,
               build_prompt("cti_summary_v1", item.source_type, item.source_text),
               temperature=0.0, max_tokens=256)
    assert p.injected, "an error rate of 1.0 must inject something"
    rec = p.injected[0]
    assert rec["model_id"] == "mock/x"
    assert rec["source_key"] == _source_key(item.source_text)


# --- N6: the LLM judge's JSON extraction ---------------------------------- #

def test_judge_json_extraction_handles_prose_and_fences():
    assert _extract_json('{"findings": []}') == {"findings": []}
    assert _extract_json('```json\n{"findings": [1]}\n```') == {"findings": [1]}
    # Prose after the object: a greedy {.*} match spans to the last brace and
    # fails to parse. This is the case that silently returned zero findings.
    assert _extract_json('Sure! {"findings": []} Let me know if you need more.') == {
        "findings": []
    }
    # A brace inside a string literal must not end the object.
    assert _extract_json('{"span": "a } b", "findings": []}')["span"] == "a } b"
    assert _extract_json("no json here") is None
    assert _extract_json("") is None


def test_judge_parses_a_realistic_reply(corpus):
    """Exercises judge_with_llm against a provider that returns real JSON."""
    from ctieval.hallucination import judge_with_llm
    from ctieval.providers.base import Completion
    from ctieval.schema import Generation

    class _JudgeStub:
        def complete(self, system, user, *, temperature, max_tokens):
            return Completion(text=(
                'Here is my assessment:\n'
                '{"findings": [{"span": "actively exploited", '
                '"category": "extrinsic", "subtype": "fabrication", '
                '"evidence": "not stated in the source"}]}\n'
                'Hope that helps.'
            ))

    gen = Generation(item_id=corpus[0].item_id, source_type=corpus[0].source_type,
                     model_id="m", model_label="M", summary="It is actively exploited.",
                     prompt_id="p", temperature=0.0, input_chars=1, output_chars=1)
    out = judge_with_llm(gen, corpus[0], _JudgeStub())
    assert len(out) == 1
    assert out[0].detector == "llm_judge"
    assert out[0].category == "extrinsic" and out[0].subtype == "fabrication"


def test_judge_survives_a_non_json_reply(corpus):
    from ctieval.hallucination import judge_with_llm
    from ctieval.providers.base import Completion
    from ctieval.schema import Generation

    class _Chatty:
        def complete(self, system, user, *, temperature, max_tokens):
            return Completion(text="I could not find any errors.")

    gen = Generation(item_id=corpus[0].item_id, source_type=corpus[0].source_type,
                     model_id="m", model_label="M", summary="x",
                     prompt_id="p", temperature=0.0, input_chars=1, output_chars=1)
    assert judge_with_llm(gen, corpus[0], _Chatty()) == []


# --- B6: human-evaluation sample size ------------------------------------- #

def test_human_sheet_samples_the_requested_number_of_items(corpus, mock_run, tmp_path):
    from ctieval.humaneval import build_sheet

    gens, _injected = mock_run
    sheet, key = tmp_path / "s.csv", tmp_path / "k.csv"
    df = build_sheet(gens, {i.item_id: i for i in corpus}, sheet, key,
                     items_per_source_type=2)
    k = _pd.read_csv(key)
    n_models = k["model_id"].nunique()
    n_types = k["source_type"].nunique()
    # Two ITEMS per source type, every model's output for each.
    assert k.groupby("source_type")["item_id"].nunique().eq(2).all()
    assert len(df) == 2 * n_types * n_models
    assert df.attrs["n_items_sampled"] == 2 * n_types
    assert df.attrs["n_rows"] == len(df)


# --- F1/F2: figure defects ------------------------------------------------ #

def test_metric_labels_do_not_mangle_bertscore():
    # "bertscore_f1".replace("_f", "") == "bertscore1"
    assert _metric_label("bertscore_f1") == "BERTScore F1"
    assert _metric_label("rougeL_f") == "ROUGE-L"
    assert "not BERTScore" in _LABELS["semantic_sim_tfidf"]


def test_hallucination_categories_are_mutually_exclusive_in_the_figure():
    """The stacked bar must sum to the affected rate, not exceed it."""
    import matplotlib
    matplotlib.use("Agg")
    from ctieval.report import fig_hallucination

    gens = _pd.DataFrame([
        {"item_id": f"i{n}", "model_label": "M", "latency_s": 1.0, "cost_usd": 0.0}
        for n in range(4)
    ])
    # i0 carries BOTH an intrinsic and an extrinsic finding.
    halluc = _pd.DataFrame([
        {"item_id": "i0", "model_label": "M", "category": "intrinsic",
         "subtype": "entity_error"},
        {"item_id": "i0", "model_label": "M", "category": "extrinsic",
         "subtype": "fabrication"},
        {"item_id": "i1", "model_label": "M", "category": "extrinsic",
         "subtype": "fabrication"},
    ])
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        out = _Path(d) / "f.png"
        fig_hallucination(halluc, gens, out, synthetic=True)
        assert out.exists()

    from ctieval.report import hallucination_rates
    rates = hallucination_rates(halluc, gens)
    assert rates.loc[0, "Flagged"] == 2          # i0 and i1
    assert rates.loc[0, "Flagged %"] == 50.0     # 2 of 4, NOT 25+50=75
    assert rates.loc[0, "Findings"] == 3         # atoms, not summaries


# --- F5: interval estimation ---------------------------------------------- #

def test_wilson_interval_brackets_the_point_estimate():
    lo, hi = _wilson_ci(15, 90)
    assert lo < 15 / 90 < hi
    assert 0.0 <= lo and hi <= 1.0
    # Degenerate counts stay inside [0, 1] rather than going negative.
    assert _wilson_ci(0, 30)[0] >= 0.0
    assert _wilson_ci(30, 30)[1] <= 1.0
    assert all(v != v for v in _wilson_ci(0, 0))  # NaN on an empty sample


def test_bootstrap_interval_brackets_the_mean():
    xs = [0.4 + 0.01 * n for n in range(40)]
    lo, hi = _bootstrap_ci(xs, n_boot=2000)
    mean = sum(xs) / len(xs)
    assert lo < mean < hi
    assert all(v != v for v in _bootstrap_ci([0.5], n_boot=10))  # NaN when n < 2


def test_rates_table_reports_wilson_intervals_and_names_them_flagged():
    from ctieval.report import hallucination_rates

    gens = _pd.DataFrame([{"item_id": f"i{n}", "model_label": "M"} for n in range(90)])
    halluc = _pd.DataFrame([
        {"item_id": f"i{n}", "model_label": "M", "category": "extrinsic",
         "subtype": "fabrication"} for n in range(15)
    ])
    t = hallucination_rates(halluc, gens)
    assert "Flagged %" in t.columns and "95% CI" in t.columns
    assert "Rate %" not in t.columns  # renamed: these are not adjudicated rates
    assert t.loc[0, "95% CI"] == "[10.4, 25.7]"


def test_rates_table_reports_confirmed_rate_after_adjudication():
    from ctieval.report import hallucination_rates

    gens = _pd.DataFrame([{"item_id": f"i{n}", "model_label": "M"} for n in range(10)])
    halluc = _pd.DataFrame([
        {"item_id": "i0", "model_label": "M", "category": "extrinsic",
         "subtype": "fabrication", "confirmed": True},
        {"item_id": "i1", "model_label": "M", "category": "extrinsic",
         "subtype": "fabrication", "confirmed": False},
    ])
    t = hallucination_rates(halluc, gens)
    assert t.loc[0, "Flagged"] == 2 and t.loc[0, "Confirmed"] == 1
    assert t.loc[0, "Detector precision"] == 0.5


# --- N2: APT sections must not silently share one reference --------------- #

def test_apt_sections_do_not_share_the_executive_summary_by_default():
    pdf_dir = _Path(__file__).resolve().parents[1] / "data" / "apt_pdfs"
    if not list(pdf_dir.glob("*.pdf")):
        _pytest.skip("no sample PDF available")
    items = _apt_pdf.collect(pdf_dir, min_words=50, require_reference=False)
    assert items, "the sample PDF should yield sections"
    # Every section is flagged for annotation rather than handed a shared ref.
    assert all(i.metadata["needs_reference_summary"] for i in items)
    assert all(not i.metadata["reference_shared"] for i in items)

    shared = _apt_pdf.collect(pdf_dir, min_words=50, require_reference=False,
                              share_executive_summary=True)
    if len(shared) > 1 and shared[0].reference_summary:
        # Opt-in restores the old behaviour, but marks it in the corpus so the
        # choice is visible rather than silent.
        assert all(i.metadata["reference_shared"] for i in shared)
        assert all(i.metadata["needs_reference_summary"] for i in shared)


# --- N3: collectors degrade gracefully ------------------------------------ #

def test_collector_http_retries_then_raises_a_clean_error(monkeypatch):
    from ctieval.collectors import _http

    calls = {"n": 0}

    class _Resp:
        status_code = 503
        def raise_for_status(self): raise AssertionError("should not be reached")

    def _fake_get(*a, **k):
        calls["n"] += 1
        return _Resp()

    monkeypatch.setattr(_http.requests, "get", _fake_get)
    monkeypatch.setattr(_http.time, "sleep", lambda *_: None)
    with _pytest.raises(_http.CollectorError) as exc:
        _http.get_json("https://example.invalid", max_attempts=3, source="the test API")
    assert calls["n"] == 3
    assert "503" in str(exc.value) and "the test API" in str(exc.value)


def test_collector_http_recovers_after_a_transient_failure(monkeypatch):
    from ctieval.collectors import _http

    seq = iter([503, 200])

    class _Resp:
        def __init__(self, code): self.status_code = code
        def raise_for_status(self): pass
        def json(self): return {"ok": True}

    monkeypatch.setattr(_http.requests, "get", lambda *a, **k: _Resp(next(seq)))
    monkeypatch.setattr(_http.time, "sleep", lambda *_: None)
    assert _http.get_json("https://example.invalid", max_attempts=3) == {"ok": True}


# --- B4: the offline collector honours its size arguments ----------------- #

def test_offline_collector_is_sizeable():
    items = _offline.collect(n_cve=30, n_otx=30, n_apt=30, seed=1)
    assert len(items) == 90
    counts = {t: sum(1 for i in items if i.source_type == t) for t in ("cve", "otx", "apt")}
    assert counts == {"cve": 30, "otx": 30, "apt": 30}


# --------------------------------------------------------------------------- #
# CLI-level integration tests. These run the real entry point in-process so the
# argument wiring is covered, not just the functions behind it.
# --------------------------------------------------------------------------- #

def _write_cfg(tmp_path, **overrides):
    """A mock-only config rooted entirely inside tmp_path."""
    import yaml
    base = {
        "experiment": {"run_id": "test", "seed": 1, "prompt_id": "cti_summary_v1",
                       "temperature": 0.0, "max_tokens": 256, "alpha": 0.05},
        "models": [
            {"label": "Mock-A", "provider": "mock", "model_id": "mock/a",
             "extra": {"error_rate": 0.3, "seed": 11}},
            {"label": "Mock-B", "provider": "mock", "model_id": "mock/b",
             "extra": {"error_rate": 0.6, "seed": 22}},
        ],
        "paths": {
            "corpus": str(tmp_path / "corpus.jsonl"),
            "generations": str(tmp_path / "generations.jsonl"),
            "metrics": str(tmp_path / "metrics.csv"),
            "hallucinations": str(tmp_path / "hallucinations.jsonl"),
            "human_sheet": str(tmp_path / "human_eval_sheet.csv"),
            "human_scores": str(tmp_path / "human_scores.csv"),
            "report_dir": str(tmp_path / "report"),
            "provenance": str(tmp_path / "provenance.csv"),
        },
    }
    base.update(overrides)
    cfg_path = tmp_path / "cfg.yaml"
    cfg_path.write_text(yaml.safe_dump(base), encoding="utf-8")
    return cfg_path


def test_demo_refuses_to_overwrite_a_real_corpus(tmp_path, capsys):
    """The documented one-liner used to destroy a collected corpus."""
    from ctieval.cli import main
    from ctieval.schema import write_jsonl

    cfg_path = _write_cfg(tmp_path)
    real = _offline.collect(n_cve=1, n_otx=1, n_apt=1, seed=3)
    for item in real:
        item.metadata.pop("synthetic", None)  # pretend these were really collected
    write_jsonl(tmp_path / "corpus.jsonl", real)
    before = (tmp_path / "corpus.jsonl").read_text(encoding="utf-8")

    rc = main(["--config", str(cfg_path), "demo"])
    assert rc == 1
    assert "Refusing to overwrite" in capsys.readouterr().err
    assert (tmp_path / "corpus.jsonl").read_text(encoding="utf-8") == before


def test_demo_overwrites_a_synthetic_corpus_without_complaint(tmp_path):
    from ctieval.cli import main

    cfg_path = _write_cfg(tmp_path)
    assert main(["--config", str(cfg_path), "demo"]) == 0
    assert (tmp_path / "report" / "results_pack.md").exists()


def test_demo_switches_away_from_a_config_with_real_backends(tmp_path, capsys):
    """A config naming live backends must not be used by the dry run."""
    import yaml
    from ctieval.cli import main

    cfg_path = _write_cfg(tmp_path)
    data = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    data["models"] = [{"label": "Claude", "provider": "anthropic",
                       "model_id": "x", "api_key_env": "NOPE_NOT_SET"}]
    cfg_path.write_text(yaml.safe_dump(data), encoding="utf-8")

    main(["--config", str(cfg_path), "demo"])
    out = capsys.readouterr().out
    assert "Switching to the dry-run configuration" in out
    # and it must not have touched the corpus path the real config named
    assert not (tmp_path / "corpus.jsonl").exists()


def test_annotate_export_writes_a_header_when_nothing_is_pending(tmp_path):
    """A zero-byte export used to crash the matching import."""
    from ctieval.cli import main
    from ctieval.schema import write_jsonl

    cfg_path = _write_cfg(tmp_path)
    write_jsonl(tmp_path / "corpus.jsonl", _offline.collect(n_cve=2, n_otx=0, n_apt=0, seed=4))
    work = tmp_path / "refs.csv"

    assert main(["--config", str(cfg_path), "annotate", "--export",
                 "--file", str(work)]) == 0
    df = _pd.read_csv(work)          # would raise EmptyDataError before the fix
    assert list(df.columns) == ["item_id", "source_type", "title",
                                "SOURCE_TEXT", "reference_summary"]
    assert len(df) == 0
    # And the import path reports an empty file instead of tracing back.
    (tmp_path / "empty.csv").write_text("", encoding="utf-8")
    assert main(["--config", str(cfg_path), "annotate",
                 "--import", str(tmp_path / "empty.csv")]) == 1


def test_annotate_round_trip(tmp_path):
    from ctieval.cli import main
    from ctieval.schema import load_corpus, write_jsonl

    cfg_path = _write_cfg(tmp_path)
    items = _offline.collect(n_cve=2, n_otx=0, n_apt=0, seed=5)
    for i in items:
        i.reference_summary = ""
    write_jsonl(tmp_path / "corpus.jsonl", items)
    work = tmp_path / "refs.csv"

    assert main(["--config", str(cfg_path), "annotate", "--export",
                 "--file", str(work)]) == 0
    df = _pd.read_csv(work)
    assert len(df) == 2
    df["reference_summary"] = "An authored analyst summary."
    df.to_csv(work, index=False)
    assert main(["--config", str(cfg_path), "annotate", "--import", str(work)]) == 0
    after = load_corpus(tmp_path / "corpus.jsonl")
    assert all(i.reference_summary == "An authored analyst summary." for i in after)
    assert all(i.metadata["reference_source"] == "researcher_authored" for i in after)


def test_score_exits_cleanly_without_bertscore(tmp_path, capsys):
    from ctieval.cli import main

    cfg_path = _write_cfg(tmp_path)
    assert main(["--config", str(cfg_path), "demo"]) == 0
    # A fresh score run without the flag must fail loudly, not degrade silently.
    rc = main(["--config", str(cfg_path), "score"])
    assert rc == 3
    assert "NOT BERTScore" in capsys.readouterr().err


def test_detect_writes_detector_validation_and_report_consumes_it(tmp_path):
    from ctieval.cli import main

    cfg_path = _write_cfg(tmp_path)
    assert main(["--config", str(cfg_path), "demo"]) == 0
    validation = tmp_path / "detector_validation.csv"
    assert validation.exists(), "detect must persist the validation for report"
    row = _pd.read_csv(validation).iloc[0]
    assert row["method"].startswith("per (")
    assert 0.0 <= row["recall"] <= 1.0
    pack = (tmp_path / "report" / "results_pack.md").read_text(encoding="utf-8")
    assert "Table 6.5" in pack          # the slot Chapter 6 reserves
    assert "Table 6.1b" in pack         # bootstrap intervals
    assert "detector-flagged" in pack.lower()


def test_adjudicate_round_trip_changes_the_reported_rate(tmp_path):
    from ctieval.cli import main

    cfg_path = _write_cfg(tmp_path)
    assert main(["--config", str(cfg_path), "demo"]) == 0
    work = tmp_path / "adjudication.csv"

    assert main(["--config", str(cfg_path), "adjudicate", "--export", str(work)]) == 0
    df = _pd.read_csv(work, comment="#")
    assert {"finding_id", "confirmed", "span", "category"} <= set(df.columns)
    assert len(df) > 0

    # Confirm the first half, reject the rest.
    half = len(df) // 2
    df["confirmed"] = ["TRUE"] * half + ["FALSE"] * (len(df) - half)
    df.to_csv(work, index=False)
    assert main(["--config", str(cfg_path), "adjudicate", "--import", str(work)]) == 0

    rows = [_json.loads(l) for l in
            (tmp_path / "hallucinations.jsonl").read_text(encoding="utf-8").splitlines()]
    assert sum(1 for r in rows if r.get("confirmed") is True) == half
    assert sum(1 for r in rows if r.get("confirmed") is False) == len(df) - half

    # The report must now lead with the confirmed rate.
    assert main(["--config", str(cfg_path), "report", "--allow-synthetic"]) == 0
    pack = (tmp_path / "report" / "results_pack.md").read_text(encoding="utf-8")
    assert "human-confirmed" in pack
    rates = _pd.read_csv(tmp_path / "report" / "table_hallucination_rates.csv")
    assert "Confirmed %" in rates.columns and "Detector precision" in rates.columns


def test_humaneval_build_and_analyse_end_to_end(tmp_path):
    import numpy as _np
    from ctieval.cli import main
    from ctieval.humaneval import DIMENSIONS

    cfg_path = _write_cfg(tmp_path)
    assert main(["--config", str(cfg_path), "demo"]) == 0
    assert main(["--config", str(cfg_path), "humaneval", "build", "--n", "2"]) == 0

    sheet = _pd.read_csv(tmp_path / "human_eval_sheet.csv", comment="#")
    key = _pd.read_csv(tmp_path / "human_eval_key.csv")
    assert key.groupby("source_type")["item_id"].nunique().eq(2).all()
    assert "model_label" not in sheet.columns, "the sheet must stay blinded"

    rng = _np.random.default_rng(0)
    files = []
    for name in ("rater1", "rater2"):
        r = sheet[["eval_id"]].copy()
        for d in DIMENSIONS:
            r[d] = rng.integers(1, 6, len(r))
        r["notes"] = ""
        path = tmp_path / f"{name}.csv"
        r.to_csv(path, index=False)
        files.append(f"{name}={path}")

    assert main(["--config", str(cfg_path), "humaneval", "analyse",
                 "--scores", files[0], "--scores", files[1]]) == 0
    long = _pd.read_csv(tmp_path / "human_scores.csv")
    assert "model_label" in long.columns and "composite" in long.columns
    assert main(["--config", str(cfg_path), "report", "--allow-synthetic"]) == 0
    pack = (tmp_path / "report" / "results_pack.md").read_text(encoding="utf-8")
    assert "Table 6.6" in pack


def test_collect_offline_honours_the_size_flags(tmp_path):
    from ctieval.cli import main
    from ctieval.schema import load_corpus

    cfg_path = _write_cfg(tmp_path)
    assert main(["--config", str(cfg_path), "collect", "--source", "offline",
                 "--n-cve", "30", "--n-otx", "30", "--n-apt", "30"]) == 0
    corpus = load_corpus(tmp_path / "corpus.jsonl")
    assert len(corpus) == 90


def test_collect_reports_a_missing_key_without_a_traceback(tmp_path, capsys, monkeypatch):
    from ctieval.cli import main

    monkeypatch.delenv("OTX_API_KEY", raising=False)
    cfg_path = _write_cfg(tmp_path)
    rc = main(["--config", str(cfg_path), "collect", "--source", "otx"])
    assert rc == 2
    err = capsys.readouterr().err
    assert "Collection failed" in err and "OTX_API_KEY" in err


def test_selfcheck_scores_reach_the_results_pack(tmp_path):
    import yaml
    from ctieval.cli import main

    cfg_path = _write_cfg(tmp_path)
    data = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    data["experiment"]["selfcheck_samples"] = 2
    cfg_path.write_text(yaml.safe_dump(data), encoding="utf-8")

    assert main(["--config", str(cfg_path), "demo"]) == 0
    assert (tmp_path / "selfcheck_scores.csv").exists()
    assert main(["--config", str(cfg_path), "report", "--allow-synthetic"]) == 0
    pack = (tmp_path / "report" / "results_pack.md").read_text(encoding="utf-8")
    assert "SelfCheckGPT consistency" in pack
    assert (tmp_path / "report" / "table_selfcheck.csv").exists()


# --------------------------------------------------------------------------- #
# Repository hygiene. Section 5.3.4 commits to credentials never touching the
# code, the configuration or the results; a real Anthropic key and a real OTX
# key were once committed in .env.example, which .gitignore does not cover.
# This fails the build if anything credential-shaped comes back.
# --------------------------------------------------------------------------- #

SECRET_PATTERNS = {
    "anthropic key": r"sk-ant-[A-Za-z0-9_\-]{20,}",
    "openai key": r"\bsk-[A-Za-z0-9]{32,}\b",
    "aws access key": r"\bAKIA[0-9A-Z]{16}\b",
    "github token": r"\bgh[pousr]_[A-Za-z0-9]{30,}\b",
    "slack token": r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b",
    "private key block": r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
    "otx-style 64-hex secret": r"(?i)(otx|api|secret|token)_?key\s*[=:]\s*[a-f0-9]{64}",
}

SCANNED_SUFFIXES = {".py", ".yaml", ".yml", ".md", ".txt", ".json", ".cfg",
                    ".toml", ".ini", ".example", ".env", ".sh", ".ps1"}
SKIP_DIRS = {".git", "__pycache__", "results", ".pytest_cache", "node_modules",
             "site-packages", "dist-packages", ".tox", ".mypy_cache", "models"}


def _virtualenv_roots(root: _Path) -> set[_Path]:
    """Any directory holding a pyvenv.cfg is a virtual environment.

    Matching on the name alone missed environments called anything other than
    .venv or venv, and then the scan walked site-packages and flagged strings
    inside third-party code. The marker file is what actually identifies one.
    """
    roots = set()
    for depth in ("*/pyvenv.cfg", "*/*/pyvenv.cfg"):
        for marker in root.glob(depth):
            roots.add(marker.parent)
    return roots


def _repo_files():
    root = _Path(__file__).resolve().parents[1]
    venvs = _virtualenv_roots(root)
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        if any(v in p.parents for v in venvs):
            continue
        if p.suffix.lower() in SCANNED_SUFFIXES or p.name.startswith(".env"):
            yield p


def test_no_credentials_are_committed_anywhere_in_the_repo():
    import re as _re

    hits = []
    for path in _repo_files():
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for name, pattern in SECRET_PATTERNS.items():
            for m in _re.finditer(pattern, text):
                line = text[: m.start()].count("\n") + 1
                hits.append(f"{path.name}:{line} looks like a {name}")
    assert not hits, (
        "Credential-shaped strings found in the repository:\n  "
        + "\n  ".join(hits)
        + "\n\nRotate the credential, then replace the value with a placeholder. "
        "Section 5.3.4 promises no key ever enters the code, the configuration "
        "or the results."
    )


def test_env_example_is_a_template_not_a_key_store():
    env = _Path(__file__).resolve().parents[1] / ".env.example"
    if not env.exists():
        _pytest.skip(".env.example not present")
    for raw in env.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        assert "=" in line, f"malformed line in .env.example: {raw!r}"
        key, _, value = line.partition("=")
        # Only a local, non-secret default may carry a value.
        if key.strip() == "LOCAL_LLM_BASE_URL":
            continue
        assert value.strip() == "", (
            f"{key.strip()} has a value in .env.example. This file is not "
            "git-ignored — it must ship empty."
        )


def test_mock_provider_is_reproducible_across_processes():
    """The provider seeds from a digest, not from the PYTHONHASHSEED-salted hash().

    Seeding from hash() made the harness reproducible within one process and
    different between runs, so detector-validation figures drifted every time the
    dry run was executed.
    """
    import subprocess as sp
    import sys as _s

    script = (
        "from ctieval.config import ModelConfig;"
        "from ctieval.providers.mock import MockProvider;"
        "from ctieval.collectors import offline;"
        "from ctieval.prompts import SYSTEM_PROMPT, build_prompt;"
        "p=MockProvider(ModelConfig(label='m',provider='mock',model_id='mock/x',"
        "extra={'error_rate':0.5,'seed':11}));"
        "items=offline.collect(n_cve=6,n_otx=0,n_apt=0,seed=1);"
        "[p.complete(SYSTEM_PROMPT, build_prompt('cti_summary_v1',i.source_type,"
        "i.source_text), temperature=0.0, max_tokens=256) for i in items];"
        "print(len(p.injected), sorted(r['subtype'] for r in p.injected))"
    )
    runs = set()
    for salt in ("0", "1", "12345"):
        env = dict(__import__("os").environ, PYTHONHASHSEED=salt)
        out = sp.run([_s.executable, "-c", script], capture_output=True, text=True,
                     env=env, timeout=120)
        assert out.returncode == 0, out.stderr
        runs.add(out.stdout.strip())
    assert len(runs) == 1, f"provider is not reproducible across hash seeds: {runs}"


# --------------------------------------------------------------------------- #
# BERTScore. The metric normally needs a Hugging Face download, so on a machine
# without hub access the code path went untested until the day of the real run.
# These build a tiny local backbone and exercise the genuine bert-score library.
# --------------------------------------------------------------------------- #

def _have_bertscore():
    try:
        import bert_score  # noqa: F401
        import transformers  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


@_pytest.fixture(scope="module")
def tiny_backbone(tmp_path_factory):
    if not _have_bertscore():
        _pytest.skip("bert-score / transformers not installed")
    from transformers import DistilBertConfig, DistilBertModel, DistilBertTokenizerFast

    out = tmp_path_factory.mktemp("tiny-bertscore")
    vocab = ["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"]
    vocab += [chr(c) for c in range(ord("a"), ord("z") + 1)]
    vocab += [f"##{chr(c)}" for c in range(ord("a"), ord("z") + 1)]
    vocab += [str(d) for d in range(10)]
    vocab += ["the", "a", "vulnerability", "attacker", "remote", "summary", "cve"]
    (out / "vocab.txt").write_text("\n".join(vocab) + "\n", encoding="utf-8")
    # A deliberately roomy position limit: this fixture exists to test the
    # scoring path, not the truncation guard, which has its own test below.
    cfg = DistilBertConfig(vocab_size=len(vocab), dim=64, n_layers=2, n_heads=2,
                           hidden_dim=128, max_position_embeddings=2048)
    DistilBertModel(cfg).save_pretrained(out)
    DistilBertTokenizerFast(vocab_file=str(out / "vocab.txt"),
                            do_lower_case=True).save_pretrained(out)
    return str(out)


def test_backbone_cache_check_is_fast_and_honest(tiny_backbone):
    """Knowing the backbone is absent up front avoids a multi-minute retry stall."""
    from ctieval.metrics import bertscore_backbone_cached

    assert bertscore_backbone_cached(tiny_backbone) is True
    assert bertscore_backbone_cached("definitely/not-a-real-model-xyz") is False


def test_real_bertscore_runs_end_to_end(corpus, mock_run, tiny_backbone):
    """The genuine bert-score library, exercised with no network access."""
    gens, _injected = mock_run
    df = _score_all(gens, {i.item_id: i for i in corpus},
                    bertscore_model=tiny_backbone, bertscore_num_layers=2)
    assert df["semantic_metric"].iloc[0] == "bertscore_f1"
    assert "bertscore_f1" in df.columns
    assert df["bertscore_f1"].notna().all()
    assert ((df["bertscore_f1"] >= -1.0) & (df["bertscore_f1"] <= 1.0)).all()
    # and the fallback column must NOT be present when the real metric ran
    assert "semantic_sim_tfidf" not in df.columns


def test_identical_text_scores_near_one_on_bertscore(tiny_backbone):
    """Sanity check on the metric itself, independent of the pipeline."""
    from ctieval.metrics import compute_bertscore

    text = "A remote attacker can exploit the vulnerability."
    same = compute_bertscore([text], [text], tiny_backbone, num_layers=2)[0]
    diff = compute_bertscore([text], ["Unrelated wording entirely."],
                             tiny_backbone, num_layers=2)[0]
    assert same > diff, "identical text must not score below unrelated text"
    assert same > 0.99, f"identical text should score ~1.0, got {same}"


def test_over_long_text_is_clipped_not_fatal(tiny_backbone):
    """One over-long summary must not abort the whole scoring stage.

    A tiny vocabulary falls back to character-level word pieces, so a long
    summary can blow past the backbone's position limit and raise inside torch.
    Before the guard, that killed every score in the run.
    """
    from ctieval.metrics import _backbone_max_words, _clip_to_context, compute_bertscore

    limit = _backbone_max_words(tiny_backbone)
    assert limit > 0
    long_text = " ".join(["vulnerability"] * (limit * 3))
    cands, refs, clipped = _clip_to_context([long_text, "short"], ["ref", "short"],
                                            tiny_backbone)
    assert clipped == 1
    assert len(cands[0].split()) == limit
    assert cands[1] == "short"

    with _pytest.warns(RuntimeWarning, match="truncated"):
        out = compute_bertscore([long_text], ["a reference summary"],
                                tiny_backbone, num_layers=2)
    assert len(out) == 1 and -1.0 <= out[0] <= 1.0


def test_proposal_conformance_checker_runs_and_flags_synthetic(tmp_path):
    """The conformance checker must fail loudly on a synthetic corpus.

    Its whole purpose is to make drift from the proposal visible, and the most
    consequential drift is reporting from validation data.
    """
    import subprocess as _sp
    import sys as _s
    import yaml as _yaml

    from ctieval.schema import write_jsonl

    root = _Path(__file__).resolve().parents[1]
    cfg = _yaml.safe_load((root / "config" / "config.yaml").read_text(encoding="utf-8"))
    cfg["paths"] = dict(cfg["paths"])
    cfg["paths"]["corpus"] = str(tmp_path / "corpus.jsonl")
    path = tmp_path / "cfg.yaml"
    path.write_text(_yaml.safe_dump(cfg), encoding="utf-8")

    # clean config, no corpus yet -> passes
    out = _sp.run([_s.executable, "scripts/check_proposal_conformance.py",
                   "--config", str(path)], cwd=str(root), capture_output=True,
                  text=True, timeout=180)
    assert out.returncode == 0, out.stdout + out.stderr
    assert "No conformance failures" in out.stdout

    # synthetic corpus -> must fail
    write_jsonl(tmp_path / "corpus.jsonl", _offline.collect(n_cve=2, n_otx=2, n_apt=2, seed=9))
    out = _sp.run([_s.executable, "scripts/check_proposal_conformance.py",
                   "--config", str(path)], cwd=str(root), capture_output=True,
                  text=True, timeout=180)
    assert out.returncode == 1
    assert "synthetic" in out.stdout


def test_credential_scan_ignores_virtual_environments(tmp_path):
    """The scan must identify a venv by its pyvenv.cfg, not by its name.

    A venv called anything other than .venv or venv was previously walked in
    full, and the scan flagged credential-shaped strings inside installed
    third-party packages — a false positive that fails the build for no reason.
    """
    from tests.test_pipeline import _virtualenv_roots  # noqa: PLC0415

    for name in (".venv", "venv", ".v", "env311", "some-other-name"):
        (tmp_path / name).mkdir()
        (tmp_path / name / "pyvenv.cfg").write_text("home = /usr\n", encoding="utf-8")
    found = _virtualenv_roots(tmp_path)
    assert len(found) == 5, f"missed a venv: {sorted(p.name for p in found)}"
    assert {p.name for p in found} == {".venv", "venv", ".v", "env311", "some-other-name"}
