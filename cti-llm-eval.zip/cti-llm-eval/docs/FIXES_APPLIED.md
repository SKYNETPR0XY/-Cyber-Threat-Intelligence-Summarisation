# Fixes applied — 1 September 2026

Every defect found by running the pipeline has been fixed in `src/ctieval/`,
pinned by a regression test, and verified by re-running the whole program.

| Check | Before | After |
|---|---|---|
| Test suite | 32 passing | **63 passing** |
| Statistical verification | 88 / 88 | **100 / 100** |
| CLI command surface | 5 of 18 paths errored or misbehaved | **18 / 18 exit correctly** |
| Modules changed | — | 9 |

`python -m pytest -q` → 63 passed.
`python scripts/verify_statistics.py results/dryrun` → 100/100.
Every command below returns the exit code it should, including the failure paths.

---

## 1. Data-loss hazard: `python -m ctieval demo`

**Was:** the command in the CLI docstring loaded the *real* config, overwrote
`data/corpus.jsonl` and `data/provenance_registry.csv` with synthetic items,
then hammered the live Anthropic API and LM Studio for ~9 minutes writing 90
error records into `results/generations.jsonl`.

**Now:** `cmd_demo` detects a config that is not mock-only, says so, and loads
`config/config.demo.yaml` instead. It then refuses to overwrite any corpus
holding non-synthetic items unless `--force` is passed. It can no longer touch
collected data or spend API budget.

```
$ python -m ctieval demo
Switching to the dry-run configuration: config/config.demo.yaml
(the demo never runs against real backends or the real corpus)
```

Tests: `test_demo_refuses_to_overwrite_a_real_corpus`,
`test_demo_switches_away_from_a_config_with_real_backends`,
`test_demo_overwrites_a_synthetic_corpus_without_complaint`.

## 2. `validate_detector()` measured the wrong thing (B3)

**Was:** compared *sets of span strings* pooled across the corpus, so one span
appearing in twenty summaries collapsed to a single entry.

**Now:** matches on `(item_id, model_id, span)` triples.
`MockProvider` records `source_key` and `model_id` on every injected error,
`run_experiment` persists them to `<generations>.injected.jsonl`, and `detect`
reads them back. Without the mapping the function still runs but names itself
`"span sets (degraded…)"` rather than reporting a figure that looks sound.

The same dry run, both ways:

| Method | Precision | Recall | F1 | Seeded |
|---|---|---|---|---|
| span sets (old) | 0.714 | 1.000 | 0.833 | 10 |
| per finding (now) | **0.203** | 1.000 | 0.338 | 48 |

The recall claim in §5.5 holds. The precision claim does not — report the real
number and frame the checker as the high-recall instrument it is.

Tests: `test_detector_validation_matches_per_item_not_per_span`,
`test_detector_validation_counts_false_positives`,
`test_mock_provider_records_the_pair_it_injected_into`.

## 3. Adjudication now exists (B2)

New command, following the same export/review/import idiom as `annotate`:

```bash
python -m ctieval adjudicate --export results/adjudication.csv
#   set 'confirmed' to TRUE/FALSE per row; correct category/subtype if needed
python -m ctieval adjudicate --import results/adjudication.csv
```

It writes `confirmed` onto each finding and prints detector precision on the
reviewed set. Table 6.4 then leads with the **human-confirmed** rate and carries
the detector's flagged rate and precision beside it. Until findings are
adjudicated the table names itself *detector-flagged* and says in the pack that
each figure is an upper bound including false positives.

Test: `test_adjudicate_round_trip_changes_the_reported_rate`.

## 4. BERTScore can no longer degrade silently (B1)

`score_all` raises `BERTScoreUnavailable` instead of quietly writing the TF-IDF
proxy; `score` exits 3 with the reason. The proxy requires
`--allow-semantic-fallback`, and the dry run is the only place that passes it.

> **This one still needs you.** The code now enforces it, but the environment
> cannot yet satisfy it: `bert-score` is not installed and `huggingface.co` is
> unreachable from this machine's sandbox. Run `pip install bert-score` with hub
> access and confirm `metrics.csv` carries a `bertscore_f1` column before scoring
> for real. Still disclose in §5.4.1 that the backbone is
> `distilbert-base-uncased` (not the `roberta-large` default) and that
> `rescale_with_baseline=False`.

Tests: `test_score_all_refuses_to_substitute_the_proxy_by_default`,
`test_score_all_fallback_is_explicit_and_labelled`,
`test_score_exits_cleanly_without_bertscore`.

## 5. APT sections no longer share one reference (N2)

**Was:** every section of a report was handed the report's executive summary as
its reference and marked `needs_reference_summary: False`, so `annotate` never
prompted. Three sections about different subject matter were scored against one
identical 105-word summary.

**Now:** the executive summary is not used as a section reference by default.
Sections without a `<report>.refs.json` entry are emitted with
`needs_reference_summary: True` so the annotation stage picks them up.
`--share-executive-summary` restores the old behaviour and stamps
`reference_shared: True` on those items so the choice is visible in the corpus.

Test: `test_apt_sections_do_not_share_the_executive_summary_by_default`.

## 6. Collectors survive the network (N3)

New `collectors/_http.py`: `get_json()` retries 403/408/429/5xx and connection
errors with exponential backoff, then raises `CollectorError` with a message a
user can act on. `cmd_collect` catches it and returns exit code 2 instead of a
traceback. A blip 25 CVEs into collection no longer aborts the run with a stack
trace, and a missing `OTX_API_KEY` prints one line.

```
$ python -m ctieval collect --source otx
Collection failed: OTX_API_KEY is not set. Register free at otx.alienvault.com …
```

Tests: `test_collector_http_retries_then_raises_a_clean_error`,
`test_collector_http_recovers_after_a_transient_failure`,
`test_collect_reports_a_missing_key_without_a_traceback`.

## 7. The LLM judge can now parse a real reply (N6)

**Was:** `re.search(r"\{.*\}", text, re.S)` is greedy — it spans from the first
brace to the last, so any prose after the JSON, or a second object, failed to
parse and the judge silently returned zero findings. Zero test coverage.

**Now:** `_extract_json` walks the string for the first brace-balanced object,
ignores braces inside string literals, and strips a markdown fence. Four tests
cover it, including a stub provider returning a realistic reply.

Tests: `test_judge_json_extraction_handles_prose_and_fences`,
`test_judge_parses_a_realistic_reply`, `test_judge_survives_a_non_json_reply`.

## 8. SelfCheck output reaches the report (D6)

`selfcheck_scores.csv` was written and never read again. `cmd_report` now joins
it to the model labels and `build_results_pack` emits **Table 6.5b** and
`table_selfcheck.csv`. Enabled SelfCheck now shows up in Chapter 6.

Test: `test_selfcheck_scores_reach_the_results_pack`.

## 9. Figures and tables

- **F1** — `"bertscore_f1".replace("_f", "")` rendered the axis tick as
  **BERTSCORE1**. Replaced with an explicit `METRIC_LABELS` map: ROUGE-1,
  ROUGE-2, ROUGE-L, BERTScore F1, and "TF-IDF proxy (not BERTScore)".
- **F2** — the stacked bar counted a summary in both the intrinsic and extrinsic
  segment, so the total exceeded Table 6.4's rate. Now three mutually exclusive
  segments — intrinsic only / extrinsic only / both — which sum exactly to the
  table. Verified for all three models in `verify_statistics.py`.
- **F3** — the count column is renamed `Findings` (atom-level) and the heatmap
  title says so, because one fabricated sentence yields several findings.
- **F4** — `sharey=True` on the cost/latency figure: labels written once, values
  annotated on the bars.
- **F5** — Wilson 95% intervals on every rate in Table 6.4, and a new
  **Table 6.1b** of bootstrap 95% intervals for every model × metric mean.
- **F6** — `savefig.dpi` 200 → **300**.
- Model names are truncated to 22 characters instead of `split()[0]`, which
  rendered "Claude Sonnet 4.6" and "Claude Sonnet 4.7" identically as "Claude".

Tests: `test_metric_labels_do_not_mangle_bertscore`,
`test_hallucination_categories_are_mutually_exclusive_in_the_figure`,
`test_rates_table_reports_wilson_intervals_and_names_them_flagged`,
`test_rates_table_reports_confirmed_rate_after_adjudication`,
`test_wilson_interval_brackets_the_point_estimate`,
`test_bootstrap_interval_brackets_the_mean`.

## 10. Smaller fixes

- **B4** — `collect --source offline` now honours `--n-cve/--n-otx/--n-apt`
  (was hard-wired to 12/9/9). `--n-apt` added.
- **B5** — `detect` persists `detector_validation.csv`; `report` reads it, so
  the Table 6.5 slot Chapter 6 reserves is actually filled.
- **B6** — `humaneval build --n` now counts corpus **items** per source type.
  `--n 4` gives 12 items × 3 models = 36 rows, and the command prints those
  numbers so the methodology can state the real sample.
- **N4** — `annotate --export` always writes a header row; the zero-byte file no
  longer crashes `--import` with `EmptyDataError`, and an empty import reports
  itself instead of tracing back.
- `run_experiment` truncates the generations file rather than `unlink()`, which
  fails on mounts that disallow deletion.
- `README.md` updated: the adjudication step, the corrected `humaneval --n`
  semantics, the BERTScore requirement, and `python -m ctieval demo` as a safe
  one-liner.

## 11. New tooling

- `scripts/verify_statistics.py` — recomputes every reported statistic from raw
  `metrics.csv` with scipy and scikit-learn and checks it against what the
  pipeline wrote, including figure-vs-table consistency and Wilson intervals.
  100 checks. Run it after touching `metrics.py`, `report.py` or `humaneval.py`.
- `scripts/dryrun_fullscale.py` — 90-item, 3-model dry run for rehearsing
  Chapter 6 at the real scale.

---

## Still open — these need you, not the code

1. **Install `bert-score` and confirm hub access** (§4 above). Nothing in
   Chapter 6 is final until the semantic column is real.
2. **Decide RQ2's scope.** RQ2 asks "which mitigations reduce it"; there is one
   prompt template and no strategy dimension. Implement a second prompt
   condition, or narrow RQ2 and O4 and move mitigation into Chapter 8. A
   supervisor conversation.
3. **Dissertation text**: the corpus size is never stated (§5.2); the test count
   is now **63**, not "thirty-one"; the reference list holds 18 sources against
   O1's promise of twenty; the NVD 2023 statistic is uncited; method citations
   (Friedman, Wilcoxon, Holm, rank-biserial, ICC, Wilson, Landis & Koch) are
   missing; front matter still says "Right-click and Update Field"; §5.5 asserts
   a result that belongs in Chapter 6; the CVE reference design (§5.2.1) needs
   owning as a validity threat.
4. **Delete or rewrite `claude/D3-evaluation-pipeline-guide.md`** in the Claude
   project — it describes a different CLI, different outputs, 12 tests,
   quadratic-weighted kappa and Bonferroni. It contradicts both the code and the
   dissertation.
