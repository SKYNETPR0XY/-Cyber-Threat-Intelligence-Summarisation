# ctieval — dry run, verification and review

**Subject:** *Evaluating Large Language Models for Automated Cyber Threat Intelligence Summarisation* (W18850154)
**Repo:** `cti-llm-eval` · **Date:** 31 August 2026
**Scope:** ran the pipeline end to end offline, verified every statistic it produces against independent recomputation, and reviewed the dissertation against the artefact.

---

## 0. What was run, and what these numbers are

| Step | Result |
|---|---|
| `pytest -q` | **32 passed**, 0 failed |
| `python -m ctieval --config config/config.demo.yaml demo` | completed — 30 items × 3 mock models, full pipeline |
| `scripts/dryrun_fullscale.py` (added) | completed — **90 items × 3 stand-ins = 270 generations**, all six stages plus human eval |
| Independent statistical verification | **88 / 88 checks agree** with the pipeline's own output |

**Every number produced is synthetic and unsubmittable.** The corpus came from
`ctieval.collectors.offline`; the summaries came from stand-in providers that do
no inference. `build_results_pack` refused to emit anything until
`allow_synthetic=True` was passed, and stamped `DRY RUN — SYNTHETIC DATA — NOT
AN EXPERIMENTAL RESULT` across every figure. **The integrity guard described in
§5.3.4 works exactly as the dissertation claims it does.**

The dry run exists to rehearse Chapter 6 at the real scale — tables, figures,
statistics and interpretive prose — so the argument is settled before API budget
is spent. `python -m ctieval demo` alone cannot do that: its three mock providers
emit near-identical extractive text, so the Friedman/Wilcoxon layer is degenerate
(all three pairwise contrasts non-significant, identical medians) and the figures
show nothing. The added driver uses your pipeline for everything — prompting,
metrics, statistics, detection, reporting — and simulates only the two things a
dry run must simulate: the models and the raters.

New files, all clearly marked dry-run-only:
`scripts/dryrun_fullscale.py`, `results/dryrun/**`, `docs/CHAPTER6_DRYRUN_DRAFT.md`, this document.
Nothing under `src/ctieval/` was modified.

---

## 1. Verification — what the checks confirm

I recomputed every reported statistic from the raw `metrics.csv` using scipy and,
where possible, a second independent implementation. All 88 agreed:

- **Friedman** χ² and p for all three metrics, and **Kendall's W** (also range-checked into [0, 1]).
- **All nine pairwise Wilcoxon** signed-rank W statistics and raw p-values.
- **Holm–Bonferroni** step-down adjusted p-values, recomputed from scratch, plus the monotonicity property (every adjusted p ≥ its raw p). `holm_bonferroni()` is correct — a genuine step-down, not a Bonferroni relabelled.
- **Matched-pairs rank-biserial** r for all nine contrasts, range-checked into [−1, 1].
- **Linearly-weighted Cohen's κ** for all five dimensions, against `sklearn.metrics.cohen_kappa_score(weights="linear")` — exact agreement to four decimals.
- **ICC(2,k)** against a hand-rolled two-way ANOVA — exact agreement.
- Table 6.1 descriptives against the raw per-row data; Table 6.4 counts against `hallucinations.jsonl`; all four figure files present and non-trivial.

Two design details also check out and are worth a sentence in §5.5:
`paired_matrix()` drops any item missing for any model, so the Wilcoxon tests are
genuinely paired; and `score_pair` calls `RougeScorer.score(target=reference,
prediction=candidate)` in the correct argument order, which is a surprisingly
common way to get ROUGE silently wrong.

**The statistical machinery is sound. The issues below are elsewhere.**

---

## 2. Blocking — fix before the live run

### B1. BERTScore has never executed

`bert-score` is not installed, and `huggingface.co` is unreachable from this
machine's sandbox, so every run silently fell back to `semantic_sim_tfidf`. The
fallback behaves exactly as designed — it warns loudly, names the column
differently and refuses to call itself BERTScore — but it means **the BERTScore
code path in this project has never once run**, while §5.5 and all of Chapter 6
promise BERTScore F1.

Before scoring for real: `pip install bert-score`, confirm network access to
huggingface.co, then check that `metrics.csv` contains a `bertscore_f1` column
and that `semantic_metric == "bertscore_f1"`. If it says `semantic_sim_tfidf`,
the run is not reportable.

Two things to disclose in §5.4.1 once it works: the backbone is
`distilbert-base-uncased`, which is **not** the BERTScore default for English
(`roberta-large`) and correlates less well with human judgement — justify the
choice on compute grounds; and `rescale_with_baseline=False`, which means raw
scores in the 0.8–0.9 range that are not comparable to rescaled figures in other
papers. Say both, or a reader will misread the numbers.

### B2. There is no adjudication stage

§5.3.3 and the module docstring correctly describe detector output as
*candidates*. But there is no CLI command that lets you confirm or reject a
finding — `ctieval annotate` handles reference summaries only. So Chapter 6's
Table 6.4 would report **raw detector output** as "the hallucination rate per
model", which is not what §5.5 says it measures.

Two ways out. Either add an adjudication command and report the human-confirmed
rate as the headline with the raw detector rate beside it as detector
performance — that comparison is a genuine contribution and it is what makes the
instrument defensible. Or, if time is short, rename the table and every
reference to it: **detector-flagged rate**, reported together with the detector's
precision, with the gap discussed openly. What you cannot do is call an
unadjudicated detector count a hallucination rate.

### B3. `validate_detector()` computes the wrong quantity

`hallucination.validate_detector()` compares **sets of span strings** across the
entire corpus:

```python
detected = {(f.span or "").lower() for f in findings}
truth    = {(inj.get("span") or "").lower() for inj in injected if inj.get("span")}
```

The same span appearing in twenty different summaries collapses into one set
entry, so precision and recall are computed over *distinct strings*, not over
findings. In the dry run:

| Method | Precision | Recall | F1 | n seeded | n flagged |
|---|---|---|---|---|---|
| as shipped (span sets) | **0.765** | 1.000 | 0.867 | 13 | 17 |
| corrected — (item_id, model_id, span) | **0.160** | 1.000 | 0.275 | 56 | 351 |

A five-fold difference in precision. `MockProvider.injected` also records no
`item_id`, so the correct match is impossible without a change to the provider.

This matters because §5.5 states, as a validity claim, that "the checker achieved
perfect recall with conservative precision". The **recall claim is supported** —
1.00 on both methods, every seeded error caught. The **precision claim is not**;
the shipped function overstates it, and the corrected 0.16 (itself a lower bound,
since unlabelled-but-genuinely-ungrounded text counts against it) says the
checker over-flags substantially. Fix the function, re-run, and report whatever
it actually gives — a high-recall, low-precision detector is a perfectly
defensible design for a safety instrument, provided you say so.

```python
# providers/mock.py — carry the pair identity on each injected record
def _call(self, system, user, temperature, max_tokens):
    ...
    if rng.random() < self.error_rate:
        summary, record = self._inject(summary, source, rng)
        if record:
            record = dict(record)
            record["source_key"] = source[:200]   # map back to item_id
            record["model_id"] = self.model_id
            self.injected.append(record)

# hallucination.py — score per finding, not per distinct string
def validate_detector(findings, injected, item_id_by_source_key):
    truth = {(item_id_by_source_key.get(r["source_key"], "?"), r["model_id"],
              (r.get("span") or "").lower())
             for r in injected if r.get("span")}
    got = {(f.item_id, f.model_id, (f.span or "").lower()) for f in findings}
    tp, fp, fn = len(got & truth), len(got - truth), len(truth - got)
    ...
```

### B4. The offline collector ignores its size arguments

`cmd_collect` calls `offline.collect(seed=cfg.seed)` and drops `--n-cve`,
`--n-otx` and the APT count, so an offline corpus is **always** 12/9/9 = 30
items. The dry run therefore cannot rehearse at the real n = 90 through the CLI
at all — which is why the added driver calls `offline.collect()` directly.

```python
# cli.py, cmd_collect
items += offline.collect(seed=cfg.seed,
                         n_cve=args.n_cve, n_otx=args.n_otx, n_apt=args.n_otx)
```

### B5. `ctieval report` never emits Table 6.5

`build_results_pack` accepts a `detector_validation` argument and renders
"Table 6.5 — Grounding detector validation against seeded errors" from it — but
`cmd_report` never passes one, so the slot Chapter 6 reserves for Table 6.5 is
never filled by the shipped command. Compute the validation in `cmd_detect`,
persist it beside `hallucinations.jsonl`, and read it back in `cmd_report`.

### B6. `humaneval build --n 10` does not produce 10 per source type

```python
take = max(1, n_per_source_type // max(1, len(models)))   # 10 // 3 == 3
```

With three models this samples **3 items** per source type and emits **9 rows**
per source type — 27 rows over 9 distinct items in total, not 30. The sampling
logic itself is right (sample items, then take all models' output for those
items, so the paired structure survives) — only the arithmetic on the parameter
is off. Either rename the parameter to `n_items_per_source_type` and pass 10, or
divide differently. Whichever you choose, §5.5 must state the human-evaluation
sample that was actually rated, because 27 rows over 9 items is a materially
weaker check than 30 independent items and an examiner will do the arithmetic.

---

## 3. Figures and tables

**F1 — Figure 6.1 axis labels are wrong.** `m.replace("_f", "").upper()` strips
the `_f` from the *middle* of `bertscore_f1`, so the tick reads **"BERTSCORE1"**.
`rougeL_f` renders as "ROUGEL" rather than "ROUGE-L". Both appear in the
submitted figure.

```python
PRETTY = {"rouge1_f": "ROUGE-1", "rouge2_f": "ROUGE-2", "rougeL_f": "ROUGE-L",
          "bertscore_f1": "BERTScore F1", "semantic_sim_tfidf": "TF-IDF proxy"}
ax.set_xticklabels([PRETTY.get(m, m) for m in metrics])
```

**F2 — Figure 6.3's left panel double-counts.** Intrinsic % and extrinsic % are
each computed as `nunique(item_id) / n`, then stacked. A summary containing both
an intrinsic and an extrinsic error is counted in both bars, so the stacked total
exceeds Table 6.4's rate. In the dry run one model shows 31.1% on the figure
against 30.0% in the table — small here because the stand-in injects one error
per summary; on real output, where a summary routinely carries both kinds, the
divergence will be much larger, and a figure that contradicts its own table is
the kind of thing a viva finds. Either plot mutually exclusive categories
(intrinsic-only / extrinsic-only / both) or plot side-by-side bars and drop the
implied total.

**F3 — "Errors" is atom-level, not hallucination-level.** One injected fabricated
sentence produced four findings: `Lazarus Group`, `GitHub`, `actively exploited`,
`proof-of-concept`. So "Errors/summary" of 2.42 does not mean 2.42 hallucinations.
Define the unit in the caption, or collapse findings to distinct claims first.

**F4 — `fig_cost_latency` repeats the model labels on both panels**, spending
half the canvas on duplicated text. `sharey=True` and label once.

**F5 — no confidence intervals anywhere.** At n = 90 this is a real weakness and
it is cheap to fix. Wilson intervals for the flagged rates, computed from the dry
run: A 16.7% [10.4, 25.7]; B 30.0% [21.5, 40.1]; C 67.8% [57.6, 76.5]. Add
bootstrap CIs for the metric means too — a mean ROUGE over 30 items without an
interval is hard to defend, and the intervals will do more for the credibility of
Chapter 6 than another table would.

**F6 — 200 dpi.** `savefig.dpi` is 200; the docstring promises publication
quality and most thesis guidance asks for 300. One line.

---

## 4. Dissertation text against the artefact

**D1 — Test count.** §5.4 and Appendix B say "thirty-one-test suite"; the suite
has **32**. Trivial, but it is exactly the kind of checkable claim a marker
checks.

**D2 — The project guide in your Claude project is stale and contradicts everything.**
`claude/D3-evaluation-pipeline-guide.md` documents a different CLI
(`ctieval collect/run/score/detect/annotate/human-eval/report`), different
outputs (`reports/results_by_model.csv`, `significance_tests.csv`,
`bootstrap_cis.json`, `report.html`), a different module layout, **12** tests,
**quadratic**-weighted kappa, Bonferroni rather than Holm, and prompt-strategy
flags (`--strategies baseline cot grounded`) that do not exist in this code. The
dissertation matches the *code*, not that guide. Delete or rewrite it before it
ends up cited in Appendix B — two contradictory descriptions of the same
artefact is a gift to an examiner.

**D3 — Kappa weighting.** §5.5 says linearly-weighted; `humaneval.py` implements
linear; verified against sklearn. Correct — keep it, and cite a source for the
≥ 0.6 threshold. Landis & Koch (1977) is the usual one and is **not** in your
reference list.

**D4 — The corpus size is never stated.** §5.2.1 gives thirty CVE records; the
OTX and APT counts appear nowhere in the dissertation, and Chapter 8 falls back
to "a thirty-day OTX window and a selection of report sections". State
"90 items — 30 CVE, 30 OTX, 30 APT sections" in §5.2 and again in §6.1.1. A
reader cannot judge the statistics without n.

**D5 — RQ2 promises mitigations the methodology does not test.** RQ2 as stated in
§4.2 asks "what is the extent, nature and taxonomic classification of
hallucination ... **and which mitigations reduce it**", and O4 is mapped to it.
But §5.4 applies "one unified prompt template to every model", there is a single
`prompt_id` in the config, and there is no strategy dimension anywhere in the
code. Chapter 8 concedes the point ("tests mitigations only lightly"), which is
honest but does not close the gap between the research question and the work.

**This is the largest scope risk in the submission.** Either implement a second
prompt condition — a grounded or chain-of-thought variant over the same corpus,
scored by the same detectors, which the provider abstraction makes cheap — or
rewrite RQ2 and O4 so they claim only measurement and classification, and move
mitigation wholly into Chapter 8. Do one of these deliberately; do not leave the
mismatch in the text.

**D6 — Say which detectors actually ran.** §5.3.3 presents three complementary
detectors as the design. But `selfcheck_samples: 0` in `config.yaml` means
SelfCheck never runs unless changed, and the LLM judge is opt-in
(`detect --judge`) at one extra API call per summary. If Chapter 6's numbers come
from the grounding checker alone, say so plainly and explain why — the three-detector
design is still a valid contribution even if one instrument was budget-limited
out of the final run. What is not defensible is describing three and reporting
one without comment.

**D7 — A result is asserted in the methodology chapter.** §5.5 ends with "the
checker achieved perfect recall with conservative precision" — a finding, stated
without numbers, before Table 6.5 reports it. Move it to §6.1.5 with the actual
precision/recall/F1, and see B3 for why the precision half needs recomputing
first.

**D8 — The reproducibility claim is slightly too strong.** §2.1.3 and Appendix C
say temperature 0.0 makes each model's output reproducible. Greedy decoding is
deterministic *for a fixed backend at a fixed version*; it is not guaranteed
bit-identical across an API model revision or GPU batching changes. Soften to
"deterministic decoding, subject to provider version stability, which the corpus
records per summary" — which is true, and is a better sentence because it shows
you know why you log the model version.

**D9 — Pin the model identifiers.** §1.2 says "LLaMA 3 8B and Mistral 7B ... in
4-bit GGUF"; the config says `meta-llama-3-8b-instruct` and
`mistral-7b-instruct-v0.3`. Put the exact repository, the quantisation variant
(Q4_K_M) and the LM Studio build in §5.4.1. Confirm the `claude-sonnet-4-6`
string against the provider's current model list before the final run — an
unrecognised id fails at generation time, after you have queued 90 items. Run
`python -m ctieval preflight` first; that is what it is for.

**D10 — The CVE task design is a validity threat and needs owning.** §5.2.1
withholds the NVD description from the model and uses it as the reference. But
the remaining structured record — CVSS, CWE, CPE configurations, reference URLs —
does not contain most of the description's content. The model is therefore asked
to generate text it largely cannot derive, and ROUGE against a one- or
two-sentence description will penalise a good longer summary regardless. Two
further points: NVD/CVE descriptions are typically authored by the CNA rather
than independently by an analyst, so calling them an "expert reference summary"
overstates them; and they are short, which caps achievable overlap. Address this
in §5.2.1 and again in the limitations — it is a good discussion, not a fatal
flaw, but it must be your observation rather than the examiner's.

**D11 — Uncited statistic.** "The NVD published more than 29,000 CVEs in 2023"
appears in both the abstract and §1.1 with no citation. Cite NVD or the CVE
Program directly.

**D12 — Reference count and missing method citations.** The list holds **18**
sources; O1 commits to "at least twenty peer-reviewed sources". Add at least two,
and add the methods you rely on but do not cite: Friedman, Wilcoxon, Holm (1979),
rank-biserial (Kerby, 2014), ICC (Shrout & Fleiss, 1979), Wilson (1927),
Landis & Koch (1977). Method citations are cheap marks and their absence is
conspicuous in a chapter that leans this hard on non-parametric statistics.

**D13 — Front matter.** Table of Contents, List of Figures and List of Tables all
still read "Right-click and Update Field". Table 4.2's caption sits on p.21 while
the table is on p.20. Figure 5.1 is currently the only figure in the document.

**D14 — Placeholder inventory.** Before submission remove: the abstract's
`[RESULTS PLACEHOLDER]` paragraph; the Chapter 6 "Note to author" block; the
`[INSERT ...]` boxes for Tables 6.1–6.6 and Figures 6.1–6.4; the seven
`[Interpret: ...]` prompts; the §6.2 discussion prompt; and the conclusion's
`[Add one or two sentences ...]`. `docs/CHAPTER6_DRYRUN_DRAFT.md` drafts prose
for every one of them against the dry-run numbers, so the writing is done and
only the figures need swapping.

**D15 — Stage count.** §5.3.2 says six stages, matching Figure 5.1 and the code.
The stale guide says seven. Six is right.

---

## 5. What is working well

Worth knowing, and worth saying in the viva:

- **The integrity guard is real and it fires.** `build_results_pack` refused a
  synthetic corpus until explicitly overridden, watermarked every figure, and
  banner-marked the results pack. Very few student projects build a mechanism
  whose purpose is to make it structurally hard to overstate their own results,
  and it is the strongest single argument for the framework as a contribution.
- **The statistics are correct** — all 88 independent checks agree, including the
  Holm step-down, the rank-biserial effect sizes, the linearly-weighted kappa and
  ICC(2,k). Nothing here needs defending.
- **Blinding is properly done**: salted SHA-256 eval ids, the key written to a
  separate file, and item-level sampling so every model's output for a chosen
  item is rated, which keeps the paired structure intact.
- **The CVSS-vector masking fix** described in §5.4 is a genuinely good story —
  a specific defect, a specific consequence (a spurious contradiction on
  essentially every CVE summary), a specific fix, and a regression test. Keep it
  prominent; it earns the argument that instruments must be validated.
- **Resumability, the SHA-256 provenance registry and environment-only
  credentials** all work as described.
- The pipeline degrades honestly: when BERTScore was unavailable it warned, used
  a differently-named column, and refused to call the fallback BERTScore. That is
  the right instinct throughout the codebase.

---

## 6. Suggested order of work

1. **B1** — get BERTScore actually running; nothing in Chapter 6 is final until the semantic column is real.
2. **D5** — decide RQ2's scope: implement the mitigation arm, or narrow the question. This is a supervisor conversation, not a code change.
3. **B2 / B3** — adjudication and the detector-validity fix; these determine what Table 6.4 and Table 6.5 are allowed to say.
4. **B4 / B5 / B6** and the figure fixes **F1–F6** — half a day in total.
5. Live run: `preflight` → `collect` → `annotate` → `run --limit 3` smoke test → full `run` → `score` → `detect` → `humaneval` → `report`.
6. Swap the dry-run tables and figures in `docs/CHAPTER6_DRYRUN_DRAFT.md` for the real ones and rewrite each interpretation against the real numbers.
7. **D1, D4, D11–D14** — the text and front-matter fixes; an hour, and every one of them is a checkable claim.
