# -*- coding: utf-8 -*-
"""Render real ctieval console output as terminal-style PNGs for the appendix.

Every image is produced by actually executing the command and capturing its
stdout/stderr — nothing is typed by hand. Long output is truncated at a marked
line rather than edited, so what the reader sees is what the program printed.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)

BG, FG = "#12161c", "#d6dde6"
GREEN, RED, BLUE, YELLOW, DIM = "#79c26a", "#e0736a", "#6fb2d2", "#d9b05f", "#7d8895"
ANSI = re.compile(r"\x1b\[[0-9;]*m")


def tidy(line: str) -> str:
    """Shorten the absolute working directory to a relative one.

    Purely cosmetic and applied uniformly: the session's temporary mount path is
    long enough to wrap every line. No other character of the output is altered.
    """
    return line.replace(str(ROOT) + "/", "").replace(str(ROOT), ".")


def colour_for(line: str) -> str:
    l = line.strip()
    if l.startswith("$"):
        return BLUE
    if "PASS" in l or "passed" in l or l.startswith("[OK") or "→" in l or "->" in l:
        return GREEN
    if "FAIL" in l or "Error" in l or "error" in l or "Refusing" in l or "WARNING" in l:
        return RED
    if l.startswith("#") or l.startswith("=") or l.startswith("---"):
        return DIM
    if l.startswith("Note") or "DRY RUN" in l or "CANDIDATES" in l:
        return YELLOW
    return FG


def render(lines: list[str], out: Path, title: str, max_lines: int = 46,
           width_chars: int = 108) -> Path:
    shown = []
    for raw in lines:
        raw = tidy(ANSI.sub("", raw.rstrip("\n")))
        while len(raw) > width_chars:
            shown.append(raw[:width_chars])
            raw = "    " + raw[width_chars:]
        shown.append(raw)
    truncated = len(shown) > max_lines
    if truncated:
        head = shown[: max_lines - 6]
        tail = shown[-5:]
        shown = head + [f"  … output truncated ({len(shown) - max_lines + 6} lines omitted) …"] + tail

    line_h = 0.185
    fig_h = 0.85 + line_h * len(shown)
    fig_w = 9.6
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    # title bar
    ax.add_patch(FancyBboxPatch((0.004, 1 - 0.42 / fig_h), 0.992, 0.36 / fig_h,
                                boxstyle="round,pad=0.002", linewidth=0,
                                facecolor="#1e2530", transform=ax.transAxes))
    for i, c in enumerate(("#e0736a", "#d9b05f", "#79c26a")):
        ax.plot(0.016 + i * 0.016, 1 - 0.21 / fig_h, "o", ms=5.2, color=c,
                transform=ax.transAxes)
    ax.text(0.075, 1 - 0.225 / fig_h, title, color="#9aa6b3", fontsize=8.5,
            family="DejaVu Sans Mono", va="center", transform=ax.transAxes)

    y = 1 - 0.60 / fig_h
    for line in shown:
        ax.text(0.012, y, line, color=colour_for(line), fontsize=7.6,
                family="DejaVu Sans Mono", va="top", transform=ax.transAxes)
        y -= line_h / fig_h
    fig.savefig(out, dpi=200, facecolor=BG, bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)
    print(f"  {out.name}  ({len(shown)} lines)")
    return out


def run(cmd: list[str], cwd: Path = ROOT) -> list[str]:
    env = dict(os.environ)
    env["COLUMNS"] = "110"
    p = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True,
                       timeout=900, env=env)
    pretty = " ".join("python" if c == sys.executable else c for c in cmd)
    return [f"$ {pretty}", ""] + (p.stdout + p.stderr).splitlines()


def strip_progress(lines: list[str]) -> list[str]:
    return [l for l in lines if not l.lstrip().startswith("[") or "PASS" in l or "FAIL" in l]


if __name__ == "__main__":
    py = sys.executable
    print("Rendering screenshots from live command output…")

    render(run([py, "-m", "pytest", "-q", "--tb=no", "-p", "no:warnings"]),
           OUT / "shot_tests.png", "ctieval — test suite", max_lines=14)

    verbose = run([py, "-m", "pytest", "-v", "--tb=no", "-p", "no:warnings",
                   "--no-header"])
    verbose = [re.sub(r"^tests/test_pipeline\.py::", "  ", l).replace(" PASSED", "  PASSED")
               for l in verbose]
    render(verbose, OUT / "shot_tests_verbose.png",
           "ctieval — 65 tests, named", max_lines=74, width_chars=96)

    render(run([py, "-m", "ctieval", "--help"]),
           OUT / "shot_help.png", "ctieval — command surface", max_lines=44)

    render(run([py, "-m", "ctieval", "preflight"]),
           OUT / "shot_preflight.png", "ctieval preflight — backend reachability", max_lines=16)

    render(strip_progress(run([py, "-m", "ctieval", "demo"])),
           OUT / "shot_demo.png", "ctieval demo — offline end-to-end dry run", max_lines=52)

    render(run([py, "scripts/verify_statistics.py", "results/dryrun"]),
           OUT / "shot_verify.png", "verify_statistics.py — independent recomputation", max_lines=44)

    render(run([py, "-m", "ctieval", "--config", "config/config.demo.yaml",
                "adjudicate", "--export", "results/demo/adjudication.csv"]),
           OUT / "shot_adjudicate.png", "ctieval adjudicate — detector review workflow", max_lines=14)

    print("done")
