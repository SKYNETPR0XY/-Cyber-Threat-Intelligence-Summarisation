# Running ctieval with LM Studio + VS Code

## A. LM Studio (serves the two open-source models)

1. **Search** tab → download, in Q4_K_M GGUF quant:
   - `Meta-Llama-3-8B-Instruct`
   - `Mistral-7B-Instruct` (v0.3)
2. **Developer** tab (`>_` icon) → load a model → set **Status: Running**.
   The server listens on `http://localhost:1234`. Keep LM Studio open.
3. Get the exact model IDs it is serving:
   ```bash
   curl http://localhost:1234/v1/models
   ```
   Copy each `id` string — you paste these into config.yaml.

> LM Studio serves ONE model at a time by default. Either run the two models in
> separate passes (see step D), or enable multi-model serving and load both.

## B. VS Code

1. **File → Open Folder →** the unzipped `cti-llm-eval`.
2. Integrated terminal (Ctrl+`), then:
   ```bash
   python -m venv .venv
   ```
   Accept the "select this environment?" prompt, or Ctrl+Shift+P →
   **Python: Select Interpreter** → the `.venv` one.
3. Activate + install:
   ```bash
   # Windows PowerShell:  .venv\Scripts\Activate.ps1
   # macOS/Linux:         source .venv/bin/activate
   pip install -e .
   pip install bert-score      # needed for real BERTScore; caches weights on first run
   ```

## C. Point the config at your models

Edit `config/config.yaml`, pasting the IDs from step A.3 into `model_id`:

```yaml
  - label: "LLaMA 3 8B"
    provider: lmstudio
    model_id: <exact id from LM Studio>
    base_url: http://localhost:1234/v1
  - label: "Mistral 7B"
    provider: lmstudio
    model_id: <exact id from LM Studio>
    base_url: http://localhost:1234/v1
```

Then confirm connectivity:

```bash
python -m ctieval preflight
```

Local models should show PASS. (Claude shows FAIL until ANTHROPIC_API_KEY is set —
fine while testing only the local models.)

## D. Smoke test against your live LM Studio server

Before real data or keys, confirm generation actually flows through LM Studio:

```bash
python -m ctieval collect --source offline
python -m ctieval run --models "LLaMA 3 8B" --limit 3 --allow-unreferenced
```

3 summaries marked `ok`, no errors → wiring is correct. Then clear it:

```bash
rm -f data/corpus.jsonl results/generations.jsonl
```

If LM Studio has both models loaded, drop `--models` to test both at once.

## E. Real run

Keys first (never in config.yaml):

```bash
cp .env.example .env        # edit, add ANTHROPIC_API_KEY, OTX_API_KEY, (NVD_API_KEY)
set -a; source .env; set +a  # PowerShell: use $env:ANTHROPIC_API_KEY="..." per key
```

Then the pipeline (run the two local models in separate passes if serving one at a time):

```bash
python -m ctieval collect --source all --pdf-dir data/apt_pdfs
python -m ctieval annotate --export
#   fill data/reference_summaries.csv, then:
python -m ctieval annotate --import data/reference_summaries.csv
python -m ctieval run --models "LLaMA 3 8B"
python -m ctieval run --models "Mistral 7B"
python -m ctieval run --models "Claude Sonnet 4.6"
python -m ctieval score
python -m ctieval detect --judge "Claude Sonnet 4.6"
python -m ctieval report
```

Open `results/report/results_pack.md` → paste into Chapter 6.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `preflight` local model FAIL | ID mismatch — paste the id from `curl .../v1/models` into config.yaml |
| run hangs / connection refused | LM Studio server not Running, or wrong port in base_url |
| every summary errors on one model | that model isn't loaded in LM Studio (one-at-a-time default) |
| BERTScore warning | install `bert-score` and run once online so weights cache |
| `ANTHROPIC_API_KEY is not set` | export it in the same terminal; re-run |
