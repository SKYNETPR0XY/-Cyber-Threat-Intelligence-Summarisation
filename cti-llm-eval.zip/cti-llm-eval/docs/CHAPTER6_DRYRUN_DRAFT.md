# Chapter 6 — dry-run rehearsal draft

> **DRY RUN — SYNTHETIC DATA. NOT AN EXPERIMENTAL RESULT.**
>
> Every number in this document came from `scripts/dryrun_fullscale.py`: a
> 90-item synthetic corpus (`ctieval.collectors.offline`) summarised by three
> stand-in providers that do no inference. The models named below are
> **Proxy-A / B / C**, not Claude Sonnet 4.6, LLaMA 3 8B and Mistral 7B.
>
> The purpose of this draft is to rehearse Chapter 6 at the real scale
> (n = 90 items × 3 models = 270 summaries) so that the tables, the figures and
> the interpretive prose can be checked *before* API budget is spent — and so
> that the shape of each argument is settled in advance. When the live run
> completes, re-run `python -m ctieval report`, replace every table and figure,
> and rewrite each interpretation against the real numbers. Nothing here may be
> submitted.

---

## 6.1 Presentation of Results

### 6.1.1 Overview of the experimental run

*Rehearsal text — replace the figures, keep the structure:*

The experiment produced 270 summaries: 90 corpus items — 30 NVD CVE records,
30 AlienVault OTX pulses and 30 sections drawn from APT and vendor threat
reports — summarised by each of the three models under one unified prompt at
temperature 0.0. No generation failed, so coverage is complete and every
(item, model) cell in the paired analysis is populated; the Friedman and
Wilcoxon tests below therefore run on the full n = 90 rather than on a
listwise-deleted subset.

> **Write in the live version:** total summaries, corpus items, coverage per
> source type, number of failed generations and how they were handled, the
> run_id and the git tag, total API spend, and total wall-clock inference time.
> These are printed at the top of `results/report/results_pack.md`.

### 6.1.2 Automated metrics by model

**Table 6.1 — Automated summarisation metrics by model (mean ± SD), dry run**

| Model | ROUGE-1 F | ROUGE-2 F | ROUGE-L F | Semantic* | Length ratio | Novel unigram rate |
|---|---|---|---|---|---|---|
| Proxy-A | 0.533 ± 0.074 | 0.354 ± 0.182 | 0.444 ± 0.133 | 0.545 ± 0.050 | 1.71 | 0.017 |
| Proxy-B | 0.492 ± 0.097 | 0.316 ± 0.189 | 0.401 ± 0.154 | 0.531 ± 0.134 | 1.57 | 0.098 |
| Proxy-C | 0.464 ± 0.080 | 0.280 ± 0.169 | 0.370 ± 0.136 | 0.510 ± 0.137 | 1.77 | 0.174 |

\* **Not BERTScore.** `bert-score` was not installed and huggingface.co was not
reachable, so the pipeline fell back to the clearly-labelled
`semantic_sim_tfidf` proxy, exactly as `metrics.score_all` is designed to. This
column must carry real BERTScore F1 before submission — see the review document,
issue B1.

*Figure 6.1 —* `results/dryrun/report/figures/fig_metrics_by_model.png`

**Interpretation (rehearsal).** Proxy-A leads on every lexical metric, and the
ordering A > B > C is identical on ROUGE-1, ROUGE-2 and ROUGE-L. The two metric
families agree at the corpus level but not everywhere within it (§6.1.3), which
is the interesting case: ROUGE rewards surface overlap with the reference, so a
model that paraphrases faithfully is punished, while an embedding metric is
comparatively indifferent to wording. The novel-unigram rate separates the
models more cleanly than ROUGE does — 1.7% for Proxy-A against 17.4% for
Proxy-C — and it is the cheapest leading indicator of extrinsic error in the
whole pipeline, because content absent from the source is by definition
unverifiable against it.

> **Write in the live version:** which model ranked highest on ROUGE-L and on
> BERTScore and by how much; whether the ordering was the same on both families;
> and, if not, what the disagreement implies about abstractiveness. Relate the
> absolute ROUGE-L value to the summarisation literature — a ROUGE-L F in the
> low 0.3s is normal for abstractive summarisation and does *not* mean the
> summary is wrong; say so, or a reader will over-read it.

### 6.1.3 Performance by CTI source type

**Table 6.2 — ROUGE-L F by model within each CTI source type, dry run**

| Source type | Proxy-A | Proxy-B | Proxy-C |
|---|---|---|---|
| CVE records | 0.616 | 0.615 | 0.558 |
| APT report sections | 0.420 | 0.314 | 0.276 |
| OTX pulses | 0.296 | 0.275 | 0.276 |

*Figure 6.2 —* `results/dryrun/report/figures/fig_rougeL_by_source.png`

**Interpretation (rehearsal).** Source type moves the scores more than model
identity does: the gap between the best and worst source type (0.32 ROUGE-L for
Proxy-A) is four times the gap between the best and worst model on the whole
corpus (0.07). Two things follow. First, any single headline ROUGE number for a
model is an average over three quite different tasks and should never be quoted
without the breakdown. Second, the between-model gap is not constant across
source types — on CVE records Proxy-A and Proxy-B are indistinguishable
(0.616 vs 0.615) while on APT narrative they are 0.11 apart — so the
open-source-versus-proprietary question (RQ3) has a different answer depending
on what the SOC is actually reading.

> **Caution for the live run.** In this dry run CVE scores highest because the
> stand-in provider is extractive and the CVE reference *is* a span of the
> source. In the real experiment the CVE description is withheld from the model
> (§5.2.1), so the model must produce text it largely cannot derive from the
> remaining structured record. Expect CVE to score *lowest*, and expect that to
> be a finding about the metric and the task design rather than about the
> models. This is discussed as issue D10 in the review document.

### 6.1.4 Statistical comparison between models

Friedman omnibus on ROUGE-L F: χ²(2) = 131.04, p = 3.5 × 10⁻²⁹, Kendall's
W = 0.728, n = 90 items.

**Table 6.3 — Pairwise Wilcoxon signed-rank tests, Holm-corrected, ROUGE-L F (dry run)**

| Contrast | Median A | Median B | W | p (raw) | p (Holm) | rank-biserial r | Significant |
|---|---|---|---|---|---|---|---|
| A vs B | 0.425 | 0.315 | 435 | 8.6 × 10⁻¹¹ | 8.6 × 10⁻¹¹ | 0.788 | yes |
| A vs C | 0.425 | 0.286 | 66 | 1.5 × 10⁻¹⁵ | 4.6 × 10⁻¹⁵ | 0.968 | yes |
| B vs C | 0.315 | 0.286 | 375 | 1.7 × 10⁻¹¹ | 3.4 × 10⁻¹¹ | 0.817 | yes |

On the semantic proxy the picture is different, and usefully so: A vs B does
**not** survive correction (p_Holm = 0.076, r = 0.216) while A vs C
(p_Holm = 0.0086, r = 0.347) and B vs C (p_Holm = 2.1 × 10⁻⁹, r = 0.748) do.

**Interpretation (rehearsal).** The omnibus is significant and Kendall's W of
0.73 says the three models are ranked consistently across items rather than
trading places — the ordering is a property of the models, not an average over
noise. All three lexical contrasts survive Holm correction with large effect
sizes. The semantic metric is the more conservative instrument here: it does not
separate the top two models, which is what you would expect if those two produce
summaries that differ in wording more than in meaning. That divergence is worth
more than either result alone, because it is direct evidence for the claim in
§3.2.3 that neither metric family is sufficient by itself in a technical domain.

> **Write in the live version:** state the omnibus result first, then which
> pairwise contrasts survived Holm and how large the effects were, and say
> explicitly whether a significant difference is also an operationally
> meaningful one. Report Holm correction *within* each metric family and say so —
> six tests across two families corrected as one set is a different, more
> conservative claim, and the reader must know which you did.

### 6.1.5 Hallucination

**Table 6.4 — Detector-flagged rate and taxonomy breakdown, dry run**

| Model | Summaries | Flagged | Rate % | 95% CI (Wilson) | Findings | Findings/summary | Intrinsic | Extrinsic |
|---|---|---|---|---|---|---|---|---|
| Proxy-A | 90 | 15 | 16.7 | [10.4, 25.7] | 48 | 0.53 | 4 | 44 |
| Proxy-B | 90 | 27 | 30.0 | [21.5, 40.1] | 85 | 0.94 | 7 | 78 |
| Proxy-C | 90 | 61 | 67.8 | [57.6, 76.5] | 218 | 2.42 | 7 | 211 |

Subtype counts (entity / relational / circumstantial / fabrication):
Proxy-A 1 / 2 / 1 / 44; Proxy-B 2 / 3 / 2 / 78; Proxy-C 2 / 1 / 4 / 211.

*Figure 6.3 —* `results/dryrun/report/figures/fig_hallucination.png`

**Table 6.5 — Grounding-detector validity against seeded errors, dry run**

| Method | Precision | Recall | F1 | n seeded | n flagged |
|---|---|---|---|---|---|
| `validate_detector()` as shipped (span sets) | 0.765 | 1.000 | 0.867 | 13 | 17 |
| Corrected — (item_id, model_id, span) triples | 0.160 | 1.000 | 0.275 | 56 | 351 |

**Interpretation (rehearsal).** Three things need saying, and the third is the
one an examiner will press on.

The rate ordering matches the quality ordering: the weakest model was flagged on
four times as many summaries as the strongest. Recall of the deterministic
checker is 1.00 against errors whose ground truth is known by construction —
every seeded contradiction and fabrication was caught, which is the behaviour a
safety-oriented instrument should have.

The dominant category is extrinsic rather than intrinsic, by roughly ten to one,
and within it almost every finding is `fabrication`. That is a specific and
operationally loaded failure mode: the models are not mostly getting the CVSS
score wrong, they are mostly adding claims — active exploitation, a public
proof-of-concept, an attributed actor — that the source never made. An analyst
who acts on a fabricated exploitation claim escalates a patch that did not need
escalating; an analyst who acts on a wrong CVSS digit mis-ranks one item. These
are different risks and the taxonomy split is what makes them separable.

**But the precision figures do not support quoting these rates as hallucination
rates.** The two rows of Table 6.5 disagree by a factor of five because
`validate_detector()` compares *sets of span strings across the whole corpus*, so
the same span appearing in twenty different summaries collapses to one entry.
The corrected row is the honest per-finding number, and even it is a lower bound
on precision, because the harness only labels the errors it deliberately seeded —
some of the 351 flags are genuine ungrounded content that simply was not on the
answer key. Either way, the checker over-flags. Until findings are adjudicated
by a human (there is currently no command that does this — issue B2), Table 6.4
reports a **detector-flagged rate**, not a hallucination rate, and must be
labelled as such.

> **Write in the live version:** which model hallucinated least and most; whether
> the dominant failure was intrinsic or extrinsic and which subtype dominated;
> and how the measured rate compares with the general-benchmark rates in Bang
> et al. (2023). Report the adjudicated rate as the headline and the raw detector
> rate beside it as detector performance — that comparison is a contribution in
> its own right, and it is what separates this from "a detector said so".

### 6.1.6 Human expert evaluation

**Table 6.6 — Blinded expert scores, 1–5, dry run (2 raters, 27 summaries, 9 items)**

| Model | Factual accuracy | Completeness | Conciseness | Relevance | Absence of hallucination | Composite |
|---|---|---|---|---|---|---|
| Proxy-A | 4.56 | 4.17 | 4.44 | 4.33 | 4.44 | 4.39 |
| Proxy-B | 3.50 | 3.00 | 2.56 | 3.17 | 3.22 | 3.09 |
| Proxy-C | 2.11 | 2.39 | 1.83 | 2.06 | 2.11 | 2.10 |

Inter-rater agreement, linearly-weighted Cohen's κ: factual accuracy 0.654,
absence of hallucination 0.570, conciseness 0.525, relevance 0.468,
completeness 0.241. ICC(2,k) on the composite = 0.931, n = 27 double-rated.

**Interpretation (rehearsal).** The human ranking reproduces the automated one,
which is the validity check the design was built to provide: two instruments
that share no machinery agree on the ordering. The agreement figures are more
interesting than the scores. Only factual accuracy clears the 0.6 threshold set
in §5.5; completeness at 0.24 is close to chance, and conciseness and relevance
sit in between. That pattern is reportable rather than embarrassing — it says
that the dimensions with an external referent (is this statement true of the
source?) can be scored reliably by two people, and the dimensions that encode a
judgement about audience (is this complete enough? is it the right length?)
cannot, at least not without an anchored rubric and a calibration round. The
high ICC(2,k) alongside low per-dimension kappas is the familiar pattern where
raters agree on the overall ordering while disagreeing about individual points
on the scale.

> **Note.** The rater scores in this dry run were *simulated* from each stand-in
> model's known quality plus rater noise, so the agreement figures rehearse the
> arithmetic, not a human finding. Note also that `humaneval build --n 10`
> produced 27 rows covering 9 distinct items, not 30 rows — see issue B6 —
> so §5.5 must state the human-evaluation sample that was actually rated.

### 6.1.7 Operational cost and latency

*Figure 6.4 —* `results/dryrun/report/figures/fig_cost_latency.png`

Dry-run medians: Proxy-A 3.07 s and USD 4.42 per 1 000 summaries;
Proxy-B 12.79 s and no marginal cost; Proxy-C 7.28 s and no marginal cost.

**Interpretation (rehearsal).** The trade-off is the one RQ4 anticipates and it
inverts cleanly: the API model is roughly three times faster per summary and
carries a real per-summary charge, while the locally served models are free at
the margin and pay for it in latency and quality. The break-even reasoning a SOC
would actually use is not cost-per-summary but cost-per-*correct*-summary: at a
flagged rate of 16.7% against 67.8%, the cheaper model produces four times as
many summaries an analyst must reject or repair, and analyst time is the
expensive input in a SOC. State that comparison explicitly, and state the
capital cost the local option hides — the workstation and the GPU memory that
make 4-bit inference possible at all.

> **Write in the live version:** real token counts and the provider's published
> price at the date of the run (state the date — prices change), median and 95th
> percentile latency, and the failure rate per backend. Convert to GBP against
> the £50 cap in the risk register, and say what the marginal cost of the full
> 270-generation run actually was.

---

## 6.2 Discussion / Analysis

Structure to write against, once the real numbers exist:

**RQ1 — accuracy.** How accurate were the models in absolute terms? Anchor the
ROUGE and BERTScore values against published summarisation baselines so the
reader knows whether 0.35 is good, then let the human scores carry the
operational verdict: is this good enough for supervised, human-in-the-loop use,
and is it clearly not good enough for unsupervised use? Say which.

**RQ2 — hallucination.** Compare the measured CTI rate with the general-benchmark
rates in Bang et al. (2023) and state whether domain-specific measurement was
necessary — that is the argument that justifies the whole project. Then be
explicit about what was *not* tested: the mitigation half of RQ2 (see issue D5).

**RQ3 — open vs proprietary.** Does the gap match or contradict the general-benchmark
near-parity reported by Touvron et al. (2023)? Quote p **and** effect size, and
break the answer down by source type, because the dry run already shows the gap
is not constant across them.

**RQ4 — operational barriers.** Draw the cost, latency and hallucination findings
together into a concrete integration picture for a MISP/OpenCTI workflow: where
in the pipeline the summariser sits, what the analyst sees, and what the review
burden is at the measured flag rate.

**Limitations of the results themselves.** Sample size (n = 90, 30 per source
type), single deterministic run per model with no variance estimate, a
two-rater human check with sub-threshold agreement on three of five dimensions,
researcher-authored ground truth for OTX and APT, and 4-bit quantisation of the
open models. Name these before the examiner does.
