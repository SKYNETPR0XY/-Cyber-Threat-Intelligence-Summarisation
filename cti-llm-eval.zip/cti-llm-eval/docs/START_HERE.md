# ctieval — how to run it, start to finish

Windows PowerShell. Every command is run from the project folder.

```powershell
cd "J:\Cyber Sec\2\MSc Cyber Security and Forensics Projects\TEST 3\cti-llm-eval"
```

There are two ways through this. **Part A** proves the program works in about
five minutes with no keys, no models and no internet. **Part B** is the real
experiment. Do Part A first — if anything is wrong with your setup you will find
out before spending a penny.

---

# Part A — Prove it works (5 minutes, nothing needed)

### A1. Create the environment

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e .
pip install pytest
```

If PowerShell blocks the activate script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### A2. Run the test suite

```powershell
python -m pytest -q
```

Expect **71 passed**. This needs no network, no API key and no GPU.

### A3. Run the whole pipeline offline

```powershell
python -m ctieval demo
```

You will see it switch itself to the dry-run configuration, build a synthetic
corpus, generate 90 summaries, score them, detect hallucination candidates, and
write a watermarked results pack to `results\demo\report\`. Open
`results\demo\report\results_pack.md` and look at
`results\demo\report\figures\`.

Everything it produces is watermarked **DRY RUN — SYNTHETIC DATA**. That is the
point: it proves the machinery works without producing anything you could
mistake for a result.

### A4. Check it against your proposal

```powershell
python scripts\check_proposal_conformance.py
```

Confirms the three models, temperature 0.0, the distilbert backbone, alpha 0.05,
the five rating dimensions and the four taxonomy subtypes all match what the
proposal committed to, and lists the four deliberate deviations.

**If A2, A3 and A4 all pass, the program runs. Everything after this is data.**

---

# Part B — The real experiment

## B1. Install BERTScore (~2 GB, once)

```powershell
pip install bert-score
python -c "import bert_score; from transformers import AutoConfig; AutoConfig.from_pretrained('distilbert-base-uncased'); print('BERTScore ready')"
```

That second line downloads and caches the backbone. It must print
`BERTScore ready`. `ctieval score` refuses to run without real BERTScore rather
than quietly substituting a proxy, so fix this now or you will be stopped later.

> No internet on the machine that runs the experiment? Cache the weights on a
> networked machine and copy `%USERPROFILE%\.cache\huggingface` across.

## B2. Get your API keys

| Key | Where | Cost |
|---|---|---|
| `ANTHROPIC_API_KEY` | console.anthropic.com → API keys | pay-as-you-go, a few pounds for this run |
| `OTX_API_KEY` | otx.alienvault.com → Settings → API key | free |
| `NVD_API_KEY` | nvd.nist.gov/developers/request-an-api-key | free, optional but worth it |

Set them in the PowerShell window you will run from — they last for that window
only, which is what you want:

```powershell
$env:ANTHROPIC_API_KEY = "sk-ant-..."
$env:OTX_API_KEY       = "..."
$env:NVD_API_KEY       = "..."
```

Never put a key in `config.yaml` or `.env.example`. A test fails the build if a
credential-shaped string appears anywhere in the repository.

**Set a spend cap in the Anthropic console now.** Your risk register commits to
£50; the console enforces it, watching the number does not.

## B3. LM Studio — the two open models

This is the part people get wrong, so in detail.

**You never type a prompt into LM Studio.** It runs as a *server*. ctieval sends
the system prompt and each item's prompt over HTTP to
`http://localhost:1234/v1/chat/completions`. Your only job in the LM Studio
window is to load a model and start the server.

**B3.1 — Download both models.** Search tab (magnifying glass):

| Search for | Pick the quantisation | Size |
|---|---|---|
| `Meta-Llama-3-8B-Instruct-GGUF` | **Q4_K_M** | ~4.9 GB |
| `Mistral-7B-Instruct-v0.3-GGUF` | **Q4_K_M** | ~4.4 GB |

Q4_K_M matters — it is the 4-bit quantisation your proposal commits to in S4.5
and S7.2, and what makes an 8B model fit in about 6 GB.

**B3.2 — Start the server.** Developer tab (the `>_` icon on the left):

1. At the top, **Select a model to load** → choose Meta-Llama-3-8B-Instruct.
2. In the load settings, if you have a GPU, raise **GPU Offload** toward maximum.
   On CPU only it still works, just slower.
3. Toggle **Status: Running** (or press **Start Server**). It listens on port 1234.
4. Leave LM Studio open for the whole run. Closing it stops the server.

**B3.3 — Get the exact model identifier.** This is the single most common cause
of a failed run:

```powershell
curl http://localhost:1234/v1/models
```

You will get JSON containing something like
`"id": "meta-llama-3-8b-instruct"`. Copy that string exactly.

**B3.4 — Put it in the config.** Open `config\config.yaml` and set `model_id`
for each open model to what the server actually reported:

```yaml
  - label: "LLaMA 3 8B"
    provider: lmstudio
    model_id: meta-llama-3-8b-instruct      # <- exactly as curl reported
    base_url: http://localhost:1234/v1

  - label: "Mistral 7B"
    provider: lmstudio
    model_id: mistral-7b-instruct-v0.3      # <- exactly as curl reported
    base_url: http://localhost:1234/v1
```

**B3.5 — Confirm.**

```powershell
python -m ctieval preflight
```

The loaded model shows `[PASS]`. The other open model shows `[FAIL]` if LM Studio
is serving one at a time — that is expected, and B6 explains how to handle it.

> **One model at a time.** LM Studio serves a single model by default. Either run
> the two open models in separate passes (B6), or enable multi-model serving in
> Developer settings and load both.

## B4. Add your APT and vendor reports

Vendor licences do not allow automated scraping, so you supply the PDFs.

```powershell
mkdir data\apt_pdfs -Force
```

Put 3–6 public reports in there — Mandiant M-Trends, CrowdStrike Global Threat
Report, MITRE ATT&CK group profiles for APT28 (G0007) and Lazarus (G0032) are the
ones your proposal names in S4.3.1. Delete `sample.pdf` first or it becomes
corpus items.

**Write down the exact pages you use.** S7.3 of the proposal commits to citing
them, and only hashes and page ranges are redistributed, never the text.

## B5. Collect the corpus (~20 minutes)

```powershell
python -m ctieval collect --source all --pdf-dir data\apt_pdfs
```

30 CVEs stratified 10 Critical / 10 High / 10 Medium, 30 OTX pulses from a 30-day
window, and your PDFs segmented into sections. Then check:

```powershell
python scripts\check_proposal_conformance.py
```

It reports the count per source type against the proposal's 30/30/30 and tells
you how many items still need a reference summary.

## B6. Author the reference summaries — the long part

CVE items already have ground truth (the NVD description). OTX and APT items do
not, on purpose: using a pulse's own description as its own reference would
inflate every score in the study.

```powershell
python -m ctieval annotate --export
```

Open `data\reference_summaries.csv` in Excel. For each row read `SOURCE_TEXT` and
write, in the `reference_summary` column, the 60–120 word summary you would hand
a SOC analyst: what the threat is, what it affects, why it matters operationally.

This is around 60 summaries and it is the slowest stage in the whole project.
Export, fill some, import, repeat — progress is kept.

Have your **second practitioner review them**. S4.3.1 commits to this and an
examiner may ask who did it.

```powershell
python -m ctieval annotate --import data\reference_summaries.csv
```

## B7. Generate — smoke test first, always

```powershell
python -m ctieval run --limit 3
```

Three lines marked `ok` means the wiring is right. A wrong `model_id` or a
stopped server shows up here in thirty seconds instead of forty minutes.

Then the full grid. With LM Studio serving one model at a time:

```powershell
python -m ctieval run --models "Claude Sonnet 4.6"
python -m ctieval run --models "LLaMA 3 8B"
```

Now switch the loaded model in LM Studio to Mistral (Developer tab → select
model → Start Server), then:

```powershell
python -m ctieval run --models "Mistral 7B"
```

The runner is resumable and caches by (item, model, prompt). An interrupted run
re-executes only what is missing, and re-running costs nothing. **Watch the cost
line** in the run summary.

## B8. Score

```powershell
python -m ctieval score
```

Then the check that decides whether Chapter 6 is reportable:

```powershell
python -c "import pandas as pd; d=pd.read_csv('results/metrics.csv'); print(d['semantic_metric'].iloc[0])"
```

It must print **`bertscore_f1`**. If it prints `semantic_sim_tfidf`, go back to
B1 — that column is not BERTScore and must not be reported as one.

## B9. Detect, then adjudicate

```powershell
python -m ctieval detect
```

Optionally add the LLM judge (one extra API call per summary, roughly doubles
Claude spend):

```powershell
python -m ctieval detect --judge "Claude Sonnet 4.6"
```

Detection produces **candidates, not findings**. The detector has recall 1.00 and
precision 0.178 — roughly four flags in five are not real errors. Quoting raw
detector counts as a hallucination rate would contradict your own Section 6.2.

```powershell
python -m ctieval adjudicate --export results\adjudication.csv
```

Open it in Excel. Each row is one candidate with the flagged span, the evidence
and the proposed classification. Set `confirmed` to `TRUE` or `FALSE` on every
row, and fix `category` / `subtype` where the detector classified a real error
wrongly.

```powershell
python -m ctieval adjudicate --import results\adjudication.csv
```

It prints detector precision against your adjudication. **That number is a
result** — it goes in Table 6.6.

## B10. Human evaluation

```powershell
python -m ctieval humaneval build --n 4
```

`--n` counts corpus **items** per source type; every model's output for each is
rated, which keeps the agreement statistics paired. `--n 4` gives 12 items × 3
models = 36 rated summaries, closest to the ~30 the proposal describes. The
command prints the exact figures — put them in the Table 6.7 caption.

Send `results\human_eval_sheet.csv` to each of your two practitioners. **Keep
`human_eval_key.csv` to yourself.** A rater who can tell which summary came from
the commercial API contaminates every score.

```powershell
python -m ctieval humaneval analyse --scores rater1=r1.csv --scores rater2=r2.csv
```

Prints per-model scores, weighted kappa per dimension and ICC(2,k). A dimension
below 0.6 is a reportable finding about instrument subjectivity, not a failure.

## B11. Report and verify

```powershell
python -m ctieval report
python scripts\verify_statistics.py results
python scripts\check_proposal_conformance.py
```

`verify_statistics.py` recomputes every number independently and must print
**100/100 checks passed**. If it does not, the numbers are not safe to report.

## B12. Fill Chapter 6

Each `[INSERT …]` slot in the dissertation names the file that fills it:

| Slot | File in `results\report\` |
|---|---|
| §6.3.1 run summary | top of `results_pack.md` |
| Table 6.2 | `table_descriptives.csv` |
| Table 6.3 | `table_metric_confidence_intervals.csv` |
| Figure 6.6 | `figures\fig_metrics_by_model.png` |
| Table 6.4 | `table_by_source_type.csv` |
| Figure 6.7 | `figures\fig_rougeL_by_source.png` |
| §6.3.4 Friedman + Table 6.5 | `table_stats_rougeL_f.csv`, `table_stats_bertscore_f1.csv` |
| Table 6.6 | `table_hallucination_rates.csv` |
| Figure 6.8 | `figures\fig_hallucination.png` |
| Table 6.7 | printed by `humaneval analyse` |
| Figure 6.9 | `figures\fig_cost_latency.png` |

Paste each in, then rewrite the red "Note to author" block under it into prose
using the real numbers. Before submitting, search the document for
`Note to author` and `[INSERT` — every one must be gone — then select the
Contents, List of Figures and List of Tables fields in Word and press **F9**.

---

# One command for all of it

```powershell
python scripts\run_live_experiment.py
```

Checks keys, BERTScore, the backbone, your PDFs and backend reachability before
spending anything, then walks the stages, stopping wherever you need to do
something by hand (authoring summaries, adjudicating, rating).

---

# When something goes wrong

| Symptom | Cause and fix |
|---|---|
| `.venv\Scripts\Activate.ps1 cannot be loaded` | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| `preflight` FAIL on a local model | `model_id` does not match. Re-run `curl http://localhost:1234/v1/models` and copy it exactly. |
| `Connection refused` on port 1234 | LM Studio's server is not running. Developer tab → Status: Running. |
| Every generation for one model errors | That model is not the one currently loaded in LM Studio. |
| `score` exits 3 | BERTScore unavailable — B1. Never use `--allow-semantic-fallback` for real results. |
| `collect` exits 2 | Network or key problem; the message names which. Already-collected records are kept — re-run with `--append`. |
| NVD 403 / 503 | Rate limiting. The collector backs off and retries. An NVD key raises the limit tenfold. |
| Generation very slow | CPU inference. Raise GPU Offload in LM Studio's model load settings. |
| `verify_statistics.py` reports a failure | Do not report the numbers. Send me the output. |
| `check_proposal_conformance.py` says items are synthetic | You are pointing at a dry-run corpus. Collect real data first. |
