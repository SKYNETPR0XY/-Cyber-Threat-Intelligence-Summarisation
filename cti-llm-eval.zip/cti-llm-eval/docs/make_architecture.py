"""Render the ctieval pipeline architecture diagram (Figure 5.1)."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pathlib import Path

BLUE = "#2b5797"
GREEN = "#4f8a3d"
RED = "#c0504d"
PURPLE = "#7b5aa6"
GREY = "#59595b"


def box(ax, x, y, w, h, title, subtitle, edge, fill="#ffffff"):
    ax.add_patch(
        FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.02,rounding_size=0.08",
            linewidth=1.4, edgecolor=edge, facecolor=fill,
        )
    )
    ax.text(x + w / 2, y + h * 0.62, title, ha="center", va="center",
            fontsize=9.5, weight="bold", color=edge)
    ax.text(x + w / 2, y + h * 0.26, subtitle, ha="center", va="center",
            fontsize=7.4, color=GREY)


def arrow(ax, x1, y1, x2, y2):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2),
                                 arrowstyle="-|>", mutation_scale=12,
                                 linewidth=1.2, color=GREY))


fig, ax = plt.subplots(figsize=(9.2, 6.4))
ax.set_xlim(0, 12)
ax.set_ylim(0, 12)
ax.axis("off")

# Stage 1 — sources
ax.text(0.2, 11.5, "CTI sources (public OSINT)", fontsize=9, weight="bold", color=GREY)
box(ax, 0.3, 10.0, 3.5, 1.2, "NVD CVE API", "Structured records", BLUE, "#eef2fb")
box(ax, 4.2, 10.0, 3.5, 1.2, "AlienVault OTX", "IoC pulse narratives", BLUE, "#eef2fb")
box(ax, 8.1, 10.0, 3.5, 1.2, "APT / vendor PDFs", "Narrative reports", BLUE, "#eef2fb")

# Stage 2 — ingestion
box(ax, 0.3, 8.3, 5.5, 1.1, "Stage 1 · Collection", "Collectors → JSONL corpus + provenance", GREEN, "#eef7ec")
box(ax, 6.1, 8.3, 5.5, 1.1, "Stage 2 · Annotation", "Expert reference summaries (blinded 2nd rater)", GREEN, "#eef7ec")

# Stage 3 — generation / providers
ax.text(0.2, 7.7, "Stage 3 · Generation — unified prompt · temperature 0.0", fontsize=8.5, weight="bold", color=GREY)
box(ax, 0.3, 6.0, 3.5, 1.2, "Claude Sonnet 4.6", "Anthropic API", PURPLE, "#f2eef9")
box(ax, 4.2, 6.0, 3.5, 1.2, "LLaMA 3 8B", "LM Studio · 4-bit GGUF", PURPLE, "#f2eef9")
box(ax, 8.1, 6.0, 3.5, 1.2, "Mistral 7B", "LM Studio · 4-bit GGUF", PURPLE, "#f2eef9")

# Stage 4-5 — evaluation
box(ax, 0.3, 4.1, 3.5, 1.2, "Stage 4 · Metrics", "ROUGE · BERTScore · stats", RED, "#faeeee")
box(ax, 4.2, 4.1, 3.5, 1.2, "Stage 5 · Hallucination", "Grounding · LLM judge · SelfCheck", RED, "#faeeee")
box(ax, 8.1, 4.1, 3.5, 1.2, "Human evaluation", "Blinded · κ · ICC(2,k)", RED, "#faeeee")

# Stage 6 — reporting
box(ax, 2.2, 2.2, 7.5, 1.2, "Stage 6 · Reporting", "Figures · tables · results_pack.md (integrity-guarded)", GREEN, "#eef7ec")

# Arrows
for sx in (2.05, 5.95, 9.85):
    arrow(ax, sx, 10.0, sx, 9.45)
arrow(ax, 5.95, 8.3, 5.95, 7.25)
for sx in (2.05, 5.95, 9.85):
    arrow(ax, sx, 6.0, sx, 5.35)
arrow(ax, 5.95, 4.1, 5.95, 3.45)
arrow(ax, 9.85, 4.1, 8.5, 3.42)

fig.tight_layout()
out = Path(__file__).resolve().parent / "architecture.png"
fig.savefig(out, dpi=200, bbox_inches="tight")
print("saved", out)
