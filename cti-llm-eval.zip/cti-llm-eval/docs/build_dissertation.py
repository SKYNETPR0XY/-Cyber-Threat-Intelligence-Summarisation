# -*- coding: utf-8 -*-
"""Build the MSc dissertation .docx from the content modules.

Follows the University of Westminster 7CSEF001W structure (from the provided
template): title page, declaration, consent, acknowledgements, abstract +
keywords, auto TOC / figures / tables fields, then Chapters 1-8, references,
glossary and appendices. Uses python-docx.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Inches

import diss_content_1 as c1
import diss_content_2 as c2
import diss_content_3 as c3

BLUE = RGBColor(0x1F, 0x38, 0x64)
GREY = RGBColor(0x59, 0x59, 0x59)


# --------------------------------------------------------------------------- #
# Low-level helpers
# --------------------------------------------------------------------------- #

def set_cell_bg(cell, hex_colour):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hex_colour)
    tcPr.append(shd)


def add_field(paragraph, instruction):
    """Insert a Word field (e.g. TOC, PAGE) that updates on open."""
    run = paragraph.add_run()
    fldBegin = OxmlElement("w:fldChar")
    fldBegin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    fldSep = OxmlElement("w:fldChar")
    fldSep.set(qn("w:fldCharType"), "separate")
    placeholder = OxmlElement("w:t")
    placeholder.text = ("[Select this field and press F9 in Word to generate. "
                        "Fields are generated on the author's machine, not stored.]")
    fldEnd = OxmlElement("w:fldChar")
    fldEnd.set(qn("w:fldCharType"), "end")
    r = run._r
    r.append(fldBegin)
    r.append(instr)
    r.append(fldSep)
    r.append(placeholder)
    r.append(fldEnd)


def add_page_number_footer(section):
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Page ")
    add_field(p, "PAGE")
    p.add_run(" of ")
    add_field(p, "NUMPAGES")


def caption(doc, text, bold_label=True):
    p = doc.add_paragraph(style="Caption")
    label, _, rest = text.partition(":")
    r = p.add_run(label + ":")
    r.bold = True
    p.add_run(rest)
    return p


# --------------------------------------------------------------------------- #
# Styling
# --------------------------------------------------------------------------- #

def configure_styles(doc):
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.line_spacing = 1.4

    for level, size in [("Heading 1", 16), ("Heading 2", 13), ("Heading 3", 12)]:
        st = doc.styles[level]
        st.font.name = "Calibri"
        st.font.size = Pt(size)
        st.font.color.rgb = BLUE
        st.font.bold = True
        st.paragraph_format.space_before = Pt(14 if level == "Heading 1" else 8)
        st.paragraph_format.space_after = Pt(6)
        st.paragraph_format.keep_with_next = True

    cap = doc.styles["Caption"]
    cap.font.name = "Calibri"
    cap.font.size = Pt(9.5)
    cap.font.italic = True
    cap.font.color.rgb = GREY


# --------------------------------------------------------------------------- #
# Content emitters
# --------------------------------------------------------------------------- #

def emit_blocks(doc, blocks, tables, figures):
    for style, text in blocks:
        if style == "h1":
            doc.add_paragraph(text, style="Heading 1")
        elif style == "h2":
            doc.add_paragraph(text, style="Heading 2")
        elif style == "h3":
            doc.add_paragraph(text, style="Heading 3")
        elif style == "body":
            doc.add_paragraph(text)
        elif style == "bullet":
            doc.add_paragraph(text, style="List Bullet")
        elif style == "note":
            p = doc.add_paragraph()
            r = p.add_run("Note to author — " + text)
            r.italic = True
            r.font.color.rgb = RGBColor(0xB0, 0x00, 0x00)
            r.font.size = Pt(10)
        elif style == "slot":
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(text)
            r.italic = True
            r.font.color.rgb = RGBColor(0x88, 0x00, 0x00)
            set_para_border(p)
        elif style == "caption":
            caption(doc, text)
        elif style == "figure_arch":
            figures["arch"](doc)
        elif style.startswith("figure:"):
            _, name, width = style.split(":")
            add_figure(doc, name, float(width), text)
        elif style.startswith("table_"):
            key = style[len("table_"):]
            if key in tables:
                tables[key](doc)
            else:
                raise KeyError(f"no table builder registered for {style!r}")


def set_para_border(p, colour="880000", style="dashed"):
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    for edge in ("top", "left", "bottom", "right"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), style)
        e.set(qn("w:sz"), "6")
        e.set(qn("w:space"), "6")
        e.set(qn("w:color"), colour)
        pbdr.append(e)
    pPr.append(pbdr)


def make_table(doc, headers, rows, widths, header_bg="1F3864"):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    # Repeat the header row when a table breaks across a page, and stop rows
    # being split mid-cell; both matter because several tables run over a page.
    trPr = table.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader")
    th.set(qn("w:val"), "true")
    trPr.append(th)

    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = ""
        run = hdr[i].paragraphs[0].add_run(h)
        run.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.size = Pt(10)
        set_cell_bg(hdr[i], header_bg)
    for r_i, row in enumerate(rows):
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = ""
            run = cells[i].paragraphs[0].add_run(str(val))
            run.font.size = Pt(9.5)
            if r_i % 2 == 1:
                set_cell_bg(cells[i], "EEF2F8")
    for row in table.rows:
        rPr = row._tr.get_or_add_trPr()
        cant = OxmlElement("w:cantSplit")
        rPr.append(cant)
        for i, w in enumerate(widths):
            row.cells[i].width = Inches(w)
    doc.add_paragraph()
    return table


def table_contrib(doc):
    make_table(doc,
        ["Contribution", "Kind", "Evidenced in"],
        [["ctieval: a modular, tested, reproducible evaluation framework for LLM CTI summarisation, extensible to new models by configuration alone",
          "Artefact", "Ch. 5; Sec. 6.1; Appendices B, E"],
         ["A fully specified, rehearsed and gated protocol for a multi-model, multi-source measurement of CTI summarisation quality and hallucination, with inferential statistics (the live run was not executed; see Sec. 6.3.2)",
          "Protocol", "Sec. 6.3"],
         ["Evidence that a grounding detector for CTI is high-recall and low-precision, making human adjudication a necessity rather than a refinement",
          "Methodological", "Sec. 6.2.1"],
         ["Evidence that the matching granularity used to validate a hallucination detector changes its reported precision by more than a factor of three",
          "Methodological", "Sec. 6.2.2"],
         ["An integrity pattern in which validation output cannot easily be presented as an experimental result",
          "Design", "Sec. 5.3.4; Sec. 6.1.2"]],
        [2.9, 0.95, 1.85])
    caption(doc, "Table 1.1: Contributions and the sections that evidence them.")


def table_tiers(doc):
    make_table(doc,
        ["Tier", "Audience", "Horizon", "Typical artefact", "In scope"],
        [["Strategic", "Executive, board", "Months to years", "Risk narrative, sector trend report", "No"],
         ["Operational", "SOC lead, IR manager", "Weeks to months", "Campaign and actor reporting", "Partly"],
         ["Tactical", "Analyst, threat hunter", "Days to weeks", "TTPs, ATT&CK techniques, vendor reports", "Yes"],
         ["Technical", "Analyst, detection engineer", "Hours to days", "CVE records, IoC pulses, hashes", "Yes"]],
        [0.95, 1.35, 1.1, 1.95, 0.65])
    caption(doc, "Table 2.1: CTI tiers and the scope of this project. The tactical and technical tiers are targeted because they combine actionable specificity with volume that exceeds human reading capacity.")


def table_lit(doc):
    y, n, part = "Yes", "No", "Partial"
    make_table(doc,
        ["Study", "Focus", "Multi-model", "CTI data", "Human eval.", "Halluc. taxonomy"],
        [["Liao et al. (2016)", "IoC extraction", n, y, n, n],
         ["Bridges et al. (2014)", "Log labelling (NLP)", n, y, n, n],
         ["Aghaei et al. (2022)", "Domain LM (SecureBERT)", n, y, n, n],
         ["Bhatt et al. (2023)", "Secure-coding benchmark", y, part, n, n],
         ["Bang et al. (2023)", "General LLM evaluation", n, n, y, part],
         ["Manakul et al. (2023)", "Hallucination detection", part, n, n, part],
         ["Maynez et al. (2020)", "Summarisation faithfulness", y, n, y, part],
         ["Fabbri et al. (2021)", "Metric meta-evaluation", y, n, y, n],
         ["Ji et al. (2023)", "Hallucination taxonomy", "n/a", n, "n/a", y],
         ["This project", "CTI summarisation", y, y, y, y]],
        [1.5, 1.55, 0.85, 0.7, 0.8, 0.95])
    caption(doc, "Table 3.1: The reviewed work against the four dimensions this project addresses. Individual dimensions are well covered; their combination is not.")


def table_obj(doc):
    make_table(doc,
        ["Obj.", "Completion criterion", "Serves", "Deliverable / evidence"],
        [["O1", "Thematic review of >= 20 peer-reviewed or widely-cited sources with an explicit gap statement", "RQ1-RQ4", "Ch. 3; Table 3.1; 38 references"],
         ["O2", "Pipeline generating summaries from >= 3 LLMs under one prompt at temperature 0.0 with full telemetry", "RQ1, RQ3, RQ4", "Ch. 5; Sec. 6.1.1-6.1.2; Appendix B"],
         ["O3", "90-item ground-truth corpus (30 per source type) with provenance registry and validated references", "RQ1", "Sec. 5.2; Table 5.1; Appendix D (collectors and registry delivered; live corpus not assembled - Sec. 6.3.2)"],
         ["O4", "ROUGE + BERTScore with inferential statistics; blinded expert scoring; adjudicated hallucination classification", "RQ1, RQ2, RQ3", "Sec. 6.1.3; Sec. 6.2 (machinery verified; detector findings delivered; model comparison not run - Sec. 6.3)"],
         ["O5", "Practitioner recommendations and released, tested framework with reproducibility documentation", "RQ4", "Sec. 6.4; Ch. 7; Appendices B, C, E"]],
        [0.5, 2.5, 1.0, 1.85])
    caption(doc, "Table 4.1: Objective traceability - completion criterion, research questions served, and the deliverable that evidences each objective.")


def table_corpus(doc):
    make_table(doc,
        ["Source type", "n", "Origin", "Ground truth", "Stresses"],
        [["CVE records", "30", "NVD 2.0 REST API, stratified 10 Critical / 10 High / 10 Medium, CWE-capped",
          "NVD description (withheld from model input)", "Fidelity to exact identifiers and scores"],
         ["OTX pulses", "30", "AlienVault OTX, 30-day window, >= 200 words of English narrative",
          "Researcher-authored, practitioner-validated", "Signal extraction from noisy semi-structured input"],
         ["APT / vendor sections", "30", "Locally held public report PDFs, layout-segmented into sections",
          "Per-section sidecar reference, practitioner-validated", "Genuine abstractive summarisation of long-form prose"]],
        [1.25, 0.32, 1.85, 1.5, 1.4])
    caption(doc, "Table 5.1: Corpus composition, provenance of ground truth, and the summarisation capability each stratum is designed to stress.")


def table_reqs(doc):
    make_table(doc,
        ["#", "Requirement", "Type", "Satisfied by", "Demonstrated by"],
        [["R1", "Ingest all three source types into one schema", "F (O2, O3)", "Three collectors + CTIItem schema", "Sec. 6.1.2; collector tests"],
         ["R2", "Generate summaries from any configured model behind a uniform interface", "F (O2)", "Provider abstraction, three backends", "preflight; provider tests"],
         ["R3", "Score with ROUGE and BERTScore and apply inferential statistics", "F (O4)", "Metrics module", "Sec. 6.1.3, 100/100 checks"],
         ["R4", "Detect, adjudicate and classify hallucination against the taxonomy", "F (O4)", "Hallucination module + adjudication worksheet", "Sec. 6.2; Appendix G"],
         ["R5", "Produce a blinded human-evaluation instrument and analyse returns", "F (O4)", "Human-evaluation module", "Appendix F; blinding test"],
         ["R6", "Emit publication-ready tables and figures", "F (O5)", "Reporting layer", "Sec. 6.1.2; Ch. 6 figures"],
         ["R7", "Reproducible: fixed seed, pinned configuration, deterministic decoding", "NF", "config.yaml + provenance registry", "Appendix C"],
         ["R8", "Resumable: an interrupted run must not repeat completed work", "NF", "Runner keyed on (item, model, prompt)", "Runner tests"],
         ["R9", "Secure: no credential in code, configuration or results", "NF", "Environment-only credentials", "Repository-hygiene tests"],
         ["R10", "Honest: hard to present validation output as a result", "NF", "Watermark, refusal flags, candidate labelling", "Sec. 6.1.2; integrity tests"]],
        [0.35, 2.05, 0.75, 1.6, 1.4])
    caption(doc, "Table 5.2: Functional (F) and non-functional (NF) requirements, traced to objectives, to the design element that satisfies each, and to the evidence that demonstrates it.")


def table_alts(doc):
    make_table(doc,
        ["Decision", "Chosen", "Alternatives considered", "Rationale"],
        [["Local model serving", "LM Studio (OpenAI-compatible endpoint)", "Raw llama.cpp; HF Transformers pipeline",
          "Both open models share one serving stack, removing framework difference as a confound; provider layer reduces to one HTTP client."],
         ["Data layer", "JSON Lines files", "Relational database; LangChain orchestration",
          "Small dataset; transparency and resumability matter more than throughput; plain text is inspectable and diffable."],
         ["Decoding", "Temperature 0.0, single run", "Sampling with n-fold averaging",
          "Reproducibility of the primary comparison preferred over a variance estimate at this n; stochasticity used only where it is the signal."],
         ["Hallucination detection", "Three complementary detectors", "Single LLM judge; single heuristic",
          "No detector is sufficient alone; a deterministic checker cannot be prompt-injected; disagreement between detectors is informative."],
         ["Semantic metric backbone", "distilbert-base-uncased, unrescaled", "roberta-large (library default)",
          "Compute constraint; disclosed because it lowers human correlation and makes absolute values non-comparable with rescaled figures."]],
        [1.15, 1.4, 1.5, 2.1])
    caption(doc, "Table 5.3: Principal design decisions, the alternatives considered, and the rationale for each.")


def table_taxonomy(doc):
    make_table(doc,
        ["Subtype", "Category", "Definition", "CTI example", "Operational consequence"],
        [["Entity error", "Intrinsic", "A named identifier or entity is replaced by a different one",
          "CVE-2024-3400 reported as CVE-2024-3401", "Analyst patches or hunts for the wrong artefact"],
         ["Relational error", "Intrinsic", "Entities are correct but the relationship between them is inverted",
          "'allows' rendered as 'prevents'; 'unauthenticated' as 'authenticated'", "Exploitability is misjudged in either direction"],
         ["Circumstantial error", "Intrinsic", "A quantity, version, date or condition contradicts the source",
          "CVSS 9.1 reported as 7.7; affected version wrong", "Remediation is mis-prioritised"],
         ["Fabrication", "Extrinsic", "A claim with no basis whatsoever in the source",
          "Invented active-exploitation status, actor attribution or public PoC", "Emergency change process triggered without cause"]],
        [1.0, 0.75, 1.5, 1.65, 1.4])
    caption(doc, "Table 5.4: The Ji et al. (2023) taxonomy specialised for CTI, with the operational consequence of each subtype. A severity axis recording whether the error would change an analyst's action is stored alongside the subtype.")


def table_atoms(doc):
    make_table(doc,
        ["Atom type", "Extraction", "Check applied", "Classification if unsupported"],
        [["CVE / CWE / ATT&CK / CAPEC identifier", "Pattern match", "Present in source, or matches structured metadata", "Entity error (intrinsic)"],
         ["CVSS base score", "Cue phrase near a decimal, vector string masked first", "Equals the score in the record metadata", "Circumstantial error (intrinsic)"],
         ["Severity band", "Cue phrase", "Equals the severity in the record metadata", "Circumstantial error (intrinsic)"],
         ["IPv4 address, domain, file hash", "Pattern match", "Present verbatim in the source", "Entity error, or fabrication if no family present"],
         ["Version, port, year, percentage", "Pattern match", "Present in the source", "Circumstantial error"],
         ["Capitalised entity", "Sentence-internal capitalisation, stop-list filtered", "Head token present in source or reference", "Fabrication (extrinsic)"],
         ["High-consequence claim", "Phrase family (exploitation, PoC, zero-day, ransomware, attribution)", "Same claim family present in the source", "Fabrication (extrinsic)"],
         ["Polarity pair", "Term-pair lookup", "Source asserts the same polarity", "Relational error (intrinsic)"]],
        [1.35, 1.5, 1.75, 1.55])
    caption(doc, "Table 5.5: Checkable atom types extracted by the deterministic grounding checker, the rule applied to each, and the taxonomy subtype assigned when the check fails. The CVSS vector is masked before score extraction; see Section 5.4.2.")


def table_validity(doc):
    make_table(doc,
        ["Type", "Threat", "Control"],
        [["Construct", "ROUGE and BERTScore measure similarity, not correctness (Maynez et al., 2020)",
          "Factuality measured by a separate, source-grounded instrument; no reliability claim rests on an overlap score"],
         ["Construct", "The CVE reference is partly underivable from the input shown to the model (Sec. 5.2.1)",
          "Disclosed; CVE scores treated as a lower bound and compared within stratum, not across strata"],
         ["Internal", "Prompt variation confounded with model identity",
          "One unified prompt template applied to every model; prompt identifier logged per summary"],
         ["Internal", "Rater knowledge of model identity contaminates scores",
          "Salted-hash blinding; key file withheld from raters; matched item sampling"],
         ["Internal", "Researcher-authored ground truth correlates with one model's style",
          "References written before any model output is seen; second-practitioner validation; human scoring against source as well as reference"],
         ["Internal", "Detector false positives inflate the hallucination rate",
          "Detector validated against seeded errors before use; every finding human-adjudicated; flagged and confirmed rates reported separately"],
         ["External", "Results describe 4-bit quantised open models, not full-precision weights",
          "Stated as a scope condition; the quantised variant is the deployable one, which is the operationally relevant comparison"],
         ["External", "Model versions change beneath their identifiers",
          "Model identifier, version and run timestamp recorded per summary; results are point-in-time by declaration"],
         ["Conclusion", "Limited power at n = 90 to detect small differences",
          "Effect sizes and confidence intervals reported alongside p-values; non-significance reported as undetected difference, not equivalence"],
         ["Conclusion", "Multiple comparisons inflate the family-wise error rate",
          "Holm-Bonferroni correction applied within each metric family; the scope of correction stated explicitly"]],
        [0.85, 2.55, 2.75])
    caption(doc, "Table 5.6: Threats to validity and the controls that limit them.")


def table_detector(doc):
    make_table(doc,
        ["Matching strategy", "Precision", "Recall", "F1", "Seeded errors", "Flags"],
        [["Pooled span sets across the corpus (original)", "0.714", "1.000", "0.833", "10", "14"],
         ["Per finding, on (item, model, span) triples (corrected)", "0.178", "1.000", "0.303", "64", "359"]],
        [2.6, 0.75, 0.65, 0.6, 0.85, 0.55])
    caption(doc, "Table 6.1: The same detector, the same data, two matching strategies. Pooling spans across the corpus collapses repeated false positives into a single entry and overstates precision by a factor of four. Reproduce with `python scripts/dryrun_fullscale.py`.")


def table_plan(doc):
    headers = ["Phase", "Timeframe", "Key tasks", "Milestone / deliverable"]
    rows = [
        ["1", "12 Jun – 2 Jul", "Systematic literature review; annotated bibliography (≥20 sources); finalise research questions", "Literature matrix"],
        ["2", "3 Jul – 17 Jul", "Pipeline architecture; API and LM Studio setup; corpus schema; testbed configuration", "Operational pipeline; approved schema"],
        ["3", "17 Jul – 31 Jul", "CVE / OTX / APT collection; reference-summary authoring and second-rater validation; provenance log", "Annotated ground-truth corpus"],
        ["4", "31 Jul – 21 Aug", "Run experiments; ROUGE + BERTScore; preliminary hallucination annotation; inter-rater check", "Raw results; preliminary scores"],
        ["5", "21 Aug – 4 Sep", "Friedman + Wilcoxon; expert-score consolidation; kappa/ICC; thematic barrier analysis", "Complete analysis; RQ answers"],
        ["6", "4 Sep – 8 Sep", "Dissertation drafting; supervisor review; revision; submission", "Completed dissertation"],
    ]
    make_table(doc, headers, rows, [0.55, 1.15, 3.0, 1.7])
    caption(doc, "Table 4.2: Plan of work by phase.")


def table_risk(doc):
    headers = ["Risk", "Likelihood", "Impact", "Mitigation"]
    rows = [
        ["LLM API cost overrun", "Medium", "High", "Hard £50 spend cap; daily monitoring; fall back to local models if exhausted."],
        ["Hallucination invalidates results", "High", "High", "Report hallucination as a primary finding, not a flaw; validate every output against source."],
        ["Compute limits for local models", "Medium", "Medium", "4-bit GGUF quantisation via LM Studio; 8B not 70B; Colab as optional fallback."],
        ["Insufficient ground-truth quality", "Low", "High", "Two evaluators; weighted kappa ≥ 0.6; structured instrument with worked examples."],
        ["Data-source API unavailability", "Low", "High", "Cache corpus early; SHA-256 provenance; CISA alerts as NVD fallback."],
        ["Timeline slippage", "Medium", "Medium", "Buffer weeks in Phases 4 and 6; prioritise RQ1/RQ2; scope reduction agreed with supervisor."],
        ["Ethical issue with data use", "Low", "Low", "Public OSINT only; no personal data; ethics approved (ETH2526-2085)."],
    ]
    make_table(doc, headers, rows, [1.8, 0.9, 0.7, 3.0])
    caption(doc, "Table 4.3: Risk register with likelihood, impact and mitigation. Entries marked in Section 4.4.1 materialised during the project.")



# --------------------------------------------------------------------------- #
# Rehearsal (DRY RUN) tables, read from results/dryrun — synthetic corpus,
# stand-in providers. Every one is headed in red and captioned as DRY RUN so
# it cannot be mistaken for an experimental result.
# --------------------------------------------------------------------------- #
DRYRUN = Path(__file__).resolve().parent.parent / "results" / "dryrun"
DR_BG = "7A1F1F"
DR_TAG = " (DRY RUN — synthetic corpus, stand-in configurations; not an experimental result)"


def _dr(name):
    import pandas as pd
    return pd.read_csv(DRYRUN / "report" / name)


def _dr_json(name):
    import json
    return json.loads((DRYRUN / name).read_text(encoding="utf-8"))


def _standin(label):
    return str(label).split("(", 1)[0].strip()


def table_dr_metrics(doc):
    d = _dr("table_descriptives.csv"); c = _dr("table_metric_confidence_intervals.csv")
    rows = []
    for _, r in d.iterrows():
        ci = c[c["Model"] == r["Model"]].iloc[0]
        def cell(k):
            return f"{r[k+'_mean']:.3f} ± {r[k+'_std']:.3f}\n{ci[k+'_ci95']}"
        rows.append([_standin(r["Model"]), cell("rouge1_f"), cell("rouge2_f"), cell("rougeL_f"),
                     cell("semantic_sim_tfidf"),
                     f"{r['novel_unigram_rate_mean']:.3f} ± {r['novel_unigram_rate_std']:.3f}"])
    make_table(doc, ["Configuration", "ROUGE-1 F", "ROUGE-2 F", "ROUGE-L F",
                     "TF-IDF proxy (not BERTScore)", "Novel-unigram rate"], rows,
               [1.0, 1.05, 1.05, 1.05, 1.2, 0.95], header_bg=DR_BG)
    caption(doc, "Table 6.2: Automated metrics by stand-in configuration from the full-scale rehearsal, mean ± SD over 90 items with bootstrap 95% interval beneath. The semantic column is the labelled TF-IDF proxy because the BERTScore backbone was unavailable (Section 6.3.2)." + DR_TAG + " Source: results/dryrun/report/table_descriptives.csv and table_metric_confidence_intervals.csv.")


def table_dr_source(doc):
    d = _dr("table_by_source_type.csv")
    names = {"apt": "APT report sections", "cve": "CVE records", "otx": "OTX pulses"}
    rows = [[names[r["source_type"]], _standin(r["model_label"]), f"{r['rouge1_f']:.3f}",
             f"{r['rouge2_f']:.3f}", f"{r['rougeL_f']:.3f}", f"{r['semantic_sim_tfidf']:.3f}"]
            for _, r in d.iterrows()]
    make_table(doc, ["Source type", "Configuration", "ROUGE-1 F", "ROUGE-2 F", "ROUGE-L F",
                     "TF-IDF proxy"], rows, [1.5, 1.1, 0.9, 0.9, 0.9, 0.9], header_bg=DR_BG)
    caption(doc, "Table 6.3: Automated metrics by CTI source type and stand-in configuration from the rehearsal (means over 30 items per cell)." + DR_TAG + " Source: results/dryrun/report/table_by_source_type.csv.")


def table_dr_omnibus(doc):
    o = _dr_json("omnibus.json")
    lab = {"rouge1_f": "ROUGE-1 F", "rougeL_f": "ROUGE-L F", "semantic_sim_tfidf": "TF-IDF proxy"}
    rows = []
    for k, v in o.items():
        p = v["friedman_p"]
        rows.append([lab.get(k, k), str(v["n_items"]), f"{v['friedman_chi2']:.2f}",
                     "< 0.001" if p < 0.001 else f"{p:.4f}", f"{v['kendalls_w']:.3f}"])
    make_table(doc, ["Metric", "n (paired items)", "Friedman χ²", "p", "Kendall's W"], rows,
               [1.6, 1.1, 1.1, 1.0, 1.0], header_bg=DR_BG)
    caption(doc, "Table 6.4: Friedman omnibus test and Kendall's W per metric from the rehearsal, three configurations paired over 90 items." + DR_TAG + " Source: results/dryrun/omnibus.json.")


def table_dr_pairwise(doc):
    import pandas as pd
    lab = {"rouge1_f": "ROUGE-1 F", "rougeL_f": "ROUGE-L F", "semantic_sim_tfidf": "TF-IDF proxy"}
    frames = [_dr(f"table_stats_{k}.csv") for k in ("rougeL_f", "rouge1_f", "semantic_sim_tfidf")]
    d = pd.concat(frames)
    def fp(p):
        return "< 0.001" if p < 0.001 else f"{p:.4f}"
    rows = [[lab[r["metric"]], f"{_standin(r['model_a'])} vs {_standin(r['model_b'])}",
             f"{r['median_a']:.3f}", f"{r['median_b']:.3f}", f"{r['wilcoxon_W']:.0f}",
             fp(r["p_raw"]), fp(r["p_holm"]), f"{r['rank_biserial_r']:.2f}",
             "yes" if bool(r["significant"]) else "no"] for _, r in d.iterrows()]
    make_table(doc, ["Metric", "Contrast", "Median A", "Median B", "W", "p (raw)", "p (Holm)",
                     "r (rank-biserial)", "Sig. at α = 0.05"], rows,
               [0.85, 1.55, 0.6, 0.6, 0.5, 0.65, 0.65, 0.75, 0.6], header_bg=DR_BG)
    caption(doc, "Table 6.5: Pairwise Wilcoxon signed-rank tests with Holm correction applied within each metric family and matched-pairs rank-biserial effect sizes, from the rehearsal (n = 90 pairs per contrast)." + DR_TAG + " Source: results/dryrun/report/table_stats_*.csv.")


def table_dr_halluc(doc):
    d = _dr("table_hallucination_rates.csv")
    rows = [[_standin(r["Model"]), f"{r['Flagged']} of {r['Summaries']}", f"{r['Flagged %']:.1f}",
             str(r["95% CI"]), f"{r['Findings']} ({r['Findings/summary']:.2f})",
             f"{r['Intrinsic']} / {r['Extrinsic']}",
             f"{r['Entity']} / {r['Relational']} / {r['Circumstantial']} / {r['Fabrication']}"]
            for _, r in d.iterrows()]
    make_table(doc, ["Configuration", "Flagged", "Flagged %", "Wilson 95% CI",
                     "Findings (per summary)", "Intrinsic / Extrinsic",
                     "Entity / Relational / Circumstantial / Fabrication"], rows,
               [0.95, 0.8, 0.7, 0.95, 0.95, 0.85, 1.5], header_bg=DR_BG)
    caption(doc, "Table 6.6: Detector-flagged rates from the rehearsal with Wilson 95% intervals, atom-level finding counts, and the category and taxonomy-subtype breakdown, 90 summaries per configuration. These are unadjudicated flags and therefore upper bounds that include the detector's false positives (Section 6.2); the table names itself 'flagged' rather than 'confirmed' for that reason." + DR_TAG + " Source: results/dryrun/report/table_hallucination_rates.csv.")


def table_dr_human(doc):
    import pandas as pd
    h = pd.read_csv(DRYRUN / "human_scores.csv")
    dims = ["factual_accuracy", "completeness", "conciseness", "relevance",
            "absence_of_hallucination", "composite"]
    g = h.groupby("model_label")[dims].mean().reset_index()
    rows = [[_standin(r["model_label"])] + [f"{r[k]:.2f}" for k in dims] for _, r in g.iterrows()]
    make_table(doc, ["Configuration", "Factual accuracy", "Completeness", "Conciseness",
                     "Relevance", "Absence of hallucination", "Composite"], rows,
               [1.2, 0.9, 0.9, 0.9, 0.85, 1.0, 0.85], header_bg=DR_BG)
    caption(doc, "Table 6.7: Mean scores (1–5) on the five operational dimensions from the rehearsal's blinded evaluation workbook, 30 rated summaries per configuration, two raters. The raters are simulated by the rehearsal harness — no practitioner scored anything — and the table exists to show the instrument's output form." + DR_TAG + " Source: results/dryrun/human_scores.csv.")


def table_dr_agreement(doc):
    import pandas as pd
    txt = (DRYRUN / "report" / "results_pack.md").read_text(encoding="utf-8")
    import re
    m = re.search(r"\*\*Inter-rater agreement\.\*\*(.+)", txt)
    pairs = [(k, v.rstrip(".")) for k, v in re.findall(r"(\w+) = ([0-9.]+)", m.group(1))] if m else []
    names = {"kappa_w_factual_accuracy": "Factual accuracy (weighted κ)",
             "kappa_w_completeness": "Completeness (weighted κ)",
             "kappa_w_conciseness": "Conciseness (weighted κ)",
             "kappa_w_relevance": "Relevance (weighted κ)",
             "kappa_w_absence_of_hallucination": "Absence of hallucination (weighted κ)",
             "icc2k_composite": "Composite (ICC(2,k))",
             "n_double_rated": "Double-rated summaries (n)"}
    def band(k, v):
        if k == "n_double_rated": return "—"
        v = float(v)
        if k.startswith("icc"): return "—"
        return "substantial" if v >= 0.61 else "moderate" if v >= 0.41 else "fair" if v >= 0.21 else "slight"
    rows = [[names.get(k, k), v if k == "n_double_rated" else f"{float(v):.3f}", band(k, v)] for k, v in pairs]
    make_table(doc, ["Dimension / statistic", "Value", "Landis and Koch (1977) band"], rows,
               [2.6, 0.9, 2.2], header_bg=DR_BG)
    caption(doc, "Table 6.8: Inter-rater agreement per dimension from the rehearsal workbook, as the analysis stage reports it. Because the raters are simulated, the values demonstrate the agreement machinery and its banding, not practitioner agreement." + DR_TAG + " Source: printed by `ctieval humaneval analyse`; recorded in results/dryrun/report/results_pack.md.")


def add_verbatim(doc, text, size=8.5):
    """Reproduce text exactly, in a bordered monospace block."""
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.25)
    p.paragraph_format.right_indent = Inches(0.15)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    set_para_border(p, colour="B4BCC8", style="single")
    r = p.add_run(text)
    r.font.name = "Consolas"
    r.font.size = Pt(size)
    return p


def add_figure(doc, filename, width_in, caption_text):
    """Insert a figure from docs/ or docs/screenshots/ with a numbered caption."""
    base = Path(__file__).resolve().parent
    for candidate in (base / filename, base / "screenshots" / filename,
                      base.parent / "results" / "dryrun" / "report" / "figures" / filename):
        if candidate.exists():
            doc.add_picture(str(candidate), width=Inches(width_in))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            break
    else:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(f"[figure not found: {filename}]")
        r.italic = True
        r.font.color.rgb = RGBColor(0x88, 0x00, 0x00)
    caption(doc, caption_text)


def figure_arch(doc):
    img = Path(__file__).resolve().parent / "architecture.png"
    if img.exists():
        doc.add_picture(str(img), width=Inches(6.0))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    caption(doc, "Figure 5.1: The six-stage ctieval pipeline. Each stage reads and writes a shared JSON Lines schema; the provider abstraction lets any model be added by configuration.")


# --------------------------------------------------------------------------- #
# Front matter
# --------------------------------------------------------------------------- #

def title_page(doc):
    for _ in range(2):
        doc.add_paragraph()
    def centred(text, size, bold=True, colour=None, italic=False):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(text)
        r.bold = bold
        r.italic = italic
        r.font.size = Pt(size)
        if colour:
            r.font.color.rgb = colour
        return p

    centred("College of Creative Arts and Technologies (CAT)", 15, colour=BLUE)
    centred("School of Computer Science and Engineering", 12, bold=False, colour=BLUE)
    for _ in range(3):
        doc.add_paragraph()
    centred("Evaluating Large Language Models for Automated", 20, colour=BLUE)
    centred("Cyber Threat Intelligence Summarisation", 20, colour=BLUE)
    doc.add_paragraph()
    centred("A reproducible framework for benchmarking summarisation quality and hallucination", 12, bold=False, italic=True, colour=GREY)
    for _ in range(3):
        doc.add_paragraph()
    centred("Teu Eleberi", 14)
    centred("Student ID: W18850154", 12, bold=False)
    centred("Supervisor: Djuradj Budimir", 12, bold=False)
    centred("Module Code: 7CSEF001W", 12, bold=False)
    for _ in range(3):
        doc.add_paragraph()
    centred("This report is submitted in partial fulfilment of the requirements for the degree of", 11, bold=False)
    centred("MSc Cyber Security and Forensics", 13)
    centred("University of Westminster", 11, bold=False)
    doc.add_paragraph()
    centred("Academic Year 2025/26", 11, bold=False, colour=GREY)
    doc.add_page_break()


def simple_heading_page(doc, title, paragraphs, page_break=True):
    doc.add_paragraph(title, style="Heading 1")
    for para in paragraphs:
        doc.add_paragraph(para)
    if page_break:
        doc.add_page_break()


def declaration_and_consent(doc):
    doc.add_paragraph("Declaration", style="Heading 1")
    doc.add_paragraph(
        "I, Teu Eleberi, declare that I am the sole author of this Project; that all "
        "references cited have been consulted; that I have conducted all work of which "
        "this is a record; and that the finished work lies within the prescribed word "
        "limits. This work has not previously been accepted as part of any other degree "
        "submission."
    )
    doc.add_paragraph()
    doc.add_paragraph("Signature: ______________________________    Date: ____________________")
    doc.add_paragraph("Print Name: Teu Eleberi")
    doc.add_paragraph()
    doc.add_paragraph("Form of Consent", style="Heading 1")
    doc.add_paragraph(
        "I, Teu Eleberi, hereby consent that this Project, submitted in partial "
        "fulfilment of the requirements for the award of the MSc degree, if successful, "
        "may be made available in paper or electronic format for inter-library loan or "
        "photocopying (subject to the law of copyright), and that the title and abstract "
        "may be made available to outside organisations."
    )
    doc.add_paragraph()
    doc.add_paragraph("Signature: ______________________________    Date: ____________________")
    doc.add_paragraph("Print Name: Teu Eleberi")
    doc.add_page_break()


def abstract_page(doc):
    doc.add_paragraph("Abstract", style="Heading 1")
    for para in c1.ABSTRACT.split("\n\n"):
        if para.strip().startswith("[RESULTS PLACEHOLDER"):
            p = doc.add_paragraph()
            r = p.add_run(para.strip())
            r.italic = True
            r.font.color.rgb = RGBColor(0xB0, 0x00, 0x00)
        else:
            doc.add_paragraph(para.strip())
    doc.add_paragraph("Keywords", style="Heading 2")
    doc.add_paragraph(c3 if False else c1.KEYWORDS)
    doc.add_page_break()


def toc_page(doc):
    doc.add_paragraph("Table of Contents", style="Heading 1")
    add_field(doc.add_paragraph(), 'TOC \\o "1-3" \\h \\z \\u')
    doc.add_page_break()
    doc.add_paragraph("List of Figures", style="Heading 1")
    add_field(doc.add_paragraph(), 'TOC \\h \\z \\c "Figure"')
    doc.add_page_break()
    doc.add_paragraph("List of Tables", style="Heading 1")
    add_field(doc.add_paragraph(), 'TOC \\h \\z \\c "Table"')
    doc.add_page_break()


def references_page(doc):
    doc.add_paragraph("References", style="Heading 1")
    for ref in c3.REFERENCES:
        p = doc.add_paragraph(ref)
        p.paragraph_format.left_indent = Inches(0.5)
        p.paragraph_format.first_line_indent = Inches(-0.5)
        p.paragraph_format.space_after = Pt(6)
    doc.add_page_break()


def glossary_page(doc):
    doc.add_paragraph("Glossary of Terms", style="Heading 1")
    make_table(
        doc,
        ["Term / Abbreviation", "Definition"],
        [[t, d] for t, d in c3.GLOSSARY],
        [1.7, 4.5],
    )
    doc.add_page_break()


def appendices_page(doc):
    doc.add_paragraph("Appendices", style="Heading 1")

    doc.add_paragraph("Appendix A: Ethics Approval", style="Heading 2")
    doc.add_paragraph(
        "Ethics application ETH2526-2085 (\"Evaluating Large Language Models for "
        "Automated Cyber Threat Intelligence Summarisation\") was submitted on 9 June "
        "2026 and signed off on 10 June 2026. The signed-off record is reproduced in "
        "the project proposal. The application covers the processing of publicly "
        "available open-source intelligence only, the absence of personal-data "
        "processing, and the participation of two cybersecurity practitioners in the "
        "blinded evaluation, who gave informed consent and are not identified."
    )

    doc.add_paragraph("Appendix B: Evaluation Framework (Code)", style="Heading 2")
    doc.add_paragraph(
        "The complete ctieval framework accompanies this dissertation as a source "
        "archive and is released under an open licence. It comprises the six-stage "
        "pipeline, three source collectors plus an offline generator used only for "
        "validation, three model backends behind a common provider interface, the "
        "three-detector hallucination subsystem with its adjudication workflow, the "
        "blinded human-evaluation instrument, the reporting layer, a seventy-two-test "
        "suite and an independent statistical verification harness. The README "
        "documents the exact command sequence used to reproduce the experiment."
    )
    make_table(
        doc,
        ["Module", "Responsibility"],
        [["schema.py", "CTIItem and Generation dataclasses; JSON Lines I/O; taxonomy constants"],
         ["config.py", "YAML configuration loading; environment-only credential resolution"],
         ["prompts.py", "The unified summarisation prompt and the source-type variants"],
         ["providers/", "Anthropic REST, LM Studio, and deterministic test-harness backends"],
         ["collectors/", "NVD, OTX and PDF collectors; shared HTTP retry layer; offline generator"],
         ["metrics.py", "ROUGE, BERTScore, Friedman, Wilcoxon, Holm, effect sizes, interval estimators"],
         ["hallucination.py", "Atom extraction, grounding rules, LLM judge, SelfCheck, detector validation"],
         ["humaneval.py", "Blinded workbook construction; weighted kappa; ICC(2,k)"],
         ["report.py", "Figures, tables, results pack, and the integrity guards"],
         ["runner.py", "Resumable experiment execution and telemetry capture"],
         ["cli.py", "Ten-command interface: collect, annotate, preflight, run, score, detect, adjudicate, humaneval, report, demo"]],
        [1.35, 4.85],
    )
    caption(doc, "Table B.1: Module responsibilities in the released framework.")

    doc.add_paragraph("Appendix C: Reproducibility Checklist", style="Heading 2")
    for line in [
        "Fixed random seed and temperature 0.0 recorded in config.yaml; a run is described by (git commit, config file).",
        "One unified prompt template applied across all models; prompt identifier logged per summary.",
        "SHA-256 content hash logged for every corpus item in the provenance registry.",
        "Model identity, version, token counts, latency and cost logged per summary.",
        "Grounding detector validated against seeded errors before use, matched per finding; precision and recall reported.",
        "Every detector finding human-adjudicated before any hallucination rate is reported.",
        "BERTScore backbone and library versions pinned; scoring fails rather than silently substituting a labelled proxy.",
        "Multiple-comparison correction applied within metric family, and the scope stated.",
        "All reported statistics independently recomputed by scripts/verify_statistics.py (100 checks).",
        "API credentials read only from environment variables; repository-hygiene test fails the build on any credential-shaped string.",
        "Synthetic corpora watermark every figure and block results-pack emission without an explicit override.",
    ]:
        doc.add_paragraph(line, style="List Bullet")

    doc.add_page_break()
    doc.add_paragraph("Appendix D: Provenance Registry (extract)", style="Heading 2")
    doc.add_paragraph(
        "Every collection run appends to the provenance registry, which records for "
        "each corpus item its identifier, source type, origin, retrieval timestamp, "
        "source and reference word counts, and the SHA-256 hash of the source text. "
        "The registry is the mechanism by which a third party can confirm that the "
        "corpus a study reports on is the corpus they have reconstructed. The rows "
        "below are illustrative of the schema only, with placeholder identifiers and "
        "hashes: no live corpus was collected in this project (Section 6.3.2), so no "
        "real registry entry exists to reproduce."
    )
    make_table(
        doc,
        ["item_id", "type", "origin", "src words", "ref words", "sha256 (first 16)"],
        [["cve::CVE-YYYY-NNNNN", "cve", "NVD 2.0 REST API", "312", "58", "a3f1c0e28b7d4419"],
         ["otx::<pulse id>", "otx", "AlienVault OTX API v1", "684", "94", "77b2ee5a10c3d8f0"],
         ["apt::<report>::s003", "apt", "local PDF, pp. 11-13", "1180", "112", "0c94ab6f2d517e33"]],
        [1.7, 0.55, 1.7, 0.75, 0.75, 1.35],
    )
    caption(doc, "Table D.1: Provenance registry schema with one illustrative row per source type.")

    doc.add_paragraph("Appendix E: Test Inventory", style="Heading 2")
    doc.add_paragraph(
        "The suite comprises seventy-two tests executing in roughly thirty seconds "
        "without network access, model downloads or API keys. Figure E.1 reproduces "
        "the named inventory as emitted by pytest."
    )
    add_figure(doc, "shot_tests_verbose.png", 6.1,
               "Figure E.1: The complete named test inventory. Reproduce with `python -m pytest -v`.")
    make_table(
        doc,
        ["Area", "Tests", "Representative coverage"],
        [["Hallucination detection", "15", "Atom extraction; CVSS vector defect; contradicted score; unsupported exploitation claim; polarity inversion; detector validity matched per finding; LLM-judge reply parsing; SelfCheck consistency"],
         ["Statistics and metrics", "15", "Holm monotonicity; rank-biserial signs; paired-matrix construction; weighted kappa vs scikit-learn; ICC; Wilson and bootstrap intervals; BERTScore cache check, end-to-end computation on an offline backbone, and context clipping"],
         ["CLI end-to-end", "10", "Every command's success and failure exit codes; annotate and adjudication round trips; human-evaluation build and analyse; detector validation reaching the report"],
         ["Integrity guards", "7", "Dry run refuses a production corpus and configuration; scoring refuses a proxy metric; reporting refuses synthetic data; proposal-conformance checker flags a synthetic corpus"],
         ["Schema, config, providers, hygiene", "12", "Round-trip serialisation; source-type validation; provider registry; retry behaviour; credentials never read from files or committed; mock provider reproducible across processes"],
         ["Collectors", "7", "PDF section extraction; offline determinism and sizing; shared-reference rule; HTTP retry and clean failure"],
         ["Human evaluation", "2", "Blinded sheet hides model identity; sample counts items per source type"],
         ["Reporting and figures", "4", "Metric label mapping; mutually exclusive hallucination categories matching the table; Wilson intervals and confirmed rates in the rates table"]],
        [1.6, 0.55, 4.05],
    )
    caption(doc, "Table E.1: Distribution of the test suite across the areas of the framework.")

    doc.add_page_break()
    doc.add_paragraph("Appendix F: Human Evaluation Instrument", style="Heading 2")
    doc.add_paragraph(
        "Each rater receives a CSV workbook containing only an opaque evaluation "
        "identifier, the source text, the reference summary and the candidate "
        "summary. The model that produced each candidate is withheld; the mapping is "
        "written to a separate key file that raters do not receive. Raters score five "
        "dimensions from 1 to 5 and may add free-text notes."
    )
    make_table(
        doc,
        ["Dimension", "1", "5"],
        [["Factual accuracy", "Multiple false statements", "Every statement supported by the source"],
         ["Completeness", "Omits the central point", "Captures everything operationally important"],
         ["Conciseness", "Padded or repetitive", "No wasted words"],
         ["Relevance", "Wrong audience or focus", "Exactly what a SOC analyst needs first"],
         ["Absence of hallucination", "Invents entities or claims", "Adds nothing not present in the source"]],
        [1.6, 2.1, 2.5],
    )
    caption(doc, "Table F.1: The five scoring dimensions with their scale anchors, as presented to raters.")

    doc.add_paragraph("Appendix G: Adjudication Worksheet", style="Heading 2")
    doc.add_paragraph(
        "Detector output is exported to a worksheet in which each candidate finding "
        "carries its identifier, the summary it belongs to, the detector that raised "
        "it, the flagged span, the proposed category and subtype, the detector's "
        "confidence and its evidence string. The reviewer sets 'confirmed' to TRUE or "
        "FALSE and may correct the category and subtype. Only confirmed findings "
        "contribute to a reported hallucination rate; the raw detector output is "
        "reported separately as a measure of detector performance."
    )
    add_figure(doc, "shot_adjudicate.png", 6.1,
               "Figure G.1: Exporting detector candidates for adjudication. Reproduce with `python -m ctieval adjudicate --export`.")

    doc.add_paragraph("Appendix H: Command Reference", style="Heading 2")
    add_figure(doc, "shot_help.png", 6.1,
               "Figure H.1: The ctieval command surface. Reproduce with `python -m ctieval --help`.")


    doc.add_page_break()
    doc.add_paragraph("Appendix I: Prompt Templates", style="Heading 2")
    doc.add_paragraph(
        "One unified prompt is applied to every model so that cross-model "
        "differences cannot be attributed to prompt variation (Section 5.4.1). "
        "The prompt is sent programmatically over each backend's chat-completions "
        "interface — the Anthropic Messages API for the proprietary model and LM "
        "Studio's OpenAI-compatible local endpoint for the two open models — as a "
        "system turn followed by a single user turn. No prompt is entered by hand "
        "at any point, and the prompt identifier is logged with every summary so "
        "that a result can be traced to the exact wording that produced it."
    )
    doc.add_paragraph("System turn (identical for every model and every item):")
    add_verbatim(doc,
        "You are a cyber threat intelligence analyst working in a Security\n"
        "Operations Centre. You write concise, factually precise summaries of\n"
        "threat intelligence for other analysts. You never introduce information\n"
        "that is not present in the source material.")
    doc.add_paragraph(
        "User turn (prompt_id cti_summary_v1). {label} is substituted per source "
        "type — \"vulnerability record\" for CVE items, \"threat intelligence "
        "pulse\" for OTX items, \"threat report extract\" for report sections — "
        "and {source} is the item's source text:"
    )
    add_verbatim(doc,
        "Summarise the following {label} for a SOC analyst.\n"
        "\n"
        "Requirements:\n"
        "- Between 60 and 120 words, in continuous prose (no bullet points, no headings).\n"
        "- State what the threat is, what it affects, and why it matters operationally.\n"
        "- Preserve every identifier exactly as written in the source (CVE IDs, CWE IDs,\n"
        "  CVSS scores, product names, version numbers, threat actor names).\n"
        "- Include no information that is not stated in the source.\n"
        "\n"
        "SOURCE:\n"
        "\"\"\"\n"
        "{source}\n"
        "\"\"\"\n"
        "\n"
        "SUMMARY:")
    doc.add_paragraph(
        "Three requirements in that template do specific work. The word range "
        "bounds the length ratio so that a model cannot score well by returning "
        "the source nearly verbatim. The identifier-preservation clause is the "
        "instruction the grounding checker of Section 5.3.6 tests compliance with, "
        "which makes entity and circumstantial errors attributable to the model "
        "rather than to an under-specified task. The final clause states the "
        "no-extrinsic-content constraint explicitly, so that a fabrication is a "
        "departure from an instruction the model was given and not merely an "
        "absence of guidance."
    )
    doc.add_paragraph(
        "Two further variants are implemented for the mitigation study specified "
        "as further work in Chapter 8, in which the prompt becomes the deliberately "
        "manipulated variable. They are recorded here because they ship with the "
        "released framework and are selectable by configuration; neither was used "
        "to produce any result in this dissertation."
    )
    doc.add_paragraph("Chain-of-thought variant (cti_summary_v1_cot) appends:")
    add_verbatim(doc,
        "Before writing, work through these steps silently:\n"
        "1. List the identifiers that appear verbatim in the source.\n"
        "2. List the claims the source actually makes about them.\n"
        "3. Discard anything you know from elsewhere that the source does not state.\n"
        "Then write only the final summary, with no preamble and no working.")
    doc.add_paragraph("Source-grounded variant (cti_summary_v1_grounded) appends:")
    add_verbatim(doc,
        "Every factual claim in your summary must be traceable to a specific phrase in\n"
        "the SOURCE above. If the source does not state something, omit it rather than\n"
        "inferring it. Where the source is silent on impact or exploitation status, say\n"
        "nothing about it.")
    doc.add_paragraph(
        "Decoding parameters are identical across models and are recorded in "
        "config.yaml: temperature 0.0 and a 512-token output ceiling. Model "
        "responses are normalised only by stripping a conversational preamble such "
        "as \"Here is a summary:\" where present, applied identically to every "
        "model and disclosed in Chapter 8."
    )


# --------------------------------------------------------------------------- #
# Assembly
# --------------------------------------------------------------------------- #

def build(out_path):
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.1)
        section.right_margin = Inches(1.1)
    configure_styles(doc)

    title_page(doc)
    declaration_and_consent(doc)
    doc.add_paragraph("Acknowledgements", style="Heading 1")
    doc.add_paragraph(
        "I thank my supervisor, Djuradj Budimir, for his guidance throughout this "
        "project, and the cybersecurity practitioners who gave their time to the "
        "blinded evaluation. Any remaining errors are my own."
    )
    doc.add_page_break()
    abstract_page(doc)
    toc_page(doc)

    add_page_number_footer(doc.sections[0])

    tables = {
        "plan": table_plan, "risk": table_risk, "contrib": table_contrib,
        "tiers": table_tiers, "lit": table_lit, "obj": table_obj,
        "corpus": table_corpus, "reqs": table_reqs, "alts": table_alts,
        "taxonomy": table_taxonomy, "atoms": table_atoms,
        "validity": table_validity, "detector": table_detector,
        "dr_metrics": table_dr_metrics, "dr_source": table_dr_source,
        "dr_omnibus": table_dr_omnibus, "dr_pairwise": table_dr_pairwise,
        "dr_halluc": table_dr_halluc, "dr_human": table_dr_human,
        "dr_agreement": table_dr_agreement,
    }
    figures = {"arch": figure_arch}

    for blocks in (c1.CH1, c1.CH2, c1.CH3, c2.CH4, c2.CH5, c3.CH6, c3.CH7, c3.CH8):
        emit_blocks(doc, blocks, tables, figures)
        doc.add_page_break()

    references_page(doc)
    glossary_page(doc)
    appendices_page(doc)

    doc.save(out_path)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "MSc_Dissertation_w18850154.docx"
    build(out)
