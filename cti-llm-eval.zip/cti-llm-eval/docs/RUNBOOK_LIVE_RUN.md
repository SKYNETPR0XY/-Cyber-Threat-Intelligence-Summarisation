# Running the live experiment — step by step

Windows PowerShell. Everything below is run from the project folder:

```powershell
cd "J:\Cyber Sec\2\MSc Cyber Security and Forensics Projects\TEST 3\cti-llm-eval"
```

Work through the stages in order. `scripts\run_live_experiment.py` gates every
step and refuses to continue where the output would not be reportable, so if it
stops, read what it says rather than working around it.

---

## Stage 0 — One-time setup (about 45 minutes, most of it downloads)

### 0.1 Python environment

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e .
pip install bert-score
```

`bert-score` pulls PyTorch — roughly 2 GB, and it is the single largest download.
Confirm it worked, and that the backbone can be fetched from the Hugging Face hub
(this caches it, so it only needs to happen once with internet access):

```powershell
python -c "import bert_score; from transformers import AutoConfig; AutoConfig.from_pretrained('distilbert-base-uncased'); print('BERTScore ready')"
```

If that prints `BERTScore ready`, scoring will work. If it errors, fix it now —
`ctieval score` deliberately refuses to run without real BERTScore rather than
silently recording the TF-IDF proxy, so a failure here stops you later anyway.

### 0.2 API keys

Get them:

| Key | Where | Cost |
|---|---|---|
| `ANTHROPIC_API_KEY` | console.anthropic.com → API keys | pay-as-you-go, this run is a few pounds |
| `OTX_API_KEY` | otx.alienvault.com → Settings → API key | free |
| `NVD_API_KEY` | nvd.nist.gov/developers/request-an-api-key | free, optional |

The NVD key is optional but worth ten minutes of waiting: without it collection is
throttled to 5 requests per 30 seconds, with it 50.

Set them in the PowerShell window you will run from. These last for that window only:

```powershell
$env:ANTHROPIC_API_KEY = "sk-ant-..."
$env:OTX_API_KEY       = "..."
$env:NVD_API_KEY       = "..."
```

Do **not** put them in `config/config.yaml` or in `.env.example`. Section 5.3.4 of
your dissertation commits to environment-only credentials, and a test now fails
the build if a key appears anywhere in the repository.

> **Set a spend cap** in the Anthropic console before your first run. Your risk
> register commits to a £50 ceiling; the console enforces it, watching the number
> does not.

### 0.3 LM Studio

1. Install LM Studio and open the **Search** tab.
2. Download **`Meta-Llama-3-8B-Instruct-GGUF`**, quantisation **Q4_K_M** (~4.9 GB).
3. Download **`Mistral-7B-Instruct-v0.3-GGUF`**, quantisation **Q4_K_M** (~4.4 GB).
4. Go to the **Developer** tab (`>_` icon), load one model, click **Start Server**.
   It listens on port 1234. Leave LM Studio open for the whole run.
5. Ask the server what it is actually serving:

```powershell
curl http://localhost:1234/v1/models
```

6. Copy each `id` string it returns into `config/config.yaml` under `model_id`.
   They must match exactly — an identifier that is close but not right fails at
   generation time, after you have queued items.

> LM Studio serves **one model at a time** by default. Either run the two open
> models in separate passes (Stage 3 shows how), or enable multi-model serving
> and load both.

### 0.4 Vendor and APT reports

The APT stratum reads PDFs you supply, because vendor licences do not permit
automated scraping.

```powershell
mkdir data\apt_pdfs -Force
```

Put 3–6 public reports in there — Mandiant M-Trends, CrowdStrike Global Threat
Report, MITRE ATT&CK group profiles for APT28 (G0007) and Lazarus (G0032) are the
ones your proposal names. **Record the exact pages you use**; Section 5.2.3 commits
to citing them, and only hashes and page ranges are redistributed, not the text.

Delete `sample.pdf` from that folder before collecting, or it becomes corpus items.

### 0.5 Check everything at once

```powershell
python scripts\run_live_experiment.py
```

It checks keys, BERTScore, the backbone, the PDFs, and backend reachability, and
tells you exactly what is missing. **Nothing is spent until every gate passes.**

---

## Stage 1 — Collect the corpus (~20 minutes, mostly NVD rate-limiting)

```powershell
python -m ctieval collect --source all --pdf-dir data\apt_pdfs
```

This pulls 30 CVE records from NVD stratified 10 Critical / 10 High / 10 Medium,
30 OTX pulses from a 30-day window, and segments your PDFs into sections. It
writes `data\corpus.jsonl` and appends to `data\provenance_registry.csv`.

Check what you got:

```powershell
python -c "import json; rows=[json.loads(l) for l in open('data/corpus.jsonl',encoding='utf-8')]; import collections; print(collections.Counter(r['source_type'] for r in rows)); print(sum(1 for r in rows if not r['reference_summary'].strip()), 'awaiting a reference summary')"
```

You want 30 / 30 / ~30. If the APT count is low, lower `--apt-min-words` or add
more PDFs.

**For Chapter 6:** the provenance registry is your Appendix D evidence. Keep it.

---

## Stage 2 — Author the reference summaries (the long part: several sessions)

CVE items already have ground truth — the NVD description. OTX and APT items do
not, deliberately: using a pulse's own description as its own reference would
inflate every ROUGE score in the study.

```powershell
python -m ctieval annotate --export
```

This writes `data\reference_summaries.csv`. Open it in Excel. For each row, read
`SOURCE_TEXT` and write, in the `reference_summary` column, the 60–120 word
summary you would hand a SOC analyst. State what the threat is, what it affects,
and why it matters operationally.

This is ~60 summaries and it is the slowest stage in the project. Save as you go —
you can export, fill some, import, and repeat.

Then have your **second practitioner review them**. Section 5.2.2 commits to this
and an examiner may ask who did it. Record the name in the item metadata.

```powershell
python -m ctieval annotate --import data\reference_summaries.csv
```

Confirm nothing is outstanding:

```powershell
python -c "import json; rows=[json.loads(l) for l in open('data/corpus.jsonl',encoding='utf-8')]; print(sum(1 for r in rows if not r['reference_summary'].strip()), 'still missing')"
```

---

## Stage 3 — Generate (~40–90 minutes, mostly local inference)

**Always smoke-test first.** Three items catches a wrong model id or a dead server
in thirty seconds instead of forty minutes:

```powershell
python -m ctieval run --limit 3
```

Three lines marked `ok`, no errors → the wiring is right. Then the full grid.

If LM Studio serves one model at a time, run three passes, switching the loaded
model in LM Studio between the second and third:

```powershell
python -m ctieval run --models "Claude Sonnet 4.6"
python -m ctieval run --models "LLaMA 3 8B"
# load Mistral in LM Studio, then:
python -m ctieval run --models "Mistral 7B"
```

The runner is resumable and caches by (item, model, prompt), so an interrupted run
re-executes only what is missing and re-running costs nothing. **Watch the cost
line** printed in the run summary.

---

## Stage 4 — Score

```powershell
python -m ctieval score
```

Confirm you have real BERTScore, not the proxy — this is the one check that
decides whether Chapter 6 is reportable:

```powershell
python -c "import pandas as pd; d=pd.read_csv('results/metrics.csv'); print(d['semantic_metric'].iloc[0]); print([c for c in d.columns if 'bert' in c])"
```

It must print `bertscore_f1`. If it prints `semantic_sim_tfidf`, stop and fix
Stage 0.1 — that column is not BERTScore and must not be reported as such.

`score` also prints the Friedman and pairwise Wilcoxon results to the console.

---

## Stage 5 — Detect and adjudicate

```powershell
python -m ctieval detect
```

Optionally add the LLM judge — one extra API call per summary, so it roughly
doubles Claude spend:

```powershell
python -m ctieval detect --judge "Claude Sonnet 4.6"
```

Detection produces **candidates, not findings**. Your Section 6.2 result is that
the detector has recall 1.00 and precision 0.178, so roughly four flags in five are
not real errors. Reporting raw detector counts as a hallucination rate would
contradict your own Chapter 6.

```powershell
python -m ctieval adjudicate --export results\adjudication.csv
```

Open it in Excel. Each row is one candidate: the flagged span, the evidence, the
proposed category and subtype. Set `confirmed` to `TRUE` or `FALSE` for every row,
and correct `category` / `subtype` where the detector classified a real error
wrongly. Then:

```powershell
python -m ctieval adjudicate --import results\adjudication.csv
```

It prints detector precision against your adjudication. **That number is a result** —
it goes in Table 6.6.

---

## Stage 6 — Human evaluation

```powershell
python -m ctieval humaneval build --n 10
```

`--n` counts corpus **items** per source type, so `--n 10` gives 10 items × 3
source types × 3 models = 90 rated summaries. The command prints the exact figures;
put them in the Table 6.7 caption, because Section 5.5.3 has to state the sample.

Send `results\human_eval_sheet.csv` to each of your two practitioners. **Keep
`human_eval_key.csv` to yourself** — if a rater can see which summary came from the
commercial API, every score is contaminated.

When both return:

```powershell
python -m ctieval humaneval analyse --scores rater1=r1.csv --scores rater2=r2.csv
```

This prints per-model scores and the agreement line — weighted kappa per dimension
and ICC(2,k). A dimension below 0.6 is a reportable finding about instrument
subjectivity, not a failure; say so in the interpretation.

---

## Stage 7 — Report and verify

```powershell
python -m ctieval report
python scripts\verify_statistics.py results
```

`report` writes everything into `results\report\`. `verify_statistics.py`
recomputes every number independently and must print **100/100 checks passed**. If
it does not, something is wrong with the analysis and the numbers are not safe to
report.

---

## Stage 8 — Fill Chapter 6

Each `[INSERT …]` slot in the dissertation names the file that fills it:

| Dissertation slot | File in `results\report\` |
|---|---|
| §6.3.1 run summary | top of `results_pack.md` |
| Table 6.2 | `table_descriptives.csv` |
| Table 6.3 | `table_metric_confidence_intervals.csv` |
| Figure 6.6 | `figures\fig_metrics_by_model.png` |
| Table 6.4 | `table_by_source_type.csv` |
| Figure 6.7 | `figures\fig_rougeL_by_source.png` |
| §6.3.4 Friedman line + Table 6.5 | `table_stats_rougeL_f.csv`, `table_stats_bertscore_f1.csv` |
| Table 6.6 | `table_hallucination_rates.csv` |
| Figure 6.8 | `figures\fig_hallucination.png` |
| Table 6.7 | printed by `humaneval analyse` |
| Figure 6.9 | `figures\fig_cost_latency.png` |

Paste each in, then rewrite the red "Note to author" block beneath it into prose,
using the specific numbers. The questions in each note are the ones an examiner
will ask.

**Before submitting:** search the document for "Note to author" and for `[INSERT` —
every one must be gone. Then select the Contents, List of Figures and List of
Tables fields in Word and press **F9** to generate them.

---

## If something goes wrong

| Symptom | Cause and fix |
|---|---|
| `preflight` shows FAIL for a local model | The `model_id` in config.yaml does not match what LM Studio reports. Re-run `curl http://localhost:1234/v1/models`. |
| Every generation for one model errors | That model is not the one currently loaded in LM Studio. |
| `score` exits with status 3 | BERTScore unavailable. Stage 0.1. Do not use `--allow-semantic-fallback` for real results. |
| `collect` exits with status 2 | Network or key problem; the message names which. Records already collected are kept — re-run with `--append`. |
| NVD returns 403 or 503 | Rate limiting. The collector backs off and retries; get an NVD key to reduce it. |
| Generation is very slow | Local 8B inference on CPU. Enable GPU offload in LM Studio's model settings. |
| `verify_statistics.py` reports a failure | Do not report the numbers. Send me the output. |
