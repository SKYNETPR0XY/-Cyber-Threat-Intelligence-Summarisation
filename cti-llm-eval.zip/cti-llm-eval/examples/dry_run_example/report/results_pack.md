> **DRY RUN — SYNTHETIC DATA.** Every number below was produced from the offline synthetic corpus with the mock provider. It validates that the pipeline runs end to end. It is **not** an experimental result and must not be reported as one.

## 6.1 Overview of the experimental run

The experiment produced 90 summaries: 30 corpus items across 3 models. Coverage by source type was 9 APT, 12 CVE, 9 OTX.

### Table 6.1 — Automated metrics by model (mean ± SD)

| Model                                   |   rouge1_f_mean |   rouge1_f_std |   rouge2_f_mean |   rouge2_f_std |   rougeL_f_mean |   rougeL_f_std |   semantic_sim_tfidf_mean |   semantic_sim_tfidf_std |   len_ratio_mean |   len_ratio_std |   novel_unigram_rate_mean |   novel_unigram_rate_std |   latency_s_mean |   latency_s_std |
|:----------------------------------------|----------------:|---------------:|----------------:|---------------:|----------------:|---------------:|--------------------------:|-------------------------:|-----------------:|----------------:|--------------------------:|-------------------------:|-----------------:|----------------:|
| Stand-in A (proxies the API model)      |           0.548 |          0.074 |           0.381 |          0.193 |           0.466 |          0.136 |                     0.550 |                    0.049 |            1.724 |           0.186 |                     0.013 |                    0.028 |            2.996 |           1.020 |
| Stand-in B (proxies local open model 1) |           0.499 |          0.102 |           0.344 |          0.198 |           0.419 |          0.159 |                     0.544 |                    0.146 |            1.622 |           0.363 |                     0.097 |                    0.044 |           11.257 |           3.995 |
| Stand-in C (proxies local open model 2) |           0.481 |          0.094 |           0.314 |          0.185 |           0.400 |          0.149 |                     0.523 |                    0.142 |            1.746 |           0.328 |                     0.164 |                    0.067 |            8.788 |           2.720 |

![Automated metrics by model](/home/claude/build/cti-llm-eval/results/demo/report/figures/fig_metrics_by_model.png)

*Figure 6.1: Automated summarisation metrics by model, mean ± standard error.*

### Table 6.1b — Bootstrap 95% confidence intervals for the means

| Model                                   |   n |   rouge1_f_mean | rouge1_f_ci95    |   rouge2_f_mean | rouge2_f_ci95    |   rougeL_f_mean | rougeL_f_ci95    |   semantic_sim_tfidf_mean | semantic_sim_tfidf_ci95   |
|:----------------------------------------|----:|----------------:|:-----------------|----------------:|:-----------------|----------------:|:-----------------|--------------------------:|:--------------------------|
| Stand-in A (proxies the API model)      |  30 |           0.548 | [0.5213, 0.5735] |           0.381 | [0.3139, 0.4504] |           0.466 | [0.4177, 0.5147] |                     0.550 | [0.5330, 0.5677]          |
| Stand-in B (proxies local open model 1) |  30 |           0.499 | [0.4643, 0.5357] |           0.344 | [0.2755, 0.4140] |           0.419 | [0.3640, 0.4753] |                     0.544 | [0.4930, 0.5960]          |
| Stand-in C (proxies local open model 2) |  30 |           0.481 | [0.4486, 0.5151] |           0.314 | [0.2503, 0.3811] |           0.400 | [0.3485, 0.4541] |                     0.523 | [0.4739, 0.5740]          |

### Table 6.2 — Automated metrics by CTI source type

| source_type   | model_label                             |   rouge1_f |   rouge2_f |   rougeL_f |   semantic_sim_tfidf |
|:--------------|:----------------------------------------|-----------:|-----------:|-----------:|---------------------:|
| apt           | Stand-in A (proxies the API model)      |      0.550 |      0.255 |      0.430 |                0.509 |
| apt           | Stand-in B (proxies local open model 1) |      0.434 |      0.203 |      0.312 |                0.374 |
| apt           | Stand-in C (proxies local open model 2) |      0.410 |      0.176 |      0.289 |                0.357 |
| cve           | Stand-in A (proxies the API model)      |      0.621 |      0.612 |      0.617 |                0.605 |
| cve           | Stand-in B (proxies local open model 1) |      0.619 |      0.579 |      0.609 |                0.707 |
| cve           | Stand-in C (proxies local open model 2) |      0.592 |      0.534 |      0.578 |                0.681 |
| otx           | Stand-in A (proxies the API model)      |      0.448 |      0.200 |      0.301 |                0.517 |
| otx           | Stand-in B (proxies local open model 1) |      0.405 |      0.170 |      0.274 |                0.496 |
| otx           | Stand-in C (proxies local open model 2) |      0.404 |      0.159 |      0.274 |                0.480 |

![ROUGE-L by source type](/home/claude/build/cti-llm-eval/results/demo/report/figures/fig_rougeL_by_source.png)

*Figure 6.2: Distribution of ROUGE-L F by model within each CTI source type.*

## 6.2 Inferential comparison between models

- **rouge1_f**: Friedman χ²(30 items) = 36.87, p = 0.0000, Kendall's W = 0.614.
- **rougeL_f**: Friedman χ²(30 items) = 38.60, p = 0.0000, Kendall's W = 0.643.
- **semantic_sim_tfidf**: Friedman χ²(30 items) = 6.07, p = 0.0482, Kendall's W = 0.101.

### Table 6.3.rouge1_f — Pairwise Wilcoxon signed-rank tests (rouge1_f)

| metric   | model_a                                 | model_b                                 |   median_a |   median_b |   mean_diff |   wilcoxon_W |   p_raw |   rank_biserial_r |   n |   p_holm | significant   |
|:---------|:----------------------------------------|:----------------------------------------|-----------:|-----------:|------------:|-------------:|--------:|------------------:|----:|---------:|:--------------|
| rouge1_f | Stand-in A (proxies the API model)      | Stand-in B (proxies local open model 1) |     0.5566 |     0.4530 |      0.0487 |      45.0000 |  0.0001 |            0.8065 |  30 |   0.0002 | True          |
| rouge1_f | Stand-in A (proxies the API model)      | Stand-in C (proxies local open model 2) |     0.5566 |     0.4147 |      0.0670 |       0.0000 |  0.0000 |            1.0000 |  30 |   0.0000 | True          |
| rouge1_f | Stand-in B (proxies local open model 1) | Stand-in C (proxies local open model 2) |     0.4530 |     0.4147 |      0.0183 |      72.0000 |  0.0010 |            0.6903 |  30 |   0.0010 | True          |

### Table 6.3.rougeL_f — Pairwise Wilcoxon signed-rank tests (rougeL_f)

| metric   | model_a                                 | model_b                                 |   median_a |   median_b |   mean_diff |   wilcoxon_W |   p_raw |   rank_biserial_r |   n |   p_holm | significant   |
|:---------|:----------------------------------------|:----------------------------------------|-----------:|-----------:|------------:|-------------:|--------:|------------------:|----:|---------:|:--------------|
| rougeL_f | Stand-in A (proxies the API model)      | Stand-in B (proxies local open model 1) |     0.4340 |     0.3204 |      0.0473 |      29.0000 |  0.0000 |            0.8753 |  30 |   0.0001 | True          |
| rougeL_f | Stand-in A (proxies the API model)      | Stand-in C (proxies local open model 2) |     0.4340 |     0.2982 |      0.0662 |       0.0000 |  0.0000 |            1.0000 |  30 |   0.0000 | True          |
| rougeL_f | Stand-in B (proxies local open model 1) | Stand-in C (proxies local open model 2) |     0.3204 |     0.2982 |      0.0190 |      85.0000 |  0.0024 |            0.6344 |  30 |   0.0024 | True          |

### Table 6.3.semantic_sim_tfidf — Pairwise Wilcoxon signed-rank tests (semantic_sim_tfidf)

| metric             | model_a                                 | model_b                                 |   median_a |   median_b |   mean_diff |   wilcoxon_W |   p_raw |   rank_biserial_r |   n |   p_holm | significant   |
|:-------------------|:----------------------------------------|:----------------------------------------|-----------:|-----------:|------------:|-------------:|--------:|------------------:|----:|---------:|:--------------|
| semantic_sim_tfidf | Stand-in A (proxies the API model)      | Stand-in B (proxies local open model 1) |     0.5221 |     0.5000 |      0.0060 |     203.0000 |  0.5439 |            0.1269 |  30 |   0.5439 | False         |
| semantic_sim_tfidf | Stand-in A (proxies the API model)      | Stand-in C (proxies local open model 2) |     0.5221 |     0.4868 |      0.0263 |     174.0000 |  0.2287 |            0.2516 |  30 |   0.4574 | False         |
| semantic_sim_tfidf | Stand-in B (proxies local open model 1) | Stand-in C (proxies local open model 2) |     0.5000 |     0.4868 |      0.0203 |      58.0000 |  0.0003 |            0.7505 |  30 |   0.0010 | True          |

## 6.3 Hallucination

### Table 6.4 — Detector-flagged rate and taxonomy breakdown

| Model                                   |   Summaries |   Flagged |   Flagged % | 95% CI       |   Findings |   Findings/summary |   Intrinsic |   Extrinsic |   Entity |   Relational |   Circumstantial |   Fabrication |
|:----------------------------------------|------------:|----------:|------------:|:-------------|-----------:|-------------------:|------------:|------------:|---------:|-------------:|-----------------:|--------------:|
| Stand-in A (proxies the API model)      |          30 |         4 |       13.30 | [5.3, 29.7]  |         13 |               0.43 |           1 |          12 |        1 |            0 |                0 |            12 |
| Stand-in B (proxies local open model 1) |          30 |         7 |       23.30 | [11.8, 40.9] |         25 |               0.83 |           0 |          25 |        0 |            0 |                0 |            25 |
| Stand-in C (proxies local open model 2) |          30 |        18 |       60.00 | [42.3, 75.4] |         54 |               1.80 |           4 |          50 |        2 |            2 |                0 |            50 |

**These are detector-flagged rates, not adjudicated hallucination rates.** No findings have been reviewed by a human (`ctieval adjudicate`), so each figure is an upper bound that includes the detector's false positives. `Findings` counts checkable atoms, so one fabricated sentence can contribute several.

![Hallucination](/home/claude/build/cti-llm-eval/results/demo/report/figures/fig_hallucination.png)

*Figure 6.3: Hallucination rate by category (left) and error counts by taxonomy subtype (right).*

### Table 6.5 — Grounding detector validation against seeded errors

| method                        |   precision |   recall |    f1 |   true_positives |   false_positives |   false_negatives |   n_injected |   n_detected |
|:------------------------------|------------:|---------:|------:|-----------------:|------------------:|------------------:|-------------:|-------------:|
| per (item_id, model_id, span) |       0.206 |    1.000 | 0.342 |               19 |                73 |                 0 |           19 |           92 |

Matching is on (item_id, model_id, span) triples. Pooling span strings across the corpus collapses repeated spans into one entry and inflates precision.

## 6.5 Operational cost and latency

![Cost and latency](/home/claude/build/cti-llm-eval/results/demo/report/figures/fig_cost_latency.png)

*Figure 6.4: Median inference latency per summary and marginal cost per 1 000 summaries.*
