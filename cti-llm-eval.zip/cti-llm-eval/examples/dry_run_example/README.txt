DRY RUN — SYNTHETIC DATA — NOT AN EXPERIMENTAL RESULT
=====================================================

Example output from `python -m ctieval demo`, kept so that the shape of every
artefact can be inspected without running anything.

The three backends are STAND-INS. Each represents the structural profile of one
model in the study — relative quality, error rate, latency, marginal cost — so
that every stage downstream is exercised on realistically-shaped input. None of
them performs inference. None is named for the model it proxies, and their
model_ids are prefixed `mock/`.

  Stand-in A (proxies the API model)        strongest, priced, low latency
  Stand-in B (proxies local open model 1)   weaker, free at the margin, slow
  Stand-in C (proxies local open model 2)   weakest, free at the margin, slow

Every figure carries the DRY RUN watermark and the results pack carries the
banner, because the reporting layer refuses to emit from a synthetic corpus
without an explicit override.

No number in this directory may appear in the dissertation as a finding.
Regenerate with `python -m ctieval demo`.
