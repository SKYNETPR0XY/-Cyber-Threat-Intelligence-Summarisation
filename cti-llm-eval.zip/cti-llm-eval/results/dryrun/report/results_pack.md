> **DRY RUN — SYNTHETIC DATA.** Every number below was produced from the offline synthetic corpus with the mock provider. It validates that the pipeline runs end to end. It is **not** an experimental result and must not be reported as one.

## 6.1 Overview of the experimental run

The experiment produced 270 summaries: 90 corpus items across 3 models. Coverage by source type was 30 APT, 30 CVE, 30 OTX.

### Table 6.1 — Automated metrics by model (mean ± SD)

| Model                                   |   rouge1_f_mean |   rouge1_f_std |   rouge2_f_mean |   rouge2_f_std |   rougeL_f_mean |   rougeL_f_std |   semantic_sim_tfidf_mean |   semantic_sim_tfidf_std |   len_ratio_mean |   len_ratio_std |   novel_unigram_rate_mean |   novel_unigram_rate_std |   latency_s_mean |   latency_s_std |
|:----------------------------------------|----------------:|---------------:|----------------:|---------------:|----------------:|---------------:|--------------------------:|-------------------------:|-----------------:|----------------:|--------------------------:|-------------------------:|-----------------:|----------------:|
| Stand-in A (proxies the API model)      |           0.534 |          0.074 |           0.353 |          0.182 |           0.446 |          0.131 |                     0.545 |                    0.050 |            1.725 |           0.174 |                     0.021 |                    0.036 |            2.848 |           0.800 |
| Stand-in B (proxies local open model 1) |           0.482 |          0.095 |           0.314 |          0.186 |           0.396 |          0.148 |                     0.525 |                    0.141 |            1.628 |           0.388 |                     0.106 |                    0.048 |           10.189 |           3.275 |
| Stand-in C (proxies local open model 2) |           0.469 |          0.085 |           0.290 |          0.172 |           0.383 |          0.136 |                     0.514 |                    0.138 |            1.715 |           0.352 |                     0.162 |                    0.060 |            8.835 |           2.612 |

![Automated metrics by model](/home/claude/build/cti-llm-eval/results/dryrun/report/figures/fig_metrics_by_model.png)

*Figure 6.1: Automated summarisation metrics by model, mean ± standard error.*

### Table 6.1b — Bootstrap 95% confidence intervals for the means

| Model                                   |   n |   rouge1_f_mean | rouge1_f_ci95    |   rouge2_f_mean | rouge2_f_ci95    |   rougeL_f_mean | rougeL_f_ci95    |   semantic_sim_tfidf_mean | semantic_sim_tfidf_ci95   |
|:----------------------------------------|----:|----------------:|:-----------------|----------------:|:-----------------|----------------:|:-----------------|--------------------------:|:--------------------------|
| Stand-in A (proxies the API model)      |  90 |           0.534 | [0.5189, 0.5489] |           0.353 | [0.3164, 0.3910] |           0.446 | [0.4194, 0.4730] |                     0.545 | [0.5354, 0.5559]          |
| Stand-in B (proxies local open model 1) |  90 |           0.482 | [0.4635, 0.5026] |           0.314 | [0.2768, 0.3528] |           0.396 | [0.3669, 0.4273] |                     0.525 | [0.4972, 0.5543]          |
| Stand-in C (proxies local open model 2) |  90 |           0.469 | [0.4527, 0.4872] |           0.290 | [0.2556, 0.3257] |           0.383 | [0.3565, 0.4120] |                     0.514 | [0.4859, 0.5421]          |

### Table 6.2 — Automated metrics by CTI source type

| source_type   | model_label                             |   rouge1_f |   rouge2_f |   rougeL_f |   semantic_sim_tfidf |
|:--------------|:----------------------------------------|-----------:|-----------:|-----------:|---------------------:|
| apt           | Stand-in A (proxies the API model)      |      0.543 |      0.251 |      0.425 |                0.503 |
| apt           | Stand-in B (proxies local open model 1) |      0.427 |      0.197 |      0.309 |                0.370 |
| apt           | Stand-in C (proxies local open model 2) |      0.410 |      0.177 |      0.298 |                0.357 |
| cve           | Stand-in A (proxies the API model)      |      0.617 |      0.606 |      0.615 |                0.612 |
| cve           | Stand-in B (proxies local open model 1) |      0.612 |      0.572 |      0.602 |                0.705 |
| cve           | Stand-in C (proxies local open model 2) |      0.586 |      0.529 |      0.572 |                0.689 |
| otx           | Stand-in A (proxies the API model)      |      0.441 |      0.201 |      0.298 |                0.522 |
| otx           | Stand-in B (proxies local open model 1) |      0.409 |      0.172 |      0.277 |                0.500 |
| otx           | Stand-in C (proxies local open model 2) |      0.413 |      0.162 |      0.280 |                0.495 |

![ROUGE-L by source type](/home/claude/build/cti-llm-eval/results/dryrun/report/figures/fig_rougeL_by_source.png)

*Figure 6.2: Distribution of ROUGE-L F by model within each CTI source type.*

## 6.2 Inferential comparison between models

- **rouge1_f**: Friedman χ²(90 items) = 92.42, p = 0.0000, Kendall's W = 0.513.
- **rougeL_f**: Friedman χ²(90 items) = 95.29, p = 0.0000, Kendall's W = 0.529.
- **semantic_sim_tfidf**: Friedman χ²(90 items) = 20.07, p = 0.0000, Kendall's W = 0.111.

### Table 6.3.rouge1_f — Pairwise Wilcoxon signed-rank tests (rouge1_f)

| metric   | model_a                                 | model_b                                 |   median_a |   median_b |   mean_diff |   wilcoxon_W |   p_raw |   rank_biserial_r |   n |   p_holm | significant   |
|:---------|:----------------------------------------|:----------------------------------------|-----------:|-----------:|------------:|-------------:|--------:|------------------:|----:|---------:|:--------------|
| rouge1_f | Stand-in A (proxies the API model)      | Stand-in B (proxies local open model 1) |     0.5446 |     0.4262 |      0.0513 |     363.0000 |  0.0000 |            0.8227 |  90 |   0.0000 | True          |
| rouge1_f | Stand-in A (proxies the API model)      | Stand-in C (proxies local open model 2) |     0.5446 |     0.4190 |      0.0644 |     121.0000 |  0.0000 |            0.9409 |  90 |   0.0000 | True          |
| rouge1_f | Stand-in B (proxies local open model 1) | Stand-in C (proxies local open model 2) |     0.4262 |     0.4190 |      0.0131 |    1038.0000 |  0.0000 |            0.4930 |  90 |   0.0000 | True          |

### Table 6.3.rougeL_f — Pairwise Wilcoxon signed-rank tests (rougeL_f)

| metric   | model_a                                 | model_b                                 |   median_a |   median_b |   mean_diff |   wilcoxon_W |   p_raw |   rank_biserial_r |   n |   p_holm | significant   |
|:---------|:----------------------------------------|:----------------------------------------|-----------:|-----------:|------------:|-------------:|--------:|------------------:|----:|---------:|:--------------|
| rougeL_f | Stand-in A (proxies the API model)      | Stand-in B (proxies local open model 1) |     0.4319 |     0.3158 |      0.0496 |     324.0000 |  0.0000 |            0.8418 |  90 |   0.0000 | True          |
| rougeL_f | Stand-in A (proxies the API model)      | Stand-in C (proxies local open model 2) |     0.4319 |     0.3094 |      0.0626 |     102.0000 |  0.0000 |            0.9502 |  90 |   0.0000 | True          |
| rougeL_f | Stand-in B (proxies local open model 1) | Stand-in C (proxies local open model 2) |     0.3158 |     0.3094 |      0.0130 |    1184.0000 |  0.0005 |            0.4217 |  90 |   0.0005 | True          |

### Table 6.3.semantic_sim_tfidf — Pairwise Wilcoxon signed-rank tests (semantic_sim_tfidf)

| metric             | model_a                                 | model_b                                 |   median_a |   median_b |   mean_diff |   wilcoxon_W |   p_raw |   rank_biserial_r |   n |   p_holm | significant   |
|:-------------------|:----------------------------------------|:----------------------------------------|-----------:|-----------:|------------:|-------------:|--------:|------------------:|----:|---------:|:--------------|
| semantic_sim_tfidf | Stand-in A (proxies the API model)      | Stand-in B (proxies local open model 1) |     0.5215 |     0.5006 |      0.0202 |    1497.0000 |  0.0267 |            0.2689 |  90 |   0.0267 | True          |
| semantic_sim_tfidf | Stand-in A (proxies the API model)      | Stand-in C (proxies local open model 2) |     0.5215 |     0.4986 |      0.0317 |    1311.0000 |  0.0030 |            0.3597 |  90 |   0.0061 | True          |
| semantic_sim_tfidf | Stand-in B (proxies local open model 1) | Stand-in C (proxies local open model 2) |     0.5006 |     0.4986 |      0.0115 |    1108.0000 |  0.0002 |            0.4589 |  90 |   0.0005 | True          |

## 6.3 Hallucination

### Table 6.4 — Detector-flagged rate and taxonomy breakdown

| Model                                   |   Summaries |   Flagged |   Flagged % | 95% CI       |   Findings |   Findings/summary |   Intrinsic |   Extrinsic |   Entity |   Relational |   Circumstantial |   Fabrication |
|:----------------------------------------|------------:|----------:|------------:|:-------------|-----------:|-------------------:|------------:|------------:|---------:|-------------:|-----------------:|--------------:|
| Stand-in A (proxies the API model)      |          90 |        19 |       21.10 | [14.0, 30.6] |         64 |               0.71 |           4 |          60 |        2 |            2 |                0 |            60 |
| Stand-in B (proxies local open model 1) |          90 |        34 |       37.80 | [28.5, 48.1] |        126 |               1.40 |           3 |         123 |        1 |            1 |                1 |           123 |
| Stand-in C (proxies local open model 2) |          90 |        55 |       61.10 | [50.8, 70.5] |        169 |               1.88 |          10 |         159 |        3 |            5 |                2 |           159 |

**These are detector-flagged rates, not adjudicated hallucination rates.** No findings have been reviewed by a human (`ctieval adjudicate`), so each figure is an upper bound that includes the detector's false positives. `Findings` counts checkable atoms, so one fabricated sentence can contribute several.

![Hallucination](/home/claude/build/cti-llm-eval/results/dryrun/report/figures/fig_hallucination.png)

*Figure 6.3: Hallucination rate by category (left) and error counts by taxonomy subtype (right).*

### Table 6.5 — Grounding detector validation against seeded errors

| method                        |   precision |   recall |    f1 |   true_positives |   false_positives |   false_negatives |   n_injected |   n_detected |
|:------------------------------|------------:|---------:|------:|-----------------:|------------------:|------------------:|-------------:|-------------:|
| per (item_id, model_id, span) |       0.178 |    1.000 | 0.303 |               64 |               295 |                 0 |           64 |          359 |

Matching is on (item_id, model_id, span) triples. Pooling span strings across the corpus collapses repeated spans into one entry and inflates precision.

## 6.4 Human expert evaluation

### Table 6.6 — Expert scores by model and source type (1–5)

| model_label                             | source_type   |   factual_accuracy_mean |   factual_accuracy_std |   completeness_mean |   completeness_std |   conciseness_mean |   conciseness_std |   relevance_mean |   relevance_std |   absence_of_hallucination_mean |   absence_of_hallucination_std |   composite_mean |   composite_std |
|:----------------------------------------|:--------------|------------------------:|-----------------------:|--------------------:|-------------------:|-------------------:|------------------:|-----------------:|----------------:|--------------------------------:|-------------------------------:|-----------------:|----------------:|
| Stand-in A (proxies the API model)      | apt           |                   3.500 |                  1.395 |               4.600 |              0.503 |              4.150 |             0.813 |            4.100 |           0.718 |                           3.550 |                          1.276 |            3.980 |           0.649 |
| Stand-in A (proxies the API model)      | cve           |                   4.350 |                  0.745 |               4.250 |              0.716 |              4.600 |             0.598 |            4.400 |           0.598 |                           4.250 |                          0.716 |            4.370 |           0.363 |
| Stand-in A (proxies the API model)      | otx           |                   4.150 |                  1.268 |               4.500 |              0.607 |              4.250 |             0.639 |            4.300 |           0.657 |                           4.000 |                          1.170 |            4.240 |           0.513 |
| Stand-in B (proxies local open model 1) | apt           |                   3.400 |                  1.314 |               3.200 |              0.768 |              2.550 |             0.605 |            3.000 |           0.725 |                           3.200 |                          1.322 |            3.070 |           0.567 |
| Stand-in B (proxies local open model 1) | cve           |                   3.450 |                  0.945 |               3.100 |              0.718 |              2.950 |             0.686 |            3.150 |           0.671 |                           3.200 |                          0.951 |            3.170 |           0.500 |
| Stand-in B (proxies local open model 1) | otx           |                   2.200 |                  1.399 |               3.150 |              0.671 |              2.600 |             0.754 |            3.000 |           0.562 |                           2.350 |                          1.182 |            2.660 |           0.520 |
| Stand-in C (proxies local open model 2) | apt           |                   2.200 |                  1.322 |               2.550 |              0.605 |              2.000 |             0.562 |            2.300 |           0.571 |                           1.850 |                          1.089 |            2.180 |           0.546 |
| Stand-in C (proxies local open model 2) | cve           |                   2.500 |                  1.000 |               2.200 |              0.523 |              1.950 |             0.605 |            2.350 |           0.813 |                           2.550 |                          0.945 |            2.310 |           0.470 |
| Stand-in C (proxies local open model 2) | otx           |                   1.400 |                  0.681 |               2.450 |              0.686 |              1.800 |             0.616 |            2.150 |           0.745 |                           1.450 |                          0.686 |            1.850 |           0.296 |

**Inter-rater agreement.** kappa_w_factual_accuracy = 0.6573; kappa_w_completeness = 0.4563; kappa_w_conciseness = 0.4766; kappa_w_relevance = 0.5335; kappa_w_absence_of_hallucination = 0.6697; icc2k_composite = 0.9624; n_double_rated = 90.

## 6.5 Operational cost and latency

![Cost and latency](/home/claude/build/cti-llm-eval/results/dryrun/report/figures/fig_cost_latency.png)

*Figure 6.4: Median inference latency per summary and marginal cost per 1 000 summaries.*
